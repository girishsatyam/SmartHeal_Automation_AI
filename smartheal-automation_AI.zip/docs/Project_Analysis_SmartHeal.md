# SmartHeal_Automation_AI – Comprehensive Project Analysis and Enhancement Plan

This single, merged document replaces the previous two docs (Project_Analysis_SmartHeal.md and SmartHeal_Enhancement_Proposal.md). It provides a deep-dive analysis of the repository structure, architecture, core components, dependencies, test strategy, reporting, and a feature-flagged enhancement plan to improve accuracy, speed, and stability of SmartHeal.

Important note: Mobile Android/iOS test cases and Web flow test cases are working fully fine. No changes are required to existing test flows or functionality. All enhancements are non-disruptive and gated behind conservative feature flags.

---

## 1) High-level Overview

SmartHeal_Automation_AI is an automated UI test framework for Android, iOS, and Web (Selenium/Appium), augmented with an AI-powered self-healing locator subsystem (SmartHeal). When a locator breaks, SmartHeal uses an offline embedding model to generate candidate element matches from the current DOM/tree, ranks candidates (ML or heuristics), and persists the healed locator back to YAML so subsequent runs stabilize. Allure is used for reporting, including a dedicated SmartHeal summary.

Key entrypoints:
- runner.py: unified CLI to run tests per-platform or in parallel (Android+iOS), bootstrap Appium, and generate Allure HTML with a local static server.
- pytest.ini and tests/conftest.py: plugin config, driver creation, fixtures, Allure metadata, and SmartHeal console/report summaries.


## 2) Repository Structure and Roles

- config/
  - android_config.json, ios_config.json, web_config.json: driver capabilities and baseUrl/headless for web.
- data/
  - locators/{android,ios,web}/*.yaml: page-object locators with semantic labels and strategies.
  - test_data/test_data_<ENV>.yaml: credentials and environment-specific test inputs.
- models/
  - nlp/ (SentenceTransformer offline model BAAI/bge-m3) and LightGBM model file.
- scripts/
  - download_model.py: fetches SentenceTransformer to models/nlp for offline usage.
  - train_model.py: synthetic training to produce lightgbm_ranker.pkl.
- smartheal/
  - config.py: paths.
  - embedder.py: singleton loader for SentenceTransformer (offline-first), similarity API.
  - generator.py: candidate generation from DOM/XML + iOS-intent heuristics.
  - ranking.py: ML or heuristic ranking, confidence shaping.
  - repair.py: atomic YAML updates + Allure heal_events.jsonl audit trail.
- tests/
  - common/: base page, waits, actions, device lifecycle, reporting utilities, web helpers/driver factory, env-based test data loader.
  - mobile/: E2E tests for login/dashboard, issues, test plans.
  - web/: page object for login flow and ITP flow.
  - pages/: page objects
- reports/ (generated): allure-results*, allure-report, SmartHeal summaries.
- drivers/ (local chromedriver cache/candidates) and apps/ (bundled .apk/.app).


## 3) SmartHeal Architecture Deep-dive

- ElementEmbedder (smartheal/embedder.py)
  - Loads SentenceTransformer from models/nlp offline (HF_HUB_OFFLINE=1, TRANSFORMERS_OFFLINE=1).
  - encode(text) returns torch tensor; similarity uses cosine similarity.
  - Fails gracefully if model missing, instructing to run scripts/download_model.py.

- CandidateGenerator (smartheal/generator.py)
  - Parses DOM (lxml.html for web; lxml.etree for mobile XML source) and iterates nodes.
  - Computes similarity: model-based cosine OR simple token-overlap fallback.
  - iOS-specific desired control type and required intent keywords to limit false positives.
  - Builds locators by platform: prefers id/accessibility_id; avoids unconstrained iOS XPaths.

- Ranker (smartheal/ranking.py)
  - If ML model unavailable: heuristic confidence shaping with penalties for generic/long XPaths and mismatched id usage.
  - If model available: predict_proba on simple features and sort.

- RepairAgent (smartheal/repair.py)
  - Atomic YAML write (tmp + os.replace) to avoid corruption under xdist.
  - Validates existing keys before update (no surprise keys).
  - Appends heal event to reports/allure-results(/-platform)/heal_events.jsonl and attaches Allure HTML table.

- SmartHealBasePage (tests/common/base_page.py)
  - Platform detection (Selenium vs Appium) and YAML loader per platform/page.
  - find() -> native find with timeouts; on failure triggers _heal_locator(); after heal, retries.
  - iOS guardrails ensuring intent keywords and minimum confidence; fallbacks for critical keys.
  - Utilities: scroll_to_find, tap center, iOS banner close strategies.


## 4) Automation Layers

- Web Layer
  - tests/common/web/driver_factory.py: robust Chrome driver resolution (env, PATH, brew, repository drivers), with fallback to Selenium Manager then webdriver-manager.
  - tests/common/web/helpers.py: robust helpers for frames, shadow DOM, cookie banners, auth options, field discovery, typing, and dashboard validation, designed for flakiness and cross-IdP flows.
  - tests/web/pages/WebLoginPage.py: orchestrates fast-path YAML login then generic helper-based flow, persisting heals on failure, and dashboard validation.
  - tests/web/test_web_login.py & tests/mobile/ITP_Full_Flow.py (web feature): verifies login and a Field → Test Plans navigation scenario.

- Mobile Layer (Android/iOS via Appium)
  - tests/common/device.py: Android fresh install via adb; iOS simulator boot/selection + environment preflight.
  - tests/mobile/pages/MobileLoginPage.py: robust login flow with iOS-specific safe typing, context handling, dropdown selection strategies, and banner handling.
  - tests/mobile/pages/MobileDashboardPage.py: passive stabilization, header validation, non-interactive checks for iOS, and open_test_plans/open_issues.
  - tests/mobile/test_*: parameterized per-platform flows.


## 5) Test Framework and Reporting

- pytest.ini sets markers (mobile, android, ios, web) and Allure output directory.
- tests/conftest.py
  - get_driver(platform): reads platform configs, provisions Android installs / iOS simulator, or creates web driver.
  - Fixture driver yields driver and quits post-test.
  - Hooks add screenshots on failure and create Allure environment metadata + SmartHeal summary (HTML result + console table).
- runner.py
  - Cleans previous allure-results (including platform-specific), seeds history for trend charts, orchestrates appium and pytest, merges results for parallel mode, builds SmartHeal summary HTML, and serves a static HTTP report.


## 6) Configuration and Data

- Environment selection via TARGET_ENV; DataLoader normalizes raw env values (e.g., OCIPL4 → test_data_OCIPL4.yaml).
- web_config.json drives baseUrl and headless mode.
- Android/iOS caps sourced from config; .apk/.app artifacts present under apps/.


## 7) Dependencies (requirements.txt)

- Appium-Python-Client, selenium, pytest, pytest-xdist
- allure-pytest, PyYAML, lxml
- pandas, numpy, scikit-learn, lightgbm, joblib
- sentence-transformers, torch
- webdriver-manager
- FlagEmbedding>=1.2.8 (not directly used in repo code at present)

Observations:
- Torch + sentence-transformers require CPU/GPU runtime readiness; offline model present under models/nlp (OK).
- FlagEmbedding is currently unused; consider removal unless planned.


## 8) Notable Strengths

- Offline-first AI model loading with clear error message and download script.
- Atomic YAML writes with audit trail and Allure integration.
- Heuristic guardrails for iOS to reduce false-positive heals.
- Robust web helpers that handle frames/shadow DOM and common auth variations.
- Runner provides practical ergonomics: parallel mobile run, report server, trend seeding, SmartHeal summary.
- Driver factory prefers local chromedriver before network, honoring repo-provided drivers.


## 9) Identified Risks, Issues, and Inconsistencies

1) ios_config.json platformVersion is invalid
   - Current: "platformVersion": "26.2" (iOS 26.x does not exist). Likely intended 18.2 or similar.
   - Impact: Appium session creation fails for iOS.
   - Action: Update to a valid installed simulator runtime (e.g., 18.2) or let IOSLifecycleManager fill version.

2) runner.py DEFAULT_PLATFORM value is misleading
   - DEFAULT_PLATFORM = "android,ios" does not match control flow that expects 'android' | 'ios' | 'parallel' | 'web'.
   - Impact: Appium won’t start by default; test selection markers not applied.
   - Action: Change to "parallel" (for Android+iOS) or "android" or expose a specific default in CLI usage docs.

3) Credentials in plaintext test data
   - data/test_data/test_data_OCIPL4.yaml stores username/password in repo.
   - Impact: security risk. 
   - Action: externalize secrets to environment variables, CI secrets, or encrypted vault; DataLoader can merge env overrides.

4) FlagEmbedding dependency unused
   - requirements.txt includes FlagEmbedding>=1.2.8 but code doesn’t import it.
   - Action: remove to simplify environment unless planned use.

5) Possible over-reliance on broad XPath fallbacks
   - Some Android/iOS XPaths remain broad; though heuristics penalize them.
   - Action: Continue to prefer a11y ids and constrained predicates; ensure heals don’t degrade to generic //tag.

6) iOS locator YAML includes test-personalized strings
   - e.g., ios/MobileDashboardPage.yaml test_plans_button: "Test Plans-GIRISH", issues_button: "Issues-Girish", scp_banner_close predicate with user-typo.
   - Impact: brittle across environments/users.
   - Action: generalize labels (or predicates) to non-user specific text, or let SmartHeal re-heal to generic identifiers.

7) Web fast-path may click Next/Submit repeatedly across IdP states
   - The code is cautious, but ensure duplicate clicks are idempotent on all IdP variants.
   - Action: consider small guards (e.g., disable double submit via ready-state check) if flakiness observed.

8) Interaction utilities naming
   - tests/common/interaction_utils.py functions take a "driver" which is actually a page-object instance. It works, but naming is confusing.
   - Action: rename parameter to "page" or refactor into methods on SmartHealBasePage for clarity.

9) Allure generate / serve coupling
   - runner.py always opens a server; in CI this might hang.
   - Action: add a flag to skip serve (e.g., --no-serve) for headless CI.

10) Appium plugin selection and base-path
    - Uses --use-plugins execute-driver and /wd/hub base path; ensure plugin installed in all environments or gate by availability.

11) Test stability vs. sleeps
    - Consider increasing use of wait_for_ui_stability over fixed sleeps in MobileLoginPage flows where safe.


## 10) Recommendations and Concrete Improvements

Short-term fixes (High priority):
- Update config/ios_config.json to a valid platformVersion (e.g., 18.2) or remove the field; rely on IOSLifecycleManager to set version dynamically after boot.
- Update runner.py DEFAULT_PLATFORM to "parallel" or "android"; document usage: `python runner.py -p android|ios|parallel|web`.
- Remove FlagEmbedding from requirements.txt if not planned.
- Generalize iOS locator labels: replace personalized/girlish strings with generic equivalents; allow SmartHeal to converge on accessibility ids.

Quality and stability (Mid-term):
- Add environment variable overrides for username/password and merge into DataLoader (env > yaml). Document in README.
- Introduce a CLI flag to skip serving the report in CI (e.g., --no-serve) and only generate.
- Add unit tests for SmartHeal ranking heuristics and generator filters (web & iOS node filtering correctness).
- Expand SmartHeal generator for web to produce more constrained CSS/XPath when ID not present (e.g., role+text, data-testid, aria-label combination).
- Improve iOS candidate guards to explicitly disallow strategies not supported by platform (already disallow id; keep.
- Linting/formatting: add ruff/black pre-commit hooks.

DX/Documentation (Helpful):
- Add README with Quickstart, prerequisites (Appium, Allure, Xcode simulators), and troubleshooting.
- Add Makefile tasks (make android, make ios, make web, make report) to streamline common flows.
- Provide sample .env and document TARGET_ENV, DISABLE_WEB, FAST_WEB, CHROMEDRIVER, WDM_* envs.


## 11) Quickstart / Runbook

Prereqs:
- Python 3.10+
- Allure installed (macOS: `brew install allure`)
- Appium server installed and on PATH (`npm i -g appium`, plugins as needed)
- Xcode + iOS simulators (for iOS), Android SDK/ADB (for Android), Chrome for web

Setup:
- python -m venv .venv && source .venv/bin/activate
- pip install -r requirements.txt
- python scripts/download_model.py  # downloads BAAI/bge-m3 into models/nlp for offline

Run examples:
- Android: `python runner.py -p android -l OCIPL4`
- iOS: `python runner.py -p ios -l OCIPL4`  (ensure ios_config.json is corrected)
- Parallel (Android+iOS): `python runner.py -p parallel -l OCIPL4`
- Web: `python runner.py -p web`

Environment knobs:
- TARGET_ENV (e.g., OCIPL4, OCIPL12, US1UAT) used by DataLoader to pick test_data.
- DISABLE_WEB=1 to skip web tests in generic runs.
- FAST_WEB=1 for quicker ready-state checks.
- CHROMEDRIVER=/path/to/chromedriver to force local driver.

Reports:
- Allure results: reports/allure-results
- Merged (parallel): reports/allure-results (from android/ios results)
- HTML: reports/allure-report (served automatically by runner.py)
- SmartHeal: console table + smartheal-summary.html in report dir and per-run Allure result attachment.


## 12) Noteworthy Code Paths and Defensive Checks

- Atomic YAML write in RepairAgent with fsync best-effort (parallel-safe).
- iOS healing guardrails (_ios_candidate_ok):
  - Strategy validity (disallow id), confidence thresholding, intent keyword matching, predicate checks.
- Web helpers: deep search for inputs across frames/shadow DOM with multiple fallback paths.
- Device management: iOS sim env variables to mitigate Xcode 15+ simulator root issues.


## 13) Final Notes

The project demonstrates a carefully engineered self-healing automation approach with pragmatic guardrails for iOS and robust web flows. Addressing the few configuration and hygiene issues (iOS version, default platform, secrets, unused deps, personalized iOS labels) will further increase reliability and portability across developer machines and CI.


## 14) SmartHeal Enhancement Proposal (Feature-Flagged, Non-Disruptive)

Goal: Improve accuracy, speed, and stability of SmartHeal locator and semantic healing across Android, iOS, and Web without changing existing test flows. All changes are proposed behind feature flags and conservative defaults.

### 14.1 Quick Wins (feature-flagged)
- Early-stop on high confidence
  - Flag: safe_early_stop_conf (default 0.95)
  - Behavior: In _heal_locator, if top candidate confidence >= threshold and live probe succeeds, accept immediately (skip probing others).
- Debounce reverse label healing
  - Flag: debounce_label_ms (default 30000)
  - Behavior: In find reverse-healing, only update semantic_label if last_label_healed is older than the debounce window to avoid oscillations.
- Web accessible-name enrichment (aria-labelledby)
  - Flag: enable_aria_labelledby (default false)
  - Behavior: In CandidateGenerator for Web, resolve aria-labelledby references and include resolved text in description and selector heuristics.

### 14.2 Candidate Generation Refinements
- Web
  - Skip hidden nodes by default in CI (skip_hidden_web=true) to reduce noise.
  - Prefer robust selectors in order: id > name > data-testid/data-test/data-qa (when enable_data_testid_boost) > role+name > visible text with token predicates.
  - Compute accessible name once from aria-label, aria-labelledby, label[for], placeholder, innerText and use for tokens/similarity.
- Android
  - Prefer resource-id first; only use descriptionContains/textContains when android_desc_contains is true and tokens match.
  - Keep token gate: if safe_flag is off and no token present in attributes/text, drop the node early.
- iOS
  - Keep predicate generation constrained by intended control type + 1–2 tokens.
  - Optional fallback to class chain only when predicate alignment exists and token presence is verified.
  - Continue rejecting generic //XCUIElementType* XPaths.

### 14.3 Ranking Improvements (backward compatible)
- Additional features (used only if ML model present):
  - has_data_testid, has_placeholder, has_aria_label, id_entropy (penalize numeric-only ids), locator_length, // hop count, token_jaccard(label vs desc), predicate_strength (#token conditions), prev_strategy_family match.
- Heuristic tuning when ML missing:
  - Increase penalty with locator_length and // hop count for brittle XPaths.
  - Maintain strong boosts for id/accessibility/predicate/automator families; keep safe floors.

### 14.4 Live Probe Gate Upgrades
- Web: scrollIntoView before displayed/enabled checks; if not interactable, retry once after scroll.
- Mobile: allow one small swipe-up before concluding “not interactable” to surface near-offscreen matches.

### 14.5 RepairAgent Safety (probation + rollback)
- Probation mode (optional): persist as proposed_locator with proposed_confidence on first accept. Promote to default_locator after N consecutive successes. On subsequent failure, auto-revert and log a “reverted” event.
- Dry-run mode: log events and attach to Allure without writing YAML (shadow evaluation runs in CI).

### 14.6 Reverse Healing Quality Controls
- Apply debounce window (above) and avoid label updates when difference is only casing/punctuation (already normalized) or mostly dynamic tokens (dates/numbers) when detected.

### 14.7 Platform-specific Guardrails
- Android: prefer UiSelector over XPath for text/desc contains; require token match when not using id/resource-id.
- iOS: keep _ios_candidate_ok guardrails; align with min_confidence_floor; always disallow strategy=id.
- Web: optional CSS generation fallback for stable attributes before XPath.

### 14.8 Performance & Stability
- Continue batch encode_many usage; allow EMBED_CACHE_SIZE override to increase encode cache for large pages.
- Use wait_for_ui_stability and early-stop to reduce probe counts and time.

### 14.9 Observability & Monitoring
- Extend heal_events analysis:
  - Compute acceptance rate, rejected_low_conf counts, strategy distribution, mean confidence by platform/page/key, and time-to-heal.
  - Enhance SmartHeal summary with per-platform tabs and “top noisy keys.”
- Nightly dry-run in CI to compare proposed ranking/generator tweaks without persistence.

### 14.10 Rollout Plan (non-disruptive)
- Phase 1: Enable early-stop, debounce labels, and aria-labelledby resolution behind flags. Dry-run for 2–3 builds and review SmartHeal summary and stats.
- Phase 2: Persist mode for the above if metrics improve. Introduce probation+rollback in RepairAgent (off by default, on in CI first).
- Phase 3: Add ranking features and retrain LightGBM; keep heuristics as fallback.
- Phase 4: Tune per-platform top_k and min_confidence_floor based on collected metrics.

### 14.11 Config Summary (config/smartheal_config.json)
- skip_hidden_web: true (in CI), false locally (optional)
- min_confidence_floor: 0.50 (keep global hard minimum)
- top_k: 10 (reduce later if early-stop proves effective)
- safe_id_floor: 0.92 (keep)
- safe_native_floor: 0.86 (keep)
- post_probe_interactable_gate: true (keep)
- safe_early_stop_conf: 0.95 (use in _heal_locator)
- android_desc_contains: false (use only when needed)
- enable_data_testid_boost: true (recommended for Web)
- enable_aria_labelledby: true (recommended for Web)
- enable_fuzzy_tokens: false (optional future extension)
- debounce_label_ms: 30000 (use for reverse label healing)

Notes: No changes to test flows are required; all logic resides in SmartHeal modules and can be gated by flags. Mobile Android/iOS and Web flows remain intact.
