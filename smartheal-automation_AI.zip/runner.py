import argparse
import pytest
import sys
import os
import subprocess
import time
import signal
import webbrowser
import shutil
import json
from http.server import SimpleHTTPRequestHandler
import socketserver
import logging
import getpass

logging.getLogger("sentence_transformers").setLevel(logging.ERROR)

DEFAULT_PLATFORM = "android,ios"
DEFAULT_LOCATION = "OCIPL4"
DEFAULT_TEST = None


def clean_previous_results():
    base_dir = os.path.join(os.getcwd(), "reports")
    results_dirs = [
        os.path.join(base_dir, "allure-results"),
        os.path.join(base_dir, "allure-results-ios"),
        os.path.join(base_dir, "allure-results-android"),
    ]
    for results_dir in results_dirs:
        if os.path.exists(results_dir):
            print(f"\n Cleaning previous results: {results_dir}")
            for filename in os.listdir(results_dir):
                file_path = os.path.join(results_dir, filename)
                try:
                    if os.path.isfile(file_path) or os.path.islink(file_path):
                        os.unlink(file_path)
                    elif os.path.isdir(file_path):
                        shutil.rmtree(file_path)
                except Exception as e:
                    print(f"    Failed to delete {file_path}. Reason: {e}")
        else:
            os.makedirs(results_dir, exist_ok=True)


def seed_history_for_trend():
    try:
        base = os.getcwd()
        prev_history = os.path.join(base, "reports", "allure-report", "history")
        dest_dir = os.path.join(base, "reports", "allure-results", "history")
        if os.path.isdir(prev_history):
            os.makedirs(os.path.dirname(dest_dir), exist_ok=True)
            try:
                shutil.copytree(prev_history, dest_dir, dirs_exist_ok=True)
            except TypeError:
                if not os.path.exists(dest_dir):
                    shutil.copytree(prev_history, dest_dir)
                else:
                    for root, dirs, files in os.walk(prev_history):
                        rel = os.path.relpath(root, prev_history)
                        target_root = os.path.join(dest_dir, rel) if rel != "." else dest_dir
                        os.makedirs(target_root, exist_ok=True)
                        for fn in files:
                            shutil.copy2(os.path.join(root, fn), os.path.join(target_root, fn))
    except Exception as e:
        print(f" Failed to seed history: {e}")


def start_appium(port=4723):
    print(f"Starting Appium on {port}...")
    env = os.environ.copy()
    try:
        xcode_dir = subprocess.run(["xcode-select", "-p"], capture_output=True, text=True, check=False).stdout.strip()
        if xcode_dir:
            env["DEVELOPER_DIR"] = xcode_dir
            xcode_usr_bin = os.path.join(xcode_dir, "usr", "bin")
            if xcode_usr_bin and xcode_usr_bin not in env.get("PATH", ""):
                env["PATH"] = f"{xcode_usr_bin}:{env.get('PATH', '')}"
        platform_root = os.path.join(xcode_dir, "Platforms", "iPhoneSimulator.platform")
        if os.path.isdir(platform_root):
            env["IPHONE_SIMULATOR_ROOT"] = platform_root
            env["SIMCTL_CHILD_IPHONE_SIMULATOR_ROOT"] = platform_root
        sim_sdk = subprocess.run(["xcrun", "--sdk", "iphonesimulator", "--show-sdk-path"], capture_output=True,
                                 text=True, check=False).stdout.strip()
        if sim_sdk:
            env["SDKROOT"] = sim_sdk
        env["OBJC_DISABLE_INITIALIZE_FORK_SAFETY"] = "YES"
    except Exception as e:
        print(f"iOS env preflight skipped: {e}")

    process = subprocess.Popen(
        ["appium", "-p", str(port), "--address", "127.0.0.1", "--base-path", "/wd/hub", "--use-plugins",
         "execute-driver"],
        stdout=subprocess.DEVNULL,
        stderr=subprocess.DEVNULL,
        preexec_fn=os.setsid,
        env=env
    )
    time.sleep(10)
    return process


def serve_report(report_dir, port=0):
    class Handler(SimpleHTTPRequestHandler):
        def log_message(self, format, *args): pass

    os.chdir(report_dir)
    with socketserver.TCPServer(("", port), Handler) as httpd:
        actual_port = httpd.server_address[1]
        url = f"http://localhost:{actual_port}"
        print(f"\n Serving Report at: {url}")
        print("   (Press Ctrl+C to stop the server and exit)")
        try:
            if os.path.exists("smartheal-summary.html"):
                print(f"   SmartHeal Summary: {url}/smartheal-summary.html")
        except Exception:
            pass
        webbrowser.open(url)
        try:
            httpd.serve_forever()
        except KeyboardInterrupt:
            print("\n Stopping Report Server...")
            httpd.shutdown()


def _build_smartheal_summary(results_dir, report_dir):
    try:
        os.makedirs(report_dir, exist_ok=True)
        rows = []
        seen = set()

        def process_dir(d):
            if not os.path.exists(d): return
            for name in os.listdir(d):
                if not name.startswith("heal_events") or not name.endswith(".jsonl"):
                    continue
                p = os.path.join(d, name)
                try:
                    with open(p, "r", encoding="utf-8") as f:
                        for line in f:
                            line = (line or "").strip()
                            if not line: continue
                            try:
                                ev = json.loads(line)
                                key = (ev.get("ts"), ev.get("platform"), ev.get("page"), ev.get("key"),
                                       ev.get("new_locator"))
                                if key not in seen:
                                    seen.add(key)
                                    rows.append(ev)
                            except Exception:
                                continue
                except Exception:
                    continue

        process_dir(results_dir)
        base = os.path.dirname(results_dir)
        for sub in ("allure-results-android", "allure-results-ios", "allure-results-web"):
            process_dir(os.path.join(base, sub))

        html = []
        html.append("<!DOCTYPE html><html><head><meta charset='utf-8'><title>SmartHeal Summary</title>")
        html.append(
            "<style>body{font-family:Arial,sans-serif;padding:16px;} table{border-collapse:collapse;width:100%;} th,td{border:1px solid #ddd;padding:8px;font-size:13px;} th{background:#f4f4f4;} .muted{color:#666}</style></head><body>")
        html.append("<h2>SmartHeal - Locator & Label Updates</h2>")
        html.append(f"<p class='muted'>Total updates: {len(rows)}</p>")
        if rows:
            # UPDATED HEADERS
            html.append(
                "<table><thead><tr><th>Time</th><th>Platform</th><th>Page</th><th>Key</th><th>Old Strategy</th><th>Old Value</th><th>New Strategy</th><th>New Value</th><th>Confidence</th></tr></thead><tbody>")
            for ev in rows:
                conf = ev.get('confidence', '')
                try:
                    conf_str = f"{float(conf):.4f}"
                except Exception:
                    conf_str = str(conf)

                row_style = ""
                if ev.get("strategy") == "LABEL_UPDATE":
                    row_style = "style='background-color:#e6f7ff'"

                html.append(
                    f"<tr {row_style}><td>{ev.get('ts', '')}</td><td>{ev.get('platform', '')}</td><td>{ev.get('page', '')}</td><td>{ev.get('key', '')}</td><td>{ev.get('old_strategy', '')}</td><td>{(ev.get('old_locator') or '')}</td><td>{ev.get('new_strategy', '')}</td><td>{ev.get('new_locator', '')}</td><td>{conf_str}</td></tr>")
            html.append("</tbody></table>")
        else:
            html.append("<p>No healing events recorded in this run.</p>")
        html.append("</body></html>")
        with open(os.path.join(report_dir, "smartheal-summary.html"), "w", encoding="utf-8") as outf:
            outf.write("\n".join(html))
        print(f"📄 SmartHeal summary generated at: {os.path.join(report_dir, 'smartheal-summary.html')}")
    except Exception as e:
        print(f"  Failed to build SmartHeal summary: {e}")


def _detect_platforms_from_results_dir(results_dir: str):
    plats = set()
    try:
        if os.path.isdir(results_dir):
            for fname in os.listdir(results_dir):
                if not fname.endswith(".json"): continue
                try:
                    with open(os.path.join(results_dir, fname), "r", encoding="utf-8") as f:
                        obj = json.load(f)
                    for lab in obj.get("labels", []):
                        if lab.get("name") == "tag" and lab.get("value") in ("android", "ios", "web"):
                            plats.add(lab["value"])
                except Exception:
                    continue
        base = os.path.dirname(results_dir)
        for sub in ("allure-results-android", "allure-results-ios", "allure-results-web"):
            alt = os.path.join(base, sub)
            if not os.path.isdir(alt): continue
            try:
                for fname in os.listdir(alt):
                    if not fname.endswith(".json"): continue
                    try:
                        with open(os.path.join(alt, fname), "r", encoding="utf-8") as f:
                            obj = json.load(f)
                        for lab in obj.get("labels", []):
                            if lab.get("name") == "tag" and lab.get("value") in ("android", "ios", "web"):
                                plats.add(lab["value"])
                    except Exception:
                        continue
            except Exception:
                continue
    except Exception:
        pass
    return plats


def _platform_string(plats):
    names = []
    if "android" in plats: names.append("Android")
    if "ios" in plats: names.append("iOS")
    if "web" in plats: names.append("Web")
    if not names: return ""
    if len(names) == 2: return " & ".join(names)
    return ", ".join(names) if len(names) > 1 else names[0]


def _resolve_executor_name_local():
    try:
        user = os.environ.get("USER") or os.environ.get("LOGNAME") or getpass.getuser()
    except Exception:
        user = None
    return "Girish Satyam" if user == "gsatyam" else (user or "Unknown")


def _rewrite_environment_properties(results_dir: str):
    try:
        existing = {}
        env_file = os.path.join(results_dir, "environment.properties")
        if os.path.isfile(env_file):
            try:
                with open(env_file, "r", encoding="utf-8") as ef:
                    for line in ef:
                        line = (line or "").strip()
                        if not line or "=" not in line: continue
                        k, v = line.split("=", 1)
                        existing[k.strip()] = v.strip()
            except Exception:
                pass

        for legacy in ("Target Environment", "Target Platform", "Target"):
            if legacy in existing: existing.pop(legacy, None)

        plats = _detect_platforms_from_results_dir(results_dir)
        try:
            rp = (os.environ.get("RUN_PLATFORMS") or "").strip().lower()
            if rp:
                declared = set(
                    p.strip() for p in rp.replace(",", " ").split() if p.strip() in ("android", "ios", "web"))
                plats = set(plats) | declared
        except Exception:
            pass
        plat_value = _platform_string(plats)
        target_env = os.environ.get("TARGET_ENV", "")
        executor = _resolve_executor_name_local()

        if plat_value: existing["Platform"] = plat_value
        if target_env: existing["Server"] = target_env
        if executor: existing["Executor"] = executor

        if existing:
            os.makedirs(results_dir, exist_ok=True)
            with open(env_file, "w", encoding="utf-8") as f:
                for k, v in existing.items():
                    f.write(f"{k}={v}\n")
    except Exception:
        pass


def generate_and_open_report():
    print("\n" + "=" * 50)
    print(" GENERATING ALLURE HTML REPORT")
    print("=" * 50)

    original_cwd = os.getcwd()
    report_dir = os.path.join(original_cwd, "reports", "allure-report")
    results_dir = os.path.join(original_cwd, "reports", "allure-results")

    try:
        try:
            _rewrite_environment_properties(results_dir)
        except Exception:
            pass
        subprocess.run(
            ["allure", "generate", results_dir, "-o", report_dir, "--clean"],
            check=True, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL
        )

        index_path = os.path.join(report_dir, "index.html")
        print(f"✅ Report Generated: {index_path}")

        _build_smartheal_summary(results_dir, report_dir)

        print("\n Starting Local Web Server to view report...")
        serve_report(report_dir)

    except FileNotFoundError:
        print("  'allure' command not found. Please run 'brew install allure'.")
    except Exception as e:
        print(f"  Failed to generate report: {e}")
    finally:
        if os.getcwd() != original_cwd:
            os.chdir(original_cwd)


def merge_allure_results(src_dirs, dst_dir):
    os.makedirs(dst_dir, exist_ok=True)
    for src_dir in src_dirs:
        if os.path.exists(src_dir):
            for file in os.listdir(src_dir):
                src_file = os.path.join(src_dir, file)
                dst_file = os.path.join(dst_dir, file)
                if not os.path.exists(dst_file):
                    shutil.copy2(src_file, dst_file)
                else:
                    base, ext = os.path.splitext(file)
                    new_filename = f"{base}_{os.path.basename(src_dir)}{ext}"
                    shutil.copy2(src_file, os.path.join(dst_dir, new_filename))


def main():
    sys.path.append(os.getcwd())
    clean_previous_results()
    seed_history_for_trend()

    parser = argparse.ArgumentParser()
    parser.add_argument("-p", "--platform", default=DEFAULT_PLATFORM, help="android | ios | parallel | web")
    parser.add_argument("-l", "--location", default=DEFAULT_LOCATION, help="PL12, OCIPL4, US1UAT")
    parser.add_argument("-t", "--test", default=DEFAULT_TEST, help="Path to specific test")
    parser.add_argument("-n", "--workers", default="auto", help="Workers for parallel execution")
    args = parser.parse_args()

    try:
        args.platform = (args.platform or "").strip().lower()
    except Exception:
        pass

    raw_env = (args.location or "").strip()
    derived = raw_env.upper()
    try:
        if "US1UAT" in derived:
            derived = "US1UAT"
        elif "PL" in derived or "OCIPL" in derived:
            import re as _re
            m = _re.search(r'(\d+)', derived)
            if m: derived = f"OCIPL{int(m.group(1))}"
    except Exception:
        pass
    os.environ['TARGET_ENV'] = derived
    print(f"Target Environment: {derived} (from '{raw_env}')")

    try:
        if args.platform == 'parallel':
            os.environ['RUN_PLATFORMS'] = 'android,ios'
        elif args.platform in ('android', 'ios', 'web'):
            os.environ['RUN_PLATFORMS'] = args.platform
        else:
            os.environ.pop('RUN_PLATFORMS', None)
    except Exception:
        pass

    if args.platform == 'web':
        os.environ['FAST_WEB'] = os.environ.get('FAST_WEB', '1') or '1'
        try:
            cd_candidates = [
                "/opt/homebrew/bin/chromedriver",
                "/usr/local/bin/chromedriver",
                "/usr/bin/chromedriver",
            ]
            for p in cd_candidates:
                if os.path.exists(p) and os.access(p, os.X_OK):
                    os.environ.setdefault("CHROMEDRIVER", p)
                    break
        except Exception:
            pass
        cache_dir = os.path.join(os.getcwd(), ".wdm_cache")
        os.environ['WDM_CACHE_DIR'] = os.environ.get('WDM_CACHE_DIR', cache_dir)
        os.environ['WDM_LOCAL'] = os.environ.get('WDM_LOCAL', '0') or '0'
        os.environ['WDM_OFFLINE'] = os.environ.get('WDM_OFFLINE', '0') or '0'
        os.environ['WDM_SSL_VERIFY'] = os.environ.get('WDM_SSL_VERIFY', '0') or '0'
        os.environ.setdefault('ALLOW_CFT_DOWNLOAD', '1')
        os.environ.setdefault('ALLOW_SELENIUM_MANAGER', '1')
        os.environ.setdefault('SE_OFFLINE', '1')
        print("FAST_WEB mode enabled for web.")

    appium_proc = None
    if args.platform in ['android', 'ios', 'parallel', 'mobile']:
        appium_proc = start_appium(4723)

    if args.platform == 'parallel':
        # Run the same mobile test selection twice with platform-specific env,
        # instead of relying on pytest markers (tests are not marked per-platform).
        test_target = args.test if args.test else os.path.join('tests', 'mobile')

        # NOTE:
        # Using "-k" selection by param id instead of marker selection.
        # Recent pytest versions may not apply parameter-set markers early enough
        # for "-m" selection to pick them up, leading to zero iOS collection.
        # Our tests parametrize with id="android"/"ios", so "-k android"/"-k ios"
        # reliably selects the respective cases without touching test flow.
        android_cmd = [
            sys.executable, '-m', 'pytest', '-q', '-n', '1',
            '-k', 'android',
            f'--alluredir=reports/allure-results-android',
            test_target
        ]
        ios_cmd = [
            sys.executable, '-m', 'pytest', '-q', '-n', '1',
            '-k', 'ios',
            f'--alluredir=reports/allure-results-ios',
            test_target
        ]

        # Ensure each subprocess gets the right platform via env (used by conftest fixtures)
        env_android = os.environ.copy()
        env_android['TEST_PLATFORM'] = 'android'
        env_android['PLATFORM'] = 'android'
        env_android['RUN_PLATFORMS'] = 'android,ios'
        # Disable any accidental web collection if paths include broader scopes
        env_android.setdefault('DISABLE_WEB', '1')

        env_ios = os.environ.copy()
        env_ios['TEST_PLATFORM'] = 'ios'
        env_ios['PLATFORM'] = 'ios'
        env_ios['RUN_PLATFORMS'] = 'android,ios'
        env_ios.setdefault('DISABLE_WEB', '1')

        # Run sequentially to avoid iOS instability under concurrent load
        print("Starting Android tests (phase 1/2)...")
        android_exit = subprocess.call(android_cmd, env=env_android)
        print("Android phase complete with exit code:", android_exit)
        print("Starting iOS tests (phase 2/2)...")
        ios_exit = subprocess.call(ios_cmd, env=env_ios)
        print("iOS phase complete with exit code:", ios_exit)

        merge_allure_results(['reports/allure-results-android', 'reports/allure-results-ios'], 'reports/allure-results')
        try:
            _rewrite_environment_properties(os.path.join(os.getcwd(), 'reports', 'allure-results'))
        except Exception:
            pass
        generate_and_open_report()

        if android_exit != 0 or ios_exit != 0:
            print("One or more platform test runs failed.")
            sys.exit(1)
        sys.exit(0)

    pytest_args = ["--alluredir=reports/allure-results"]
    if args.platform == 'web':
        pytest_args.append("-m web")
    elif args.platform == 'android':
        pytest_args.append("-m android")
    elif args.platform == 'ios':
        pytest_args.append("-m ios")
    if args.test: pytest_args.append(args.test)

    print(f"Executing: pytest {' '.join(pytest_args)}")

    try:
        ret = pytest.main(pytest_args)
    finally:
        if appium_proc:
            print("Stopping Appium...")
            try:
                os.killpg(os.getpgid(appium_proc.pid), signal.SIGTERM)
            except:
                pass
        try:
            _rewrite_environment_properties(os.path.join(os.getcwd(), 'reports', 'allure-results'))
        except Exception:
            pass
        generate_and_open_report()

    sys.exit(ret)


if __name__ == "__main__":
    main()