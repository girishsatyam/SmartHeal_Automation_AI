from weakref import finalize

from tests.common.base_page import SmartHealBasePage
from tests.common.data_loader import DataLoader
from tests.common.utils import drag_form_up, click_long_press_and_drag_up, swipe_element_up, get_current_timestamp


#from tests.common.utils import drag_form_up


class MobileDocumentsPage(SmartHealBasePage):
    def __init__(self, driver):
        super().__init__(driver)
        self.test_data = DataLoader.get_data()

    #upload documents
    def upload_document(self):
        # print(f"driver type: {type(self.driver)}")  # Should be Appium/Selenium WebDriver
        # print(f"element type: {type(self.find('add_document_button'))}")  # Should be WebElement

        self.click_on_element('add_document_button')
        self.click_on_element('document_skip_button')
        self.click_on_element('document_type_dropdown')
        self.click_on_element('document_type_selection')
        if self.platform == 'ios':
            swipe_element_up(self.driver, self.find('document_form'))
            self.click_on_element('document_auto_number')
        #click_long_press_and_drag_up(self,'document_form')
        #swipe_element_up(self.driver,'document_form')
        self.send_keys_to_element('document_revision',"A1")
        self.send_keys_to_element('document_title',f"{self.test_data.get('description','')}{get_current_timestamp()}")
        self.click_on_element('document_status_button')
        self.click_on_element('document_status_selection')
        self.click_on_element('document_discipline_button')
        self.click_on_element('document_discipline_selection')
        self.click_on_element('document_category_button')
        self.click_on_element('document_category_selection')
        self.click_on_element('document_upload_button')
        return
