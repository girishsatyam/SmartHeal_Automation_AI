from tests.common.base_page import SmartHealBasePage
from tests.common.data_loader import DataLoader
from tests.common.utils import random_5_digit_number, get_current_timestamp


class MobileIssuesPage(SmartHealBasePage):
    def __init__(self, driver):
        super().__init__(driver)
        self.test_data = DataLoader.get_data()

    #function to create issues
    def create_issues(self,attachments):
        #create an issue without any custom fields and attachments
        self.click_on_element('add_issue_button')
        self.click_on_element('issue_type_dropdown')
        self.click_on_element('issue_type_selection')
        self.click_on_element('issue_description')
        #add text
        #click_on_element(self, 'issue_description_text')
        self.send_keys_to_element('issue_description_text', f"{self.test_data.get('description','')}{get_current_timestamp()}"
)
        self.click_on_element('issue_description_done')
        self.click_on_element('more_issues')

        if attachments:
            print("Add Attachments")
            self.click_on_element('add_issue_attachment_button')
            self.click_on_element('choose_photo_button')

            self.accept_permission()

            self.click_on_element('select_photo1_button')
            self.click_on_element('select_photo2_button')
            self.click_on_element('add_photo_button')
            self.click_on_element('back_btn_issue_attachment')
        else:
            print("No Attachments")

        self.click_on_element('save_issue_button')

    def accept_permission(self):
        if self.platform == 'android':
            # Attempt each permission button as optional (won't fail if not present)
            for elem in ['photo_permission1', 'photo_permission2', 'photo_permission3']:
                self.click_on_element(elem, optional=True)