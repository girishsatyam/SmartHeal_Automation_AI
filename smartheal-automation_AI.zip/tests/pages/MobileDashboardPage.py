from tests.common.base_page import SmartHealBasePage
from tests.common.data_loader import DataLoader
from appium.webdriver.common.appiumby import AppiumBy
import time
from tests.common.waits import sleep_with_reason
from tests.common.constants import DEFAULT_PROJECT_NAME
from tests.common.actions import open_test_plans as common_open_test_plans, open_issues, open_documents


class MobileDashboardPage(SmartHealBasePage):
    def __init__(self, driver):
        super().__init__(driver)
        self.test_data = DataLoader.get_data()

    # iOS-only: ensure banner is closed and dashboard header visible
    def _ensure_banner_closed_ios(self, timeout=12):
        end = time.time() + timeout
        while time.time() < end:
            try:
                el = self._find_banner_close_ios()
                if el:
                    try:
                        el.click()
                    except Exception:
                        try:
                            self._tap_element_center(el)
                        except Exception:
                            pass
                    time.sleep(0.4)
                    try:
                        if not self._find_banner_close_ios():
                            return True
                    except Exception:
                        return True
                else:
                    return True
            except Exception:
                pass
            # Top-right tap fallback (common 'X')
            try:
                size = self.driver.get_window_size()
                self.driver.execute_script("mobile: tap", {"x": int(size["width"] * 0.92), "y": int(size["height"] * 0.08)})
            except Exception:
                pass
            time.sleep(0.5)
        return False

    def _wait_for_dashboard_header_ios(self, expected_title, timeout=8):
        end = time.time() + timeout
        while time.time() < end:
            try:
                # Known header IDs
                esc = self._ios_escape_pred_text(expected_title)
                for aid in ("ProjectTitle", "ProjectTitleHeader"):
                    try:
                        el = self.driver.find_element(AppiumBy.ACCESSIBILITY_ID, aid)
                        if el and self._is_visible(el):
                            return True
                    except Exception:
                        continue
                # Fallback: StaticText matching expected title (exact), then contains
                try:
                    el2 = self.driver.find_element(
                        AppiumBy.IOS_PREDICATE,
                        f'type == "XCUIElementTypeStaticText" AND (name == "{esc}" OR label == "{esc}")'
                    )
                    if el2 and self._is_visible(el2):
                        return True
                except Exception:
                    pass
                try:
                    el3 = self.driver.find_element(
                        AppiumBy.IOS_PREDICATE,
                        f'type == "XCUIElementTypeStaticText" AND (name CONTAINS[c] "{esc}" OR label CONTAINS[c] "{esc}")'
                    )
                    if el3 and self._is_visible(el3):
                        return True
                except Exception:
                    pass
            except Exception:
                pass
            # Passive wait to avoid accidental interactions on tabs
            time.sleep(0.5)
        return False

    def _is_visible(self, el):
        try:
            return bool(el.is_displayed())
        except Exception:
            try:
                r = getattr(el, "rect", {}) or {}
                return r.get("width", 0) > 0 and r.get("height", 0) > 0
            except Exception:
                return True

    # iOS: non-interactive presence check to avoid accidental taps (especially on tab bar)
    def _find_profile_tab_ios_noninteractive(self, timeout=4):
        end = time.time() + timeout
        while time.time() < end:
            try:
                el = self.driver.find_element(AppiumBy.ACCESSIBILITY_ID, "Profile")
                if el and self._is_visible(el):
                    return el
            except Exception:
                pass
            try:
                el = self.driver.find_element(
                    AppiumBy.IOS_PREDICATE,
                    "type IN {'XCUIElementTypeButton','XCUIElementTypeImage','XCUIElementTypeOther'} AND (name CONTAINS[c] 'Profile' OR label CONTAINS[c] 'Profile')"
                )
                if el and self._is_visible(el):
                    return el
            except Exception:
                pass
            time.sleep(0.3)
        return None

    def _ios_escape_pred_text(self, s):
        try:
            return str(s).replace('"', '\\"')
        except Exception:
            return str(s)

    def _ios_title_present(self, expected_title, timeout=8):
        end = time.time() + timeout
        while time.time() < end:
            esc = self._ios_escape_pred_text(expected_title)
            try:
                if self.driver.find_elements(AppiumBy.ACCESSIBILITY_ID, expected_title):
                    return True
            except Exception:
                pass
            for aid in ("ProjectTitle", "ProjectTitleHeader"):
                try:
                    el = self.driver.find_element(AppiumBy.ACCESSIBILITY_ID, aid)
                    if el and self._is_visible(el):
                        return True
                except Exception:
                    continue
            try:
                # Navigation bar name/label often carries the title
                if self.driver.find_elements(
                    AppiumBy.IOS_PREDICATE,
                    f'type == "XCUIElementTypeNavigationBar" AND (name CONTAINS[c] "{esc}" OR label CONTAINS[c] "{esc}")'
                ):
                    return True
            except Exception:
                pass
            try:
                # Any visible element near the top with matching text
                if self.driver.find_elements(
                    AppiumBy.IOS_PREDICATE,
                    f'type IN {{"XCUIElementTypeStaticText","XCUIElementTypeButton","XCUIElementTypeOther"}} AND (name CONTAINS[c] "{esc}" OR label CONTAINS[c] "{esc}" OR value CONTAINS[c] "{esc}")'
                ):
                    return True
            except Exception:
                pass
            try:
                size = self.driver.get_window_size()
                top_y = int(size.get("height", 800) * 0.22)
                elems = self.driver.find_elements(AppiumBy.IOS_PREDICATE, "type == 'XCUIElementTypeStaticText'") or []
                for el in elems:
                    try:
                        r = getattr(el, "rect", {}) or {}
                        cy = r.get("y", 9999) + r.get("height", 0) / 2
                        if cy <= top_y:
                            nm = el.get_attribute("name") or el.get_attribute("label") or el.get_attribute("value") or ""
                            if nm and expected_title.lower() in str(nm).lower():
                                return True
                    except Exception:
                        continue
            except Exception:
                pass
            time.sleep(0.4)
        # Last-resort: page source text contains expected title (case-insensitive)
        try:
            ps = self.driver.page_source or ""
            if expected_title.lower() in ps.lower():
                return True
        except Exception:
            pass
        return False

    def _get_expected_project_title(self):
        try:
            td = self.test_data or {}
        except Exception:
            td = {}
        return td.get('projectName') or td.get('projectSelected') or td.get('projLoc') or DEFAULT_PROJECT_NAME

    # iOS: pre-validation menu tap to stabilize dashboard (no scrolling/tapping near tab bar)
    def _tap_menu_button_pre_validation_ios(self):
        try:
            # 1) YAML-based 'menu_button' if defined
            try:
                el = self.find("menu_button", timeout=2, optional=True)
            except Exception:
                el = None
            if el and self._is_visible(el):
                try:
                    el.click()
                except Exception:
                    self._tap_element_center(el)
                time.sleep(0.5)
                return True
            # 2) Common accessibility ids
            for aid in ("Menu", "menu", "More", "more", "Options", "options"):
                try:
                    el = self.driver.find_element(AppiumBy.ACCESSIBILITY_ID, aid)
                    if el and self._is_visible(el):
                        try:
                            el.click()
                        except Exception:
                            self._tap_element_center(el)
                        time.sleep(0.5)
                        return True
                except Exception:
                    continue
            # 3) Predicate: nav bar button containing Menu/More/Options
            try:
                el = self.driver.find_element(
                    AppiumBy.IOS_PREDICATE,
                    "type == 'XCUIElementTypeButton' AND (name CONTAINS[c] 'Menu' OR label CONTAINS[c] 'Menu' OR name CONTAINS[c] 'More' OR label CONTAINS[c] 'More' OR name CONTAINS[c] 'Options' OR label CONTAINS[c] 'Options')"
                )
                if el and self._is_visible(el):
                    try:
                        el.click()
                    except Exception:
                        self._tap_element_center(el)
                    time.sleep(0.5)
                    return True
            except Exception:
                pass
        except Exception:
            pass
        return False

    def validate_full_dashboard(self):
        print("\n[DASHBOARD] Starting Validation of 5 Key Elements...")

        # iOS safety: ensure any landing banner is dismissed before validating
        if self.platform == 'ios':
            try:
                # self._ensure_banner_closed_ios(timeout=12)
                expected_title_tmp = self._get_expected_project_title()
                self._wait_for_dashboard_header_ios(expected_title_tmp, timeout=8)
            except Exception:
                pass

            # iOS step: Passive stabilization wait (5s) before validations; do not tap anywhere on dashboard
            sleep_with_reason(5, "iOS dashboard stabilization before validations")

            # iOS pre-validation: tap Menu button if present
            try:
                self._tap_menu_button_pre_validation_ios()
            except Exception:
                pass

        # 1. SPECIAL CHECK: Verify Dynamic Project Title
        # We check specifically for the text "AcxQASanity" (or whatever is in data)
        expected_title = self._get_expected_project_title()
        print(f"   🔍 Checking for Project Title: '{expected_title}'...")

        try:
            if self.platform == 'android':
                # Dynamic XPath to find the specific Project Name text
                title_xpath = f"//*[contains(@text, '{expected_title}')]"
                self.driver.find_element(AppiumBy.XPATH, title_xpath)
            else:
                if not self._ios_title_present(expected_title, timeout=8):
                    raise Exception(f"iOS dashboard title not detected. Expected '{expected_title}'")

            print(f"      ✅ Verified: Project Title '{expected_title}' is present.")

        except Exception:
            print(f"      ❌ Missing: Project Title '{expected_title}' NOT found.")
            raise Exception(f"Dashboard Validation Failed: Header '{expected_title}' missing.")

        # 2. STANDARD CHECKS: Verify Static Buttons/Tabs
        # We removed 'project_title' from this list since we checked it dynamically above
        validation_checklist = [
            "mail_button",  # ✅ Verify 'Mail' Button
            "home_tab",  # ✅ Verify 'Home' Tab
            "tasks_tab",  # ✅ Verify 'Tasks' Tab
            "profile_tab"  # ✅ Verify 'Profile' Tab
        ]

        failures = []

        for element_key in validation_checklist:
            print(f"   🔍 Checking for: {element_key}...")

            # Use Smart Scroll to find the element by default.
            # On iOS, for 'profile_tab' specifically, avoid any scroll/taps; perform non-interactive presence check.
            if self.platform == 'ios' and element_key == 'profile_tab':
                found_element = self._find_profile_tab_ios_noninteractive(timeout=4)
            else:
                found_element = self.scroll_to_find(element_key)

            is_ok = bool(found_element)
            if is_ok and self.platform == 'ios':
                try:
                    is_ok = self._is_visible(found_element) and (getattr(found_element, "is_enabled", lambda: True)())
                except Exception:
                    pass

            if is_ok:
                print(f"      ✅ Verified: {element_key} is present.")
            else:
                print(f"      ❌ Missing/Invisible: {element_key} NOT interactable or not found.")
                failures.append(element_key)

        if failures:
            raise Exception(f"Dashboard Validation Failed! Missing elements: {failures}")
        else:
            print("[DASHBOARD] All Validations Passed Successfully! 🚀")

    def open_test_plans(self):
        return common_open_test_plans(self)

    def open_issues(self):
        return open_issues(self)

    def open_documents(self):
        return open_documents(self)
