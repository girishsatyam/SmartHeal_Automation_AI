from tests.common.base_page import SmartHealBasePage
from tests.common.data_loader import DataLoader
from appium.webdriver.common.appiumby import AppiumBy
import time
from tests.common.constants import DEFAULT_PROJECT_NAME, IOS_CLOSE_NAMES
from tests.common.waits import wait_and_select_project as wait_and_select_project_common
from tests.common.waits import smart_wait


class MobileLoginPage(SmartHealBasePage):
    def __init__(self, driver):
        super().__init__(driver)
        self.test_data = DataLoader.get_data()

    def _switch_to_webview_if_present(self, timeout=15):
        if self.platform != 'ios':
            return False
        print("Checking for WEBVIEW context...")
        end = time.time() + timeout
        last_contexts = []
        while time.time() < end:
            try:
                ctxs = self.driver.contexts
                last_contexts = ctxs
                webviews = [c for c in ctxs if 'WEBVIEW' in c.upper()]
                if webviews:
                    target = webviews[0]
                    print(f"Switching to context: {target}")
                    self.driver.switch_to.context(target)
                    return True
            except Exception:
                pass
            smart_wait(self.driver, mode="sleep", timeout=0.5, reason="poll for WEBVIEW context")
        print(f"No WEBVIEW context found. Contexts: {last_contexts}")
        return False

    def _switch_to_native(self):
        try:
            self.driver.switch_to.context('NATIVE_APP')
            print("Switched back to NATIVE_APP context.")
        except Exception:
            pass

    def _wait_for_login_inputs(self, timeout=10):
        if self.platform != 'ios':
            return True
        print("Waiting for iOS login input fields...")
        end = time.time() + timeout
        while time.time() < end:
            try:
                # Any TextField or SecureTextField should be present on the Aconex auth screen
                tf = self.driver.find_elements(AppiumBy.IOS_PREDICATE, "type == 'XCUIElementTypeTextField'")
                pf = self.driver.find_elements(AppiumBy.IOS_PREDICATE, "type == 'XCUIElementTypeSecureTextField'")
                if tf or pf:
                    print("Detected login inputs on screen.")
                    return True
            except Exception:
                pass
            smart_wait(self.driver, mode="sleep", timeout=0.5, reason="poll for iOS login inputs")
        print("Login inputs not detected yet.")
        return False

    def _swipe_up_small(self):
        try:
            size = self.driver.get_window_size()
            start_x = size['width'] * 0.5
            if self.platform == 'ios':
                start_y = size['height'] * 0.65
                end_y = size['height'] * 0.25
            else:
                start_y = size['height'] * 0.75
                end_y = size['height'] * 0.25
            self.driver.swipe(start_x, start_y, start_x, end_y, 500)
            smart_wait(self.driver, mode="sleep", timeout=0.5, reason="post small swipe settle")
        except Exception:
            pass

    def _type_on_element(self, el, text):
        """
        Robustly types into a field avoiding duplicate/extra characters on iOS.
        - iOS: prefer clear + set_value, fallback to mobile: setValue or send_keys
        - Android/Web: clear + send_keys
        """
        try:
            el.click()
        except Exception:
            pass

        if self.platform == 'ios':
            try:
                el.clear()
                smart_wait(self.driver, mode="sleep", timeout=0.2, reason="post clear settle (iOS)")
            except Exception:
                pass
            try:
                # set_value is more reliable for iOS XCUI elements (esp. SecureTextField)
                el.set_value(text)
                return
            except Exception:
                try:
                    # Fallback to execute_script if supported by driver
                    self.driver.execute_script("mobile: setValue", {"elementId": el.id, "value": text})
                    return
                except Exception:
                    el.send_keys(text)
        else:
            try:
                el.clear()
                smart_wait(self.driver, mode="sleep", timeout=0.1, reason="post clear settle")
            except Exception:
                pass
            el.send_keys(text)

    def _hide_keyboard_if_visible(self):
        try:
            self.driver.hide_keyboard()
            smart_wait(self.driver, mode="sleep", timeout=0.3, reason="post hide_keyboard settle")
            return
        except Exception:
            pass
        # Try common iOS buttons if hide_keyboard fails
        for acc in ("Done", "Return", "Hide keyboard", "Hide Keyboard"):
            try:
                self.driver.find_element(AppiumBy.ACCESSIBILITY_ID, acc).click()
                smart_wait(self.driver, mode="sleep", timeout=0.2, reason=f"post keyboard dismiss tap: {acc}")
                return
            except Exception:
                continue

    def _validate_and_fix_secure_text(self, el, expected):
        """
        Validate the length of a secure text input and correct if extra characters were entered.
        Uses the value attribute which returns bullets on iOS.
        """
        try:
            val = el.get_attribute("value") or ""
            norm = str(val).strip()
            # iOS secure fields often return bullets '•' per character or a static label when empty
            bullet_char = "•"
            # Only attempt validation when we get some value back
            if norm and norm.lower() not in ("secure text field", "secure text entry", "password"):
                entered_len = len(norm)
                if all(c == bullet_char for c in norm):
                    entered_len = len(norm)
                if entered_len != len(expected):
                    # Re-enter exactly
                    try:
                        el.clear()
                        smart_wait(self.driver, mode="sleep", timeout=0.2, reason="post secure clear settle")
                    except Exception:
                        pass
                    try:
                        el.set_value(expected)
                    except Exception:
                        try:
                            self.driver.execute_script("mobile: setValue", {"elementId": el.id, "value": expected})
                        except Exception:
                            el.send_keys(expected)
        except Exception:
            pass

    def _tap_screen_center(self):
        try:
            size = self.driver.get_window_size()
            x = int(size['width'] * 0.5)
            y = int(size['height'] * 0.2)
            try:
                self.driver.execute_script("mobile: tap", {"x": x, "y": y})
            except Exception:
                # Fallback to W3C actions if needed
                try:
                    actions = {
                        "actions": [
                            {
                                "type": "pointer",
                                "id": "finger1",
                                "parameters": {"pointerType": "touch"},
                                "actions": [
                                    {"type": "pointerMove", "duration": 0, "x": x, "y": y},
                                    {"type": "pointerDown", "button": 0},
                                    {"type": "pause", "duration": 100},
                                    {"type": "pointerUp", "button": 0},
                                ],
                            }
                        ]
                    }
                    self.driver.perform(actions)
                except Exception:
                    pass
            smart_wait(self.driver, mode="sleep", timeout=0.3, reason="post center tap settle")
        except Exception:
            pass

    def _tap_element_center(self, el):
        try:
            r = getattr(el, "rect", None) or {}
            x = int(r.get("x", 0) + r.get("width", 0) / 2)
            y = int(r.get("y", 0) + r.get("height", 0) / 2)
            try:
                self.driver.execute_script("mobile: tap", {"x": x, "y": y})
            except Exception:
                try:
                    actions = {
                        "actions": [
                            {
                                "type": "pointer",
                                "id": "finger1",
                                "parameters": {"pointerType": "touch"},
                                "actions": [
                                    {"type": "pointerMove", "duration": 0, "x": x, "y": y},
                                    {"type": "pointerDown", "button": 0},
                                    {"type": "pause", "duration": 100},
                                    {"type": "pointerUp", "button": 0},
                                ],
                            }
                        ]
                    }
                    self.driver.perform(actions)
                except Exception:
                    pass
            smart_wait(self.driver, mode="sleep", timeout=0.2, reason="post element center tap settle")
        except Exception:
            pass

    def _find_banner_close_ios(self):
        # Try multiple strategies to locate a close/dismiss button on iOS
        names = IOS_CLOSE_NAMES
        # 1) YAML accessibility id
        try:
            meta = self.locators.get("btn_close", {})
            aid = meta.get("default_locator")
            if aid:
                try:
                    return self.driver.find_element(AppiumBy.ACCESSIBILITY_ID, aid)
                except Exception:
                    pass
        except Exception:
            pass
        # 2) Named buttons via predicate
        for n in names:
            try:
                return self.driver.find_element(
                    AppiumBy.IOS_PREDICATE,
                    f"type == 'XCUIElementTypeButton' AND (name == '{n}' OR label == '{n}' OR name CONTAINS[c] '{n}' OR label CONTAINS[c] '{n}')",
                )
            except Exception:
                continue
        # 3) Close inside an alert or sheet
        try:
            return self.driver.find_element(
                AppiumBy.IOS_CLASS_CHAIN,
                "**/XCUIElementTypeAlert/**/XCUIElementTypeButton[1]"
            )
        except Exception:
            pass
        try:
            return self.driver.find_element(
                AppiumBy.IOS_CLASS_CHAIN,
                "**/XCUIElementTypeSheet/**/XCUIElementTypeButton[1]"
            )
        except Exception:
            pass
        # 4) Navigation bar close
        try:
            return self.driver.find_element(
                AppiumBy.IOS_CLASS_CHAIN,
                "**/XCUIElementTypeNavigationBar/**/XCUIElementTypeButton[1]"
            )
        except Exception:
            pass
        # 5) Image/Other types that act like close
        for n in names:
            try:
                return self.driver.find_element(
                    AppiumBy.IOS_PREDICATE,
                    f"(type == 'XCUIElementTypeImage' OR type == 'XCUIElementTypeOther') AND (name == '{n}' OR label == '{n}' OR name CONTAINS[c] '{n}' OR label CONTAINS[c] '{n}')",
                )
            except Exception:
                continue
        return None

    def _set_picker_wheel_to(self, wheel, target, max_steps=30):
        """
        Robustly set an iOS PickerWheel to the target value.
        Tries direct set_value, then iterative mobile: selectPickerWheelValue both directions.
        """
        try:
            try:
                wheel.set_value(target)
                return
            except Exception:
                try:
                    wheel.send_keys(target)
                    return
                except Exception:
                    pass

            # Iterative selection if direct set doesn't work
            def current_value():
                try:
                    return (wheel.get_attribute("value") or "").strip()
                except Exception:
                    return ""

            for direction in ('next', 'previous'):
                steps = 0
                while steps < max_steps:
                    cur = current_value()
                    if cur and target.lower() in cur.lower():
                        return
                    try:
                        self.driver.execute_script("mobile: selectPickerWheelValue", {
                            "element": wheel.id,
                            "order": direction,
                            "offset": 0.15
                        })
                    except Exception:
                        break
                    steps += 1
        except Exception:
            pass

    # ===== iOS helper methods derived from reference (Search/Table/Scroll/Picker/WebView/SignIn) =====

    def _find_table_container(self):
        try:
            try:
                return self.driver.find_element(
                    AppiumBy.IOS_CLASS_CHAIN, "**/XCUIElementTypeSheet/**/XCUIElementTypeTable[1]"
                )
            except Exception:
                return self.driver.find_element(AppiumBy.IOS_CLASS_CHAIN, "**/XCUIElementTypeTable[1]")
        except Exception:
            return None

    def _scroll_in_container(self, container, direction, predicate):
        try:
            self.driver.execute_script(
                "mobile: scroll",
                {"direction": direction, "predicateString": predicate, "element": container.id},
            )
        except Exception:
            pass

    def _tap_cell_with_text_in_table(self, table, text):
        try:
            query = (
                "XCUIElementTypeCell[`ANY XCUIElementTypeStaticText[label == '"
                + text
                + "' OR name == '"
                + text
                + "' OR label CONTAINS[c] '"
                + text
                + "' OR name CONTAINS[c] '"
                + text
                + "']`]"
            )
            cell = table.find_element(AppiumBy.IOS_CLASS_CHAIN, query)
            try:
                cell.click()
                return True
            except Exception:
                return False
        except Exception:
            return False

    def _select_project_in_webview(self, loc_name):
        try:
            ctxs = getattr(self.driver, "contexts", [])
            for ctx in ctxs:
                if ctx != "NATIVE_APP":
                    try:
                        self.driver.switch_to.context(ctx)
                        try:
                            el = self.driver.find_element(
                                AppiumBy.XPATH, f"//*[contains(text(), '{loc_name}') or contains(., '{loc_name}')]"
                            )
                            el.click()
                            self.driver.switch_to.context("NATIVE_APP")
                            return True
                        except Exception:
                            pass
                    except Exception:
                        pass
        except Exception:
            pass
        finally:
            try:
                self.driver.switch_to.context("NATIVE_APP")
            except Exception:
                pass
        return False

    def _is_selection_sheet_open(self):
        try:
            if self.platform != 'ios':
                return False
            # Any picker wheel or sheet/table indicates the selection modal is still open
            wheels = self.driver.find_elements(AppiumBy.IOS_CLASS_CHAIN, "**/XCUIElementTypePickerWheel")
            if wheels:
                return True
            try:
                self.driver.find_element(AppiumBy.IOS_CLASS_CHAIN, "**/XCUIElementTypeSheet/**/XCUIElementTypeTable[1]")
                return True
            except Exception:
                pass
            sheets = self.driver.find_elements(AppiumBy.IOS_CLASS_CHAIN, "**/XCUIElementTypeSheet")
            return len(sheets) > 0
        except Exception:
            return False

    def _ensure_selection_sheet_closed(self, attempts=3):
        if self.platform != 'ios':
            return True
        for _ in range(attempts):
            if not self._is_selection_sheet_open():
                return True
            # Try common action buttons
            for name in ("Done", "OK", "Select", "Close"):
                try:
                    el = self.driver.find_element(AppiumBy.IOS_PREDICATE, f"name == '{name}' OR label == '{name}'")
                    el.click()
                    smart_wait(self.driver, mode="sleep", timeout=0.4, reason=f"post sheet button tap: {name}")
                    if not self._is_selection_sheet_open():
                        return True
                except Exception:
                    continue
            # Tap top area to dismiss sheet
            try:
                size = self.driver.get_window_size()
                self.driver.execute_script("mobile: tap", {"x": int(size["width"] * 0.5), "y": int(size["height"] * 0.1)})
            except Exception:
                pass
            smart_wait(self.driver, mode="sleep", timeout=0.6, reason="post sheet dismiss tap settle")
        return not self._is_selection_sheet_open()

    def _tap_sign_in_ios(self):
        try:
            # Ensure server selection sheet (if any) is closed
            try:
                self._ensure_selection_sheet_closed()
            except Exception:
                pass

            # Dismiss keyboard if present
            try:
                self.driver.hide_keyboard()
            except Exception:
                pass

            # Also try to dismiss any modal action buttons quickly
            try:
                btn = self.driver.find_element(
                    AppiumBy.IOS_PREDICATE,
                    "name IN {'Done','OK','Select'} OR label IN {'Done','OK','Select'}",
                )
                btn.click()
            except Exception:
                pass

            smart_wait(self.driver, mode="sleep", timeout=0.3, reason="pre sign-in tap settle")

            # Prefer Accessibility ID from YAML first
            label = "Sign in"
            try:
                meta = self.locators.get("login_button", {})
                label = meta.get("default_locator", label)
            except Exception:
                pass

            try:
                el = smart_wait(
                    self.driver,
                    mode="until",
                    condition=lambda d: d.find_element(AppiumBy.ACCESSIBILITY_ID, label),
                    timeout=5,
                    interval=0.25,
                )
                # If not visible, try a small scroll to surface it
                try:
                    if not el.is_displayed():
                        self._swipe_up_small()
                except Exception:
                    pass

                # Wait until enabled and click
                end = time.time() + 7
                while time.time() < end:
                    try:
                        if el.is_enabled():
                            el.click()
                            return True
                    except Exception:
                        pass
                    smart_wait(self.driver, mode="sleep", timeout=0.4, reason="poll sign-in enabled")
            except Exception:
                pass

            # Fallback to predicate variations to find Sign in/Login button and ensure it is enabled
            predicates = [
                "name == 'Sign in' OR label == 'Sign in'",
                "name CONTAINS[c] 'Sign in' OR label CONTAINS[c] 'Sign in'",
                "name == 'Login' OR label == 'Login'",
            ]
            for p in predicates:
                try:
                    btn = self.driver.find_element(
                        AppiumBy.IOS_PREDICATE, f"type == 'XCUIElementTypeButton' AND ({p})"
                    )
                    # Make visible if necessary
                    try:
                        if not btn.is_displayed():
                            self._swipe_up_small()
                    except Exception:
                        pass
                    end = time.time() + 5
                    while time.time() < end:
                        try:
                            if btn.is_enabled():
                                btn.click()
                                return True
                        except Exception:
                            pass
                        smart_wait(self.driver, mode="sleep", timeout=0.3, reason="poll fallback sign-in enabled")
                except Exception:
                    continue

            # Last resort: use healed locator with short timeout
            try:
                healed_btn = self.find("login_button", timeout=3, optional=True)
                if healed_btn:
                    end = time.time() + 5
                    while time.time() < end:
                        try:
                            if healed_btn.is_enabled():
                                healed_btn.click()
                                return True
                        except Exception:
                            pass
                        smart_wait(self.driver, mode="sleep", timeout=0.3, reason="poll healed sign-in enabled")
            except Exception:
                pass
        except Exception:
            pass
        return False

    def click_aconex_auth_robust(self):
        print("Clicking 'Sign in with Aconex username and password'...")
        clicked = False

        # Pass 1: iOS predicate search with gentle scroll + heal persisted to YAML
        if self.platform == 'ios':
            predicate = "name CONTAINS[c] 'Aconex' AND (name CONTAINS[c] 'Sign in' OR label CONTAINS[c] 'Sign in')"
            for _ in range(4):
                try:
                    el = self.driver.find_element(AppiumBy.IOS_PREDICATE, predicate)
                    best_label = el.get_attribute("name") or el.get_attribute("label") or "Sign in with Aconex username and password"
                    el.click()
                    smart_wait(self.driver, mode="sleep", timeout=1.0, reason="post Aconex auth click settle")
                    if self._wait_for_login_inputs(timeout=5):
                        clicked = True
                        try:
                            self.repair_agent.apply_fix(
                                'ios',
                                self.page_name,
                                'aconex_auth_link',
                                {'locator': best_label, 'strategy': 'accessibility_id', 'semantic_score': 0.99}
                            )
                            self.locators = self._load_yaml()
                            print(f"Persisted iOS heal for 'aconex_auth_link' -> accessibility_id: {best_label}")
                        except Exception:
                            pass
                        break
                except Exception:
                    # small scroll to surface the link if offscreen
                    self._swipe_up_small()
                    continue

        # Pass 2: Invoke SmartHeal model explicitly if not clicked yet
        if not clicked:
            try:
                healed = self._heal_locator('aconex_auth_link')
                if healed:
                    self.find('aconex_auth_link').click()
                    smart_wait(self.driver, mode="sleep", timeout=1.0, reason="post healed Aconex auth click settle")
                    if self._wait_for_login_inputs(timeout=5):
                        clicked = True
                        print("Clicked Aconex auth via healed locator.")
            except Exception:
                pass

        # Pass 3: XPath contains fallback + persist to YAML
        if not clicked:
            try:
                xpath = "//*[contains(@name,'Aconex') and (contains(@name,'Sign in') or contains(@label,'Sign in'))]"
                el = self.driver.find_element(AppiumBy.XPATH, xpath)
                best_label = el.get_attribute("name") or el.get_attribute("label")
                el.click()
                smart_wait(self.driver, mode="sleep", timeout=1.0, reason="post xpath Aconex auth click settle")
                if self._wait_for_login_inputs(timeout=5):
                    clicked = True
                    if best_label:
                        try:
                            self.repair_agent.apply_fix(
                                'ios',
                                self.page_name,
                                'aconex_auth_link',
                                {'locator': best_label, 'strategy': 'accessibility_id', 'semantic_score': 0.95}
                            )
                            self.locators = self._load_yaml()
                            print(f"Persisted iOS heal (fallback) for 'aconex_auth_link' -> accessibility_id: {best_label}")
                        except Exception:
                            pass
            except Exception as e:
                print(f"Aconex Auth selection failed: {e}")

        if not clicked:
            return False

        # Native app flow: do not switch to WEBVIEW
        return True

    def enter_credentials_robust(self):
        print("Entering credentials (robust)...")
        # Native fallbacks with scroll-retry (iOS safe typing)
        # Username (prioritize fast iOS native predicates to avoid SmartHeal delays)
        username_entered = False
        for _ in range(3):
            try:
                if self.platform == 'ios':
                    # Fast predicate search
                    predicate_user = "type == 'XCUIElementTypeTextField' AND (name CONTAINS[c] 'user' OR name CONTAINS[c] 'login' OR label CONTAINS[c] 'user' OR label CONTAINS[c] 'login' OR value CONTAINS[c] 'user' OR value CONTAINS[c] 'login' OR name CONTAINS[c] 'email' OR label CONTAINS[c] 'email')"
                    el_u2 = self.driver.find_element(AppiumBy.IOS_PREDICATE, predicate_user)
                    self._type_on_element(el_u2, self.test_data['username'])
                    username_entered = True
                    break
                else:
                    el_u = self.find('login_username', timeout=8)
                    self._type_on_element(el_u, self.test_data['username'])
                    username_entered = True
                    break
            except Exception:
                try:
                    if self.platform == 'ios':
                        # Class chain fallback
                        el_u3 = self.driver.find_element(AppiumBy.IOS_CLASS_CHAIN, "**/XCUIElementTypeTextField[1]")
                        self._type_on_element(el_u3, self.test_data['username'])
                        username_entered = True
                        break
                except Exception:
                    # Try small scroll and retry
                    self._swipe_up_small()
                    continue
        if not username_entered:
            raise Exception("Username input not found after retries.")

        # Password (prioritize fast iOS native predicates to avoid SmartHeal delays)
        password_entered = False
        last_pwd_el = None
        for _ in range(3):
            try:
                if self.platform == 'ios':
                    # Prefer secure text field via predicate
                    predicate_pwd = "type == 'XCUIElementTypeSecureTextField' OR (type == 'XCUIElementTypeTextField' AND (name CONTAINS[c] 'password' OR label CONTAINS[c] 'password'))"
                    el_p2 = self.driver.find_element(AppiumBy.IOS_PREDICATE, predicate_pwd)
                    self._type_on_element(el_p2, self.test_data['password'])
                    last_pwd_el = el_p2
                    password_entered = True
                    break
                else:
                    el_p = self.find('login_password', timeout=8)
                    self._type_on_element(el_p, self.test_data['password'])
                    last_pwd_el = el_p
                    password_entered = True
                    break
            except Exception:
                try:
                    if self.platform == 'ios':
                        # Class chain fallback
                        el_p3 = self.driver.find_element(AppiumBy.IOS_CLASS_CHAIN, "**/XCUIElementTypeSecureTextField[1]")
                        self._type_on_element(el_p3, self.test_data['password'])
                        last_pwd_el = el_p3
                        password_entered = True
                        break
                except Exception:
                    # Try small scroll and retry
                    self._swipe_up_small()
                    continue
        if not password_entered:
            raise Exception("Password input not found after retries.")

        if last_pwd_el:
            self._validate_and_fix_secure_text(last_pwd_el, self.test_data['password'])

        self._hide_keyboard_if_visible()
        self._tap_screen_center()

        # Re-validate after dismissing keyboard to ensure no stray input occurred
        try:
            smart_wait(self.driver, mode="sleep", timeout=0.3, reason="pre re-validate secure text")
            self._validate_and_fix_secure_text(last_pwd_el, self.test_data['password'])
        except Exception:
            pass

        # Ensure we remain in NATIVE context
        self._switch_to_native()

    def select_project_location_dropdown(self):
        loc_name = self.test_data['projLoc']
        print(f"Selecting Server Location: {loc_name}")
        try:
            # Ensure NATIVE context before opening dropdown
            self._switch_to_native()
            self._hide_keyboard_if_visible()
            if self.platform == 'android':
                dd = self.scroll_to_find('project_location_dropdown')
                dd.click()
                smart_wait(self.driver, mode="sleep", timeout=1.0, reason="post dropdown open settle")
            else:
                # iOS: open dropdown without triggering SmartHeal (fast native strategies)
                opened = False
                # Try YAML accessibility id first
                try:
                    meta = self.locators.get('project_location_dropdown', {})
                    aid = meta.get('default_locator', 'ProjectLocDropdown')
                    self.driver.find_element(AppiumBy.ACCESSIBILITY_ID, aid).click()
                    opened = True
                except Exception:
                    pass

                # Try common predicates and class chain
                if not opened:
                    preds = [
                        "type == 'XCUIElementTypeButton' AND (name CONTAINS[c] 'Project' AND (name CONTAINS[c] 'Location' OR name CONTAINS[c] 'Server' OR label CONTAINS[c] 'Location' OR label CONTAINS[c] 'Server'))",
                        "type == 'XCUIElementTypeStaticText' AND (name CONTAINS[c] 'Project' AND (name CONTAINS[c] 'Location' OR name CONTAINS[c] 'Server'))",
                        "type == 'XCUIElementTypeOther' AND (name CONTAINS[c] 'Project' AND (name CONTAINS[c] 'Location' OR name CONTAINS[c] 'Server'))",
                    ]
                    for p in preds:
                        try:
                            el = self.driver.find_element(AppiumBy.IOS_PREDICATE, p)
                            el.click()
                            opened = True
                            break
                        except Exception:
                            continue

                if not opened:
                    try:
                        el = self.driver.find_element(AppiumBy.IOS_CLASS_CHAIN, "**/XCUIElementTypeButton[`name CONTAINS[c] 'Project' OR label CONTAINS[c] 'Project'`][1]")
                        el.click()
                        opened = True
                    except Exception:
                        pass

                # Scroll and retry up to 3 times
                attempts = 3
                while not opened and attempts > 0:
                    try:
                        size = self.driver.get_window_size()
                        self.driver.swipe(size['width'] * 0.5, size['height'] * 0.8, size['width'] * 0.5, size['height'] * 0.2, 1000)
                    except Exception:
                        pass
                    smart_wait(self.driver, mode="sleep", timeout=0.8, reason="post scroll retry settle")
                    try:
                        self.driver.find_element(AppiumBy.ACCESSIBILITY_ID, aid).click()
                        opened = True
                        break
                    except Exception:
                        pass
                    for p in preds:
                        try:
                            el = self.driver.find_element(AppiumBy.IOS_PREDICATE, p)
                            el.click()
                            opened = True
                            break
                        except Exception:
                            continue
                    if opened:
                        break
                    attempts -= 1

                if not opened:
                    # Last resort: small-timeout native find to avoid long SmartHeal path
                    try:
                        el = self.find('project_location_dropdown', timeout=3, optional=True)
                        if el:
                            el.click()
                            opened = True
                    except Exception:
                        pass

                if not opened:
                    raise Exception("Could not open Project Location dropdown on iOS")

                smart_wait(self.driver, mode="sleep", timeout=1.0, reason="post iOS dropdown open settle")
                try:
                    WebDriverWait(self.driver, 8).until(
                        lambda d: len(d.find_elements(AppiumBy.IOS_CLASS_CHAIN, "**/XCUIElementTypePickerWheel")) > 0
                        or len(d.find_elements(AppiumBy.IOS_PREDICATE, f"name CONTAINS[c] '{loc_name}' OR label CONTAINS[c] '{loc_name}'")) > 0
                        or len(d.find_elements(AppiumBy.IOS_CLASS_CHAIN, "**/XCUIElementTypeCell")) > 0
                    )
                except Exception:
                    pass

            if self.platform == 'android':
                # Preserve Android behavior (unchanged)
                xpath = f"//*[contains(@text, '{loc_name}')]"
                smart_wait(self.driver, mode="presence", locator=(AppiumBy.XPATH, xpath), timeout=10, interval=0.5)
                self.driver.find_element(AppiumBy.XPATH, xpath).click()
            else:
                # iOS: Robust selection: SearchField -> Table -> Scroll -> Picker -> WebView
                chosen = False

                # Ensure keyboard not covering and give the sheet a moment
                try:
                    self._hide_keyboard_if_visible()
                except Exception:
                    pass

                # 1) Search Field strategy
                try:
                    sf = None
                    try:
                        sf = self.driver.find_element(AppiumBy.IOS_CLASS_CHAIN, "**/XCUIElementTypeSearchField[1]")
                    except Exception:
                        try:
                            sf = self.driver.find_element(
                                AppiumBy.IOS_PREDICATE,
                                "type == 'XCUIElementTypeTextField' AND (name CONTAINS[c] 'Search' OR value CONTAINS[c] 'Search')",
                            )
                        except Exception:
                            pass

                    if sf:
                        self._type_on_element(sf, loc_name)
                        smart_wait(self.driver, mode="sleep", timeout=1.0, reason="post search type settle")
                        try:
                            res = self.driver.find_element(
                                AppiumBy.IOS_PREDICATE,
                                f"type == 'XCUIElementTypeStaticText' AND (name CONTAINS[c] '{loc_name}' OR label CONTAINS[c] '{loc_name}')",
                            )
                            res.click()
                            chosen = True
                            try:
                                self.driver.find_element(
                                    AppiumBy.IOS_PREDICATE,
                                    "name IN {'Done','OK','Select'} OR label IN {'Done','OK','Select'}",
                                ).click()
                            except Exception:
                                pass
                        except Exception:
                            pass
                except Exception:
                    pass

                # 2) Table Container strategy
                if not chosen:
                    table = self._find_table_container()
                    if table:
                        formatted = f"{loc_name} ({loc_name})"
                        for _ in range(1):
                            if self._tap_cell_with_text_in_table(table, formatted) or self._tap_cell_with_text_in_table(
                                table, loc_name
                            ):
                                chosen = True
                                try:
                                    self.driver.find_element(
                                        AppiumBy.IOS_PREDICATE,
                                        "name IN {'Done','OK','Select'} OR label IN {'Done','OK','Select'}",
                                    ).click()
                                except Exception:
                                    pass
                                break
                            self._scroll_in_container(
                                table,
                                "down",
                                f"name CONTAINS[c] '{loc_name}' OR label CONTAINS[c] '{loc_name}'",
                            )

                # 3) Global Scroll & Tap StaticText
                if not chosen:
                    def _try_tap_text(text):
                        preds = [
                            f"name == '{text}' OR label == '{text}'",
                            f"name CONTAINS[c] '{text}' OR label CONTAINS[c] '{text}'",
                        ]
                        for p in preds:
                            try:
                                el = self.driver.find_element(
                                    AppiumBy.IOS_PREDICATE, f"type == 'XCUIElementTypeStaticText' AND ({p})"
                                )
                                el.click()
                                return True
                            except Exception:
                                continue
                        return False

                    if _try_tap_text(loc_name):
                        chosen = True
                        try:
                            self.driver.find_element(
                                AppiumBy.IOS_PREDICATE,
                                "name IN {'Done','OK','Select'} OR label IN {'Done','OK','Select'}",
                            ).click()
                        except Exception:
                            pass
                    else:
                        for _ in range(4):
                            try:
                                self.driver.execute_script(
                                    "mobile: scroll",
                                    {
                                        "direction": "down",
                                        "predicateString": f"name CONTAINS[c] '{loc_name}' OR label CONTAINS[c] '{loc_name}'",
                                    },
                                )
                            except Exception:
                                pass
                            if _try_tap_text(loc_name):
                                chosen = True
                                try:
                                    self.driver.find_element(
                                        AppiumBy.IOS_PREDICATE,
                                        "name IN {'Done','OK','Select'} OR label IN {'Done','OK','Select'}",
                                    ).click()
                                except Exception:
                                    pass
                                break

                # 4) Picker Wheel strategy
                if not chosen:
                    try:
                        wheels = self.driver.find_elements(AppiumBy.IOS_CLASS_CHAIN, "**/XCUIElementTypePickerWheel")
                        if wheels:
                            self._set_picker_wheel_to(wheels[0], loc_name)
                            chosen = True
                            try:
                                self.driver.find_element(
                                    AppiumBy.IOS_PREDICATE,
                                    "name IN {'Done','OK','Select'} OR label IN {'Done','OK','Select'}",
                                ).click()
                            except Exception:
                                pass
                    except Exception:
                        pass

                # 5) WebView fallback
                if not chosen:
                    try:
                        self._select_project_in_webview(loc_name)
                    except Exception:
                        pass

                # Ensure the selection sheet is dismissed before continuing
                try:
                    self._ensure_selection_sheet_closed()
                except Exception:
                    pass
        except Exception as e:
            print(f"Dropdown Selection Failed: {e}")

    def wait_and_select_project(self):
        """
        Phase 1: Handles Application Slowness after clicking Sign In.
        It continuously checks for the Project Name for up to 60 seconds.
        """
        proj_name = self.test_data.get('projectName', DEFAULT_PROJECT_NAME)
        try:
            # Delegate to common wait helper (keeps behavior the same, centralizes logic)
            wait_and_select_project_common(self.driver, self.platform, proj_name, timeout=60)
        except Exception as e:
            print(f"❌ Timed out waiting for Project '{proj_name}'. Page did not load.")
            raise e

    def wait_and_close_banner(self):
        """
        Phase 2: Handles Application Slowness after Project Selection.
        1. Waits for Banner Close button (up to 60s).
        2. Clicks Close.
        3. SMART WAIT (10s) for Dashboard to load (instead of hard sleep).
        """
        print("⏳ [SLOWNESS CHECK] Waiting up to 60s for Banner Close Button...")

        try:
            if self.platform == 'ios':
                # Robust iOS close handler
                # Smart stabilization wait (~10s) to allow landing page/banner animations to finish
                print("   -> iOS: Smart wait ~10s to stabilize landing page before interacting with banner...")
                end_stab = time.time() + 10
                last_src = None
                stable_ticks = 0
                while time.time() < end_stab:
                    try:
                        src = self.driver.page_source
                        if src == last_src:
                            stable_ticks += 1
                        else:
                            stable_ticks = 0
                        last_src = src
                        # If close element surfaces and UI is stable for a moment, break early
                        try:
                            if stable_ticks >= 2 and self._find_banner_close_ios():
                                break
                        except Exception:
                            pass
                    except Exception:
                        pass
                    smart_wait(self.driver, mode="sleep", timeout=0.5, reason="iOS landing stabilize poll")

                print("   -> iOS: Locating Close button on banner...")
                # Earlier working approach: try 'landing_close_button' key first (iOS-only, optional)
                close_el = None
                try:
                    close_el = self.find("landing_close_button", timeout=3, optional=True)
                except Exception:
                    close_el = None
                # If not found, proceed with robust search for Close element
                if close_el is None:
                    end = time.time() + 60
                    while time.time() < end and close_el is None:
                        try:
                            close_el = self._find_banner_close_ios()
                            if close_el:
                                break
                        except Exception:
                            pass
                        smart_wait(self.driver, mode="sleep", timeout=0.5, reason="poll for iOS close control")

                if not close_el:
                    # As last resort attempt SmartHeal-based find with short timeout
                    try:
                        close_el = self.find('btn_close', timeout=3, optional=True)
                    except Exception:
                        close_el = None

                if not close_el:
                    raise Exception("iOS banner Close control not found")

                print("   -> iOS: Clicking Close...")
                try:
                    close_el.click()
                except Exception:
                    try:
                        self._tap_element_center(close_el)
                    except Exception:
                        # Top-right tap fallback (common close 'X')
                        try:
                            size = self.driver.get_window_size()
                            for dx, dy in [(0,0), (-20,0), (0,20), (-20,20)]:
                                x = int(size['width'] * 0.92) + dx
                                y = int(size['height'] * 0.08) + dy
                                try:
                                    self.driver.execute_script("mobile: tap", {"x": x, "y": y})
                                    smart_wait(self.driver, mode="sleep", timeout=0.3, reason="post top-right tap settle")
                                except Exception:
                                    pass
                        except Exception:
                            pass

                # Wait for banner to disappear or dashboard to appear (robust)
                # print("⏳ [SMART WAIT] Waiting up to 10s for Dashboard to appear...")
                # expected_title = self.test_data.get('projectName', DEFAULT_PROJECT_NAME)
                # end2 = time.time() + 10
                # loaded = False
                # while time.time() < end2:
                #     try:
                #         # Check either known dashboard accessibility id or the project title text itself
                #         if self.driver.find_elements(AppiumBy.ACCESSIBILITY_ID, "ProjectTitle"):
                #             loaded = True
                #             break
                #     except Exception:
                #         pass
                #     try:
                #         if self.driver.find_elements(AppiumBy.ACCESSIBILITY_ID, expected_title):
                #             loaded = True
                #             break
                #     except Exception:
                #         pass
                #     try:
                #         # StaticText with name/label containing expected title
                #         st = self.driver.find_elements(
                #             AppiumBy.IOS_PREDICATE,
                #             f"type == 'XCUIElementTypeStaticText' AND (name CONTAINS[c] '{expected_title}' OR label CONTAINS[c] '{expected_title}')"
                #         )
                #         if st:
                #             loaded = True
                #             break
                #     except Exception:
                #         pass
                #
                #     # If not loaded, try closing banner again if still visible
                #     try:
                #         maybe_close = self._find_banner_close_ios()
                #         if maybe_close:
                #             try:
                #                 maybe_close.click()
                #             except Exception:
                #                 try:
                #                     self._tap_element_center(maybe_close)
                #                 except Exception:
                #                     pass
                #     except Exception:
                #         pass
                #
                #     # Dismiss any lingering sheets/alerts
                #     try:
                #         if self._is_selection_sheet_open():
                #             self._ensure_selection_sheet_closed()
                #     except Exception:
                #         pass
                #
                #     time.sleep(0.5)

                try:
                    expected_title = self.test_data.get('projectName', DEFAULT_PROJECT_NAME)
                    st = self.driver.find_elements(
                        AppiumBy.IOS_PREDICATE,
                        f"type == 'XCUIElementTypeStaticText' AND (name CONTAINS[c] '{expected_title}' OR label CONTAINS[c] '{expected_title}')"
                    )
                    if st:
                        print("✅ Dashboard Loaded successfully.")
                        return
                except Exception:
                    pass

                # if loaded:
                #     print("✅ Dashboard Loaded successfully.")
                # else:
                #     print("⚠️ Warning: Dashboard markers not detected within 12s. Proceeding to validation...")
            else:
                # Existing Android behavior (unchanged)
                # 1. Wait for Close Button
                meta = self.locators['btn_close']
                strategy = AppiumBy.ID if meta['strategy'] == 'id' else AppiumBy.ACCESSIBILITY_ID
                value = meta['default_locator']

                smart_wait(self.driver, mode="presence", locator=(strategy, value), timeout=60, interval=0.5)

                # 2. Click Close
                print("   -> Banner loaded. Clicking Close button...")
                self.find('btn_close').click()

                # 3. SMART WAIT FOR DASHBOARD (Max 10s)
                print("⏳ [SMART WAIT] Waiting up to 10s for Dashboard to appear...")

                dash_locator = (AppiumBy.ID, "com.oracle.aconex.qa:id/project_title")
                try:
                    smart_wait(self.driver, mode="presence", locator=dash_locator, timeout=10, interval=0.5)
                    print("✅ Dashboard Loaded successfully.")
                except:
                    print("⚠️ Warning: Dashboard element not detected within 10s. Proceeding to validation...")

        except Exception as e:
            print("❌ Timed out waiting for Banner/Dashboard transition.")
            raise e

        # sleep_with_reason(10,"Waiting for the project data to load")
        # click_on_element(self,'scp_banner_close')

    def perform_full_login(self):
        print(f"Starting Mobile Login Flow ({self.platform})...")

        # comman steps for login
        print("Step 1: Clicking Terms...")
        self.click_on_element('terms_link')
        print("Step 2: Clicking Agree...")
        self.click_on_element('agree_button')
        print("Step 3: Auth Method...")
        self.click_on_element('show_other_methods_link')
        self.click_on_element('aconex_auth_link')
        print("Step 4: Entering Credentials...")
        self.enter_credentials()

        print("Step 5: Selecting Server...")
        self.select_project_location_dropdown()

        print("Step 6: Clicking Sign In...")
        self.click_login_button()

        # Step 7: Wait & Select Project
        self.wait_and_select_project()

        # Step 8: Wait Close & Smart Wait for Dashboard
        self.wait_and_close_banner()

        # if self.platform == 'android':
        #     print("Step 1: Clicking Terms...")
        #     self.find('terms_link').click()
        #     sleep_with_reason(3, "post Terms tap settle (Android)")
        #
        #     print("Step 2: Clicking Agree...")
        #     self.find('agree_button').click()
        #     sleep_with_reason(3, "post Agree tap settle (Android)")
        #
        #     print("Step 3: Auth Method...")
        #     self.find('show_other_methods_link').click()
        #     sleep_with_reason(1, "post Other Methods tap settle (Android)")
        #     self.find('aconex_auth_link').click()
        #     sleep_with_reason(3, "post Aconex auth open settle (Android)")
        #
        #     print("Step 4: Entering Credentials...")
        #     self.find('login_username').send_keys(self.test_data['username'])
        #     self.find('login_password').send_keys(self.test_data['password'])
        #
        #     print("Step 5: Selecting Server...")
        #     self.select_project_location_dropdown()
        #
        #     print("Step 6: Clicking Sign In...")
        #     self.find('login_button').click()
        #
        #     # Step 7: Wait & Select Project
        #     self.wait_and_select_project()
        #
        #     # Step 8: Wait Close & Smart Wait for Dashboard
        #     self.wait_and_close_banner()
        #
        # elif self.platform == 'ios':
        #     print("Step 1: Clicking Terms...")
        #     self.find('terms_link').click()
        #     sleep_with_reason(2, "post Terms tap settle (iOS)")
        #
        #     print("Step 2: Clicking Agree...")
        #     self.find('agree_button').click()
        #     sleep_with_reason(2, "post Agree tap settle (iOS)")
        #
        #     print("Step 3: Auth Method...")
        #     self.find('show_other_methods_link').click()
        #     sleep_with_reason(1, "post Other Methods tap settle (iOS)")
        #     if not self.click_aconex_auth_robust():
        #         raise Exception("Failed to click Aconex auth link")
        #     sleep_with_reason(2, "post Aconex auth transition (iOS)")
        #
        #     print("Step 4: Entering Credentials...")
        #     self.enter_credentials_robust()
        #
        #     print("Step 5: Selecting Server...")
        #     self.select_project_location_dropdown()
        #
        #     print("Step 6: Clicking Sign In...")
        #     if not self._tap_sign_in_ios():
        #         try:
        #             self.find('login_button').click()
        #         except Exception:
        #             try:
        #                 btn = self.driver.find_element(
        #                     AppiumBy.IOS_PREDICATE,
        #                     "type == 'XCUIElementTypeButton' AND (name == 'Sign in' OR label == 'Sign in' OR name CONTAINS[c] 'Sign in' OR label CONTAINS[c] 'Sign in' OR name == 'Login' OR label == 'Login')"
        #                 )
        #                 btn.click()
        #             except Exception:
        #                 pass
        #
        #     # Step 7: Wait & Select Project
        #     self.wait_and_select_project()
        #
        #     # Step 8: Wait Close & Smart Wait for Dashboard
        #     self.wait_and_close_banner()

    def enter_credentials(self):
        if self.platform == 'android':
            self.send_keys_to_element('login_username', self.test_data['username'])
            self.send_keys_to_element('login_password', self.test_data['password'])
        elif self.platform == 'ios':
            self.enter_credentials_robust()

    def click_login_button(self):
        if self.platform == 'android':
            self.click_on_element('login_button')
        elif self.platform == 'ios':
            if not self._tap_sign_in_ios():
                try:
                    self.find('login_button').click()
                except Exception:
                    try:
                        btn = self.driver.find_element(
                            AppiumBy.IOS_PREDICATE,
                            "type == 'XCUIElementTypeButton' AND (name == 'Sign in' OR label == 'Sign in' OR name CONTAINS[c] 'Sign in' OR label CONTAINS[c] 'Sign in' OR name == 'Login' OR label == 'Login')"
                        )
                        btn.click()
                    except Exception:
                        pass
