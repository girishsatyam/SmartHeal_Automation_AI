from tests.common.base_page import SmartHealBasePage
from tests.common.data_loader import DataLoader
import allure
from tests.common.constants import WEB_AUTH_OPTION_TEXTS
from tests.common.web.helpers import (
    pl12_login_flow,
    load_web_config,
    attach_state as attach_state_helper,
    click_any_text_contains,
    click_button_by_id,
    find_username_field as _find_user_helper,
    find_password_field as _find_pwd_helper,
    type_fast as _type_fast,
    ensure_landed_on_dashboard,
)
from tests.common.waits import sleep_with_reason


class WebLoginPage(SmartHealBasePage):
    def __init__(self, driver):
        super().__init__(driver)
        self.test_data = DataLoader.get_data()
        try:
            self.web_cfg = load_web_config()
        except Exception:
            self.web_cfg = {}

    def perform_full_login(self):
        """
        Perform full PL12 web login flow using generic web helpers.
        - Launches/ensures navigation to baseUrl from config/web_config.json
        - Handles common cookie banners, SSO/auth tiles, nested iframes/shadow DOM
        - Types username/password and submits, with robust fallbacks
        """
        username = self.test_data["username"]
        password = self.test_data["password"]
        base_url = (self.web_cfg or {}).get("baseUrl")

        # Fast-path: try classic locators first for PL12 login page, then fall back to generic flow
        with allure.step("Web: Fast-path login via YAML locators"):
            try:
                # Ensure we are at baseUrl (non-destructive if already on IdP/redirected pages)
                if base_url:
                    try:
                        self.driver.get(base_url)
                        sleep_with_reason(1.0, "fast-path: post baseUrl nav")
                    except Exception:
                        pass

                # Toggle common labels/tiles that reveal the input fields
                try:
                    click_any_text_contains(self.driver, ["Login Name", "Work Email", "Aconex username", "Aconex login"])
                except Exception:
                    pass

                # Optional Terms & Conditions link
                try:
                    link = self.find("terms_link", timeout=3, optional=True)
                    if link:
                        try:
                            link.click()
                        except Exception:
                            pass
                        sleep_with_reason(0.3, "fast-path: terms link")
                except Exception:
                    pass

                # Username (try YAML first without healing; then helper)
                user_el = None
                try:
                    user_el = self.find("login_username", timeout=5, optional=True)
                except Exception:
                    user_el = None
                # If YAML-based locator failed, try SmartHeal once to persist a better locator, then retry
                if not user_el:
                    try:
                        if self._heal_locator("login_username"):
                            try:
                                user_el = self.find("login_username", timeout=5, optional=True)
                            except Exception:
                                user_el = None
                    except Exception:
                        pass
                if not user_el:
                    try:
                        user_el = _find_user_helper(self.driver)
                    except Exception:
                        user_el = None
                if not user_el:
                    raise Exception("Username field not found in fast-path")
                try:
                    user_el.clear()
                except Exception:
                    pass
                try:
                    _type_fast(self.driver, user_el, username)
                except Exception:
                    pass

                # Click Next (YAML next_button -> id nextButton -> visible text fallbacks)
                clicked_next = False
                try:
                    nxt = self.find("next_button", timeout=4, optional=True)
                    if nxt:
                        try:
                            nxt.click()
                            clicked_next = True
                        except Exception:
                            try:
                                self.driver.execute_script("arguments[0].click();", nxt)
                                clicked_next = True
                            except Exception:
                                pass
                except Exception:
                    pass
                # If YAML next_button is missing, try SmartHeal to persist and retry before falling back to generic clicks
                if not clicked_next:
                    try:
                        if self._heal_locator("next_button"):
                            try:
                                nxt = self.find("next_button", timeout=4, optional=True)
                                if nxt:
                                    try:
                                        nxt.click()
                                        clicked_next = True
                                    except Exception:
                                        try:
                                            self.driver.execute_script("arguments[0].click();", nxt)
                                            clicked_next = True
                                        except Exception:
                                            pass
                            except Exception:
                                pass
                    except Exception:
                        pass
                if not clicked_next:
                    try:
                        clicked_next = click_button_by_id(self.driver, "nextButton", timeout=6)
                    except Exception:
                        pass
                if not clicked_next:
                    try:
                        # Broad text click for Next/Continue/Proceed
                        click_any_text_contains(self.driver, ["Next", "Continue", "Proceed"])
                        clicked_next = True
                    except Exception:
                        pass
                sleep_with_reason(0.6, "fast-path: post Next click")

                # Password (try YAML without healing; then helper)
                pwd_el = None
                try:
                    pwd_el = self.find("login_password", timeout=6, optional=True)
                except Exception:
                    pwd_el = None
                # If YAML-based locator failed, attempt SmartHeal to persist and retry
                if not pwd_el:
                    try:
                        if self._heal_locator("login_password"):
                            try:
                                pwd_el = self.find("login_password", timeout=6, optional=True)
                            except Exception:
                                pwd_el = None
                    except Exception:
                        pass
                if not pwd_el:
                    try:
                        pwd_el = _find_pwd_helper(self.driver)
                    except Exception:
                        pwd_el = None
                if not pwd_el:
                    raise Exception("Password field not found in fast-path")
                try:
                    pwd_el.clear()
                except Exception:
                    pass
                try:
                    _type_fast(self.driver, pwd_el, password)
                except Exception:
                    pass

                # Submit (YAML login_button -> nextButton -> visible text)
                did_submit = False
                try:
                    btn = self.find("login_button", timeout=6, optional=True)
                    if btn:
                        try:
                            btn.click()
                            did_submit = True
                        except Exception:
                            try:
                                # JS click fallback if needed
                                self.driver.execute_script("arguments[0].click();", btn)
                                did_submit = True
                            except Exception:
                                pass
                except Exception:
                    pass
                # If YAML login_button is missing, try SmartHeal to persist and retry before id/text fallbacks
                if not did_submit:
                    try:
                        if self._heal_locator("login_button"):
                            try:
                                btn = self.find("login_button", timeout=6, optional=True)
                                if btn:
                                    try:
                                        btn.click()
                                        did_submit = True
                                    except Exception:
                                        try:
                                            self.driver.execute_script("arguments[0].click();", btn)
                                            did_submit = True
                                        except Exception:
                                            pass
                            except Exception:
                                pass
                    except Exception:
                        pass
                if not did_submit:
                    try:
                        did_submit = click_button_by_id(self.driver, "nextButton", timeout=6)
                    except Exception:
                        pass
                if not did_submit:
                    try:
                        click_any_text_contains(self.driver, ["Sign in", "Log in", "Login", "Submit"])
                        did_submit = True
                    except Exception:
                        pass

                sleep_with_reason(1.0, "fast-path: post submit")
                with allure.step("Web: Validate dashboard header"):
                    ensure_landed_on_dashboard(self.driver, header_text="ORACLE Aconex", wait_timeout=5.0)
                return
            except Exception:
                # Proceed to generic flow below
                pass

        with allure.step("Web: Execute PL12 Login Flow"):
            try:
                pl12_login_flow(self.driver, username, password, base_url, WEB_AUTH_OPTION_TEXTS)
                with allure.step("Web: Validate dashboard header"):
                    ensure_landed_on_dashboard(self.driver, header_text="ORACLE Aconex", wait_timeout=5.0)
            except Exception as e:
                # Attach diagnostics then try a classic YAML-driven fallback before failing
                try:
                    attach_state_helper(self.driver, "failure")
                except Exception:
                    pass
                try:
                    with allure.step("Web: Fallback classic login via YAML locators"):
                        # Re-navigate to baseUrl if available
                        if base_url:
                            try:
                                self.driver.get(base_url)
                                sleep_with_reason(1.0, "fallback: post baseUrl navigation")
                            except Exception:
                                pass
                        # Optional Terms & Conditions link
                        try:
                            link = self.find("terms_link", timeout=5, optional=True)
                            if link:
                                try:
                                    link.click()
                                except Exception:
                                    pass
                                sleep_with_reason(0.5, "fallback: terms link clicked")
                        except Exception:
                            pass
                        # Username
                        user_el = self.find("login_username", timeout=15)
                        try:
                            user_el.clear()
                        except Exception:
                            pass
                        try:
                            user_el.send_keys(username)
                        except Exception:
                            pass
                        # Password
                        pwd_el = self.find("login_password", timeout=15)
                        try:
                            pwd_el.clear()
                        except Exception:
                            pass
                        try:
                            pwd_el.send_keys(password)
                        except Exception:
                            pass
                        # Submit
                        btn = self.find("login_button", timeout=12)
                        try:
                            btn.click()
                        except Exception:
                            try:
                                # JS click fallback if needed
                                self.driver.execute_script("arguments[0].click();", btn)
                            except Exception:
                                pass
                        sleep_with_reason(1.0, "fallback: post login submit")
                        with allure.step("Web: Validate dashboard header (fallback)"):
                            ensure_landed_on_dashboard(self.driver, header_text="ORACLE Aconex", wait_timeout=5.0)
                except Exception:
                    # Both flows failed -> re-raise original error to surface cause
                    raise e
