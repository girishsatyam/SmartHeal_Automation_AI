import pytest
import allure
from tests.web.pages.WebLoginPage import WebLoginPage

@allure.feature("Web Login")
@pytest.mark.web
class TestWebLogin:
    @allure.story("Login Flow")
    def test_login(self, driver):
        if not driver: pytest.fail("Web Driver Failed")
        page = WebLoginPage(driver)
        page.perform_full_login()