import pytest
import allure
from tests.pages.MobileIssuesPage import MobileIssuesPage
from tests.pages.MobileDashboardPage import MobileDashboardPage
from tests.pages.MobileLoginPage import MobileLoginPage


@allure.feature("Mobile Issues")
@pytest.mark.mobile
class TestMobileIssues:
    @pytest.mark.parametrize(
        "platform,story",
        [
            pytest.param("android", "Android: Create Issues with out Attachments", marks=pytest.mark.android, id="android"),
            pytest.param("ios", "iOS: Create Issues with out Attachments", marks=pytest.mark.ios, id="ios"),
        ],
    )
    @allure.story("Create Issues with out Attachments")
    def test_create_issues(self, driver,platform,story):
        if not driver:
            pytest.fail("Driver Failed")

        # 1) Login to land on Dashboard
        MobileLoginPage(driver).perform_full_login()

        # 2) Validate Dashboard is stable
        dash = MobileDashboardPage(driver)
        #dash.validate_full_dashboard()

        # 3) Click the Issues button
        with allure.step("Open Issues from Dashboard"):
            dash.open_issues()

        MobileIssuesPage(driver).create_issues(False)

    @pytest.mark.parametrize(
        "platform,story",
        [
            pytest.param("android", "Android: Create Issues with Attachments", marks=pytest.mark.android, id="android"),
            pytest.param("ios", "iOS: Create Issues with Attachments", marks=pytest.mark.ios, id="ios"),
        ],
    )
    @allure.story("Create Issues with Attachments")
    def test_create_issues_with_attachments(self, driver, platform, story):
        if not driver:
            pytest.fail("Driver Failed")

        # 1) Login to land on Dashboard
        MobileLoginPage(driver).perform_full_login()

        # 2) Validate Dashboard is stable
        dash = MobileDashboardPage(driver)

        # 3) Click the Issues button
        with allure.step("Open Issues from Dashboard"):
            dash.open_issues()

        MobileIssuesPage(driver).create_issues(True)



