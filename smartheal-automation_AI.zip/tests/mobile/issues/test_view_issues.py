import pytest
import allure
from tests.pages.MobileDashboardPage import MobileDashboardPage
from tests.pages.MobileLoginPage import MobileLoginPage


@allure.feature("Mobile Issues")
@pytest.mark.mobile
class TestMobileIssues:

    # @pytest.mark.parametrize("platform",
    #      [
    #          pytest.param("android", marks=pytest.mark.android),
    #          pytest.param("ios", marks=pytest.mark.ios),
    #      ]
    #      )
    @pytest.mark.parametrize(
        "platform,story",
        [
            pytest.param("android", "Android: Open Issues from Dashboard", marks=pytest.mark.android, id="android"),
            pytest.param("ios", "iOS: Open Issues from Dashboard", marks=pytest.mark.ios, id="ios"),
        ],
    )
    @allure.story("Open Issues from Dashboard")
    def test_open_issues(self, driver,platform,story):
        if not driver:
            pytest.fail("Driver Failed")

        # 1) Login to land on Dashboard
        MobileLoginPage(driver).perform_full_login()

        # 2) Validate Dashboard is stable
        dash = MobileDashboardPage(driver)
        #dash.validate_full_dashboard()

        # 3) Click the Issues button
        with allure.step("Open Issues from Dashboard"):
            dash.open_issues()
            print("This is the issue testcase")
