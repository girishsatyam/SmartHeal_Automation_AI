import pytest
import allure
from tests.pages.MobileDashboardPage import MobileDashboardPage
from tests.pages.MobileLoginPage import MobileLoginPage


@allure.feature("Mobile End-to-End")
@pytest.mark.mobile
class TestMobileFlow:

    # @pytest.mark.parametrize("platform",
    #      [
    #          pytest.param("android", marks=pytest.mark.android),
    #          pytest.param("ios", marks=pytest.mark.ios),
    #      ]
    #      )
    @pytest.mark.parametrize(
        "platform,story",
        [
            pytest.param("android", "Android: App Login & Dashboard Validation", marks=pytest.mark.android, id="android"),
            pytest.param("ios", "iOS: App Login & Dashboard Validation", marks=pytest.mark.ios, id="ios"),
        ],
    )
    @allure.story("Login & Dashboard")
    def test_flow_login(self, driver,platform,story):
        if not driver: pytest.fail("Driver Failed")

        # 1. Complete Login Flow (Working Fine)
        MobileLoginPage(driver).perform_full_login()

        # 2. Dashboard Validation (New Steps)
        MobileDashboardPage(driver).validate_full_dashboard()
