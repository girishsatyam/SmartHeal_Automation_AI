import pytest
import allure

from tests.web.pages.WebLoginPage import WebLoginPage
from tests.common.web.helpers import (
    click_any_text_contains,
    find_with_frames,
    click_element,
    attach_state,
    ensure_in_view,
)

from tests.common.waits import sleep_with_reason
from selenium.webdriver.common.by import By
from selenium.webdriver import ActionChains


@allure.feature("ITP Full Flow (Web)")
@pytest.mark.web
class TestITPFullFlow:
    @allure.story("Login -> Field -> Test Plans -> Create Test Plans")
    def test_itp_create_test_plan(self, driver):
        # Follow same initial flow as tests/web/test_web_login.py
        if not driver:
            pytest.fail("Web Driver Failed")

        page = WebLoginPage(driver)
        page.perform_full_login()  # Ensures landing on Dashboard page

        # Now perform post-login steps as requested
        with allure.step("Open Field menu from header (.nav-item)"):
            field_el = None
            # Prefer explicit nav-item match to avoid clicking similarly named content elsewhere
            try:
                xp = "//*[contains(@class,'nav-item')][.//*[contains(normalize-space(),'Field')] or contains(normalize-space(.),'Field')]"
                field_el = find_with_frames(driver, By.XPATH, xp, timeout=8, clickable=True)
            except Exception:
                field_el = None
            if not field_el:
                # Fallback to text-based click
                click_any_text_contains(driver, ["Field"])  # best-effort
            else:
                try:
                    ActionChains(driver).move_to_element(field_el).pause(0.2).perform()  # open dropdown via hover if needed
                except Exception:
                    pass
                if not click_element(driver, field_el):
                    try:
                        driver.execute_script("arguments[0].click();", field_el)
                    except Exception:
                        pass
            sleep_with_reason(0.4, "post Field open settle")

        with allure.step("Click Test Plans in Field dropdown"):
            clicked_tp = False
            # Try within common dropdown/menu containers first
            try:
                xp_tp = (
                    "(//div[contains(@class,'dropdown') or contains(@class,'menu') or contains(@class,'nav')]"
                    "//a[contains(normalize-space(),'Test Plans') or contains(normalize-space(),'Test plans')])[1]"
                )
                el_tp = find_with_frames(driver, By.XPATH, xp_tp, timeout=6, clickable=True)
                if el_tp:
                    clicked_tp = click_element(driver, el_tp)
            except Exception:
                pass
            if not clicked_tp:
                clicked_tp = click_any_text_contains(driver, ["Test Plans", "Test plans"])  # broad fallback
            if not clicked_tp:
                try:
                    attach_state(driver, "no-test-plans-link")
                except Exception:
                    pass
                pytest.fail("Could not click 'Test Plans' from Field dropdown")

        with allure.step("Smart wait for Test Plans page to load (60s)"):
            sleep_with_reason(60, "Wait for Test Plans page to fully load")


        with allure.step("Click 'Create Test Plans' button (center of page)"):
            clicked_create = False

            # Try a few scroll positions around the middle to surface the button
            try:
                driver.execute_script(
                    "window.scrollTo(0, Math.max(0, (document.body.scrollHeight - window.innerHeight) * 0.45));"
                )
                sleep_with_reason(0.2, "pre-search center scroll")
            except Exception:
                pass

            def _try_click_create(timeout_each=6):
                # Prefer button/link/role=button with exact/near text
                xpaths = [
                    "//*[self::button or self::a or @role='button'][contains(translate(normalize-space(.),'ABCDEFGHIJKLMNOPQRSTUVWXYZ','abcdefghijklmnopqrstuvwxyz'),'create test plans')]",
                    "//*[self::button or self::a or @role='button'][contains(translate(normalize-space(.),'ABCDEFGHIJKLMNOPQRSTUVWXYZ','abcdefghijklmnopqrstuvwxyz'),'create test plan')]",
                    "//*[self::button or self::a or @role='button'][contains(translate(normalize-space(.),'ABCDEFGHIJKLMNOPQRSTUVWXYZ','abcdefghijklmnopqrstuvwxyz'),'create') and contains(translate(normalize-space(.),'ABCDEFGHIJKLMNOPQRSTUVWXYZ','abcdefghijklmnopqrstuvwxyz'),'test')]",
                ]
                for xp in xpaths:
                    el = find_with_frames(driver, By.XPATH, xp, timeout=timeout_each, clickable=True)
                    if el:
                        try:
                            ensure_in_view(driver, el)
                        except Exception:
                            pass
                        if click_element(driver, el):
                            return True
                # aria-label and id heuristics
                xp_aria = (
                    "//*[@aria-label and contains(translate(@aria-label,'ABCDEFGHIJKLMNOPQRSTUVWXYZ','abcdefghijklmnopqrstuvwxyz'),'create') and "
                    "(contains(translate(@aria-label,'ABCDEFGHIJKLMNOPQRSTUVWXYZ','abcdefghijklmnopqrstuvwxyz'),'test') or "
                    " contains(translate(@aria-label,'ABCDEFGHIJKLMNOPQRSTUVWXYZ','abcdefghijklmnopqrstuvwxyz'),'plan'))]"
                )
                el = find_with_frames(driver, By.XPATH, xp_aria, timeout=4, clickable=True)
                if el:
                    try:
                        ensure_in_view(driver, el)
                    except Exception:
                        pass
                    if click_element(driver, el):
                        return True
                xp_id = "//*[contains(translate(@id,'ABCDEFGHIJKLMNOPQRSTUVWXYZ','abcdefghijklmnopqrstuvwxyz'),'create') and (contains(translate(@id,'ABCDEFGHIJKLMNOPQRSTUVWXYZ','abcdefghijklmnopqrstuvwxyz'),'test') or contains(translate(@id,'ABCDEFGHIJKLMNOPQRSTUVWXYZ','abcdefghijklmnopqrstuvwxyz'),'plan'))]"
                el = find_with_frames(driver, By.XPATH, xp_id, timeout=4, clickable=True)
                if el:
                    try:
                        ensure_in_view(driver, el)
                    except Exception:
                        pass
                    if click_element(driver, el):
                        return True
                # Broad text fallback
                return click_any_text_contains(driver, ["Create Test Plans", "Create Test Plan", "Create Test", "Create"])

            # Attempt with progressive scrolling if needed
            for y_ratio in (0.45, 0.55, 0.35, 0.65):
                if clicked_create:
                    break
                try:
                    driver.execute_script(
                        "window.scrollTo(0, Math.max(0, (document.body.scrollHeight - window.innerHeight) * arguments[0]));",
                        y_ratio,
                    )
                    sleep_with_reason(0.2, f"scroll ratio {y_ratio}")
                except Exception:
                    pass
                clicked_create = _try_click_create(timeout_each=6)

            if not clicked_create:
                # Final fallback: deep shadow-DOM search + cross-frame JS clicker
                def _deep_click_create_across_frames(max_depth=8):
                    js = r"""
return (function(){
  const toks = ['create','test','plan'];
  const L = (s)=> (s||'').toLowerCase();
  function isMatch(el){
    const text = L((el.innerText||el.textContent||''));
    const aria = L(el.getAttribute && el.getAttribute('aria-label'));
    const title = L(el.getAttribute && el.getAttribute('title'));
    const id    = L(el.id);
    const dtid  = L(el.getAttribute && el.getAttribute('data-testid'));
    const bag = [text, aria, title, id, dtid].join(' ');
    // require at least 'create' and either 'test' or 'plan'
    const hasCreate = bag.includes('create');
    const hasTestOrPlan = bag.includes('test') || bag.includes('plan');
    return hasCreate && hasTestOrPlan;
  }
  function clickableAncestor(node){
    let cur = node;
    while(cur){
      try{
        if(cur.matches && cur.matches('button, a, [role="button"], .btn, .button')) return cur;
        if(cur.onclick) return cur;
      }catch(e){}
      // ascend across shadow boundary if needed
      const root = cur.getRootNode && cur.getRootNode();
      if(root && root.host && root.host !== cur){ cur = root.host; continue; }
      cur = cur.parentElement;
    }
    return node;
  }
  function walk(root){
    const stack = [root];
    let best = null, bestScore = -1;
    while(stack.length){
      const node = stack.pop();
      if(!node) continue;
      if(node.nodeType === 1){
        // score candidates
        if(isMatch(node)){
          let score = 0;
          try{ if(node.matches && node.matches('button, a, [role="button"], .btn, .button')) score += 3; }catch(e){}
          const text = L((node.innerText||node.textContent||''));
          if(text.includes('create test plan') || text.includes('create test plans')) score += 3;
          if(text) score += 1;
          if(score > bestScore){ best = node; bestScore = score; }
        }
        // push shadow root first for depth-first
        try{ if(node.shadowRoot) stack.push(node.shadowRoot); }catch(e){}
        try{ const kids = node.querySelectorAll('*'); for(const k of kids) stack.push(k); }catch(e){}
      }
    }
    if(!best) return false;
    let target = clickableAncestor(best);
    try{ target.scrollIntoView({block:'center', inline:'center'}); }catch(e){}
    try{ target.click(); return true; }catch(e){}
    try{ const ev = document.createEvent('MouseEvents'); ev.initEvent('click', true, true); target.dispatchEvent(ev); return true; }catch(e){}
    return false;
  }
  try{ return !!walk(document); }catch(e){ return false; }
})();
"""
                    def _click_here():
                        try:
                            return bool(driver.execute_script(js))
                        except Exception:
                            return False
                    def _recurse(depth):
                        if _click_here():
                            return True
                        if depth >= max_depth:
                            return False
                        try:
                            frames = driver.find_elements(By.CSS_SELECTOR, "iframe, frame")
                        except Exception:
                            frames = []
                        for fr in frames[:12]:
                            try:
                                driver.switch_to.frame(fr)
                                if _recurse(depth + 1):
                                    return True
                            except Exception:
                                pass
                            finally:
                                try:
                                    driver.switch_to.parent_frame()
                                except Exception:
                                    try:
                                        driver.switch_to.default_content()
                                    except Exception:
                                        pass
                        return False
                    try:
                        driver.switch_to.default_content()
                    except Exception:
                        pass
                    return _recurse(0)

                clicked_create = _deep_click_create_across_frames()

            if not clicked_create:
                try:
                    attach_state(driver, "no-create-test-plan")
                except Exception:
                    pass
                pytest.fail("Could not click 'Create Test Plans' button")

            # Smart wait after successful click (30s)
            sleep_with_reason(60, "post Create Test Plans click settle (60s)")
