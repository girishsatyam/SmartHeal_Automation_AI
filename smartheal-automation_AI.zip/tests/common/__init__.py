"""
Shared common utilities for tests.

Usage examples:
    from tests.common import get_bundle_id, AppLifecycleManager, get_alluredir
"""

from .utils import is_truthy, get_bundle_id
from .device import AppLifecycleManager, IOSLifecycleManager
from .reporting import (
    get_alluredir,
    resolve_executor_name,
    write_executor_json,
    detect_platforms_from_results,
    platform_string,
)
from .actions import open_test_plans
from .waits import (
    wait_until,
    wait_for_presence,
    wait_for_visible,
    wait_for_enabled,
    wait_for_ui_stability,
    sleep_with_reason,
    safe_click,
)
from .constants import (
    IOS_CLOSE_NAMES,
    UI_STABILITY_DEFAULT_DURATION,
    UI_STABILITY_DEFAULT_WINDOW,
    SLEEP_SHORT,
    SLEEP_MED,
    SLEEP_LONG,
    DEFAULT_PROJECT_NAME,
    DEFAULT_POST_CLICK_DELAY,
)

__all__ = [
    # utils
    "is_truthy",
    "get_bundle_id",
    # device lifecycle
    "AppLifecycleManager",
    "IOSLifecycleManager",
    # reporting
    "get_alluredir",
    "resolve_executor_name",
    "write_executor_json",
    "detect_platforms_from_results",
    "platform_string",
    # actions
    "open_test_plans",
    # waits
    "wait_until",
    "wait_for_presence",
    "wait_for_visible",
    "wait_for_enabled",
    "wait_for_ui_stability",
    "sleep_with_reason",
    "safe_click",
    # constants
    "IOS_CLOSE_NAMES",
    "UI_STABILITY_DEFAULT_DURATION",
    "UI_STABILITY_DEFAULT_WINDOW",
    "SLEEP_SHORT",
    "SLEEP_MED",
    "SLEEP_LONG",
    "DEFAULT_PROJECT_NAME",
    "DEFAULT_POST_CLICK_DELAY",
]
