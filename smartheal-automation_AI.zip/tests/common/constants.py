# Common, reusable constants to avoid hardcoding across tests/pages

# iOS close/dismiss button candidate names used to detect and close banners/modals
IOS_CLOSE_NAMES = [
    "CloseButton",
    "Close",
    "Dismiss",
    "OK",
    "Got it",
    "Got It",
    "Done",
    "Cancel",
]

# Default heuristic UI stability wait parameters
UI_STABILITY_DEFAULT_DURATION = 4.0   # total time budget to observe stability
UI_STABILITY_DEFAULT_WINDOW = 1.0     # required continuous stable window

# Generic small delays for fallbacks (use waits.wait_for_ui_stability when possible)
SLEEP_SHORT = 0.3
SLEEP_MED = 0.8
SLEEP_LONG = 2.0

# iOS dashboard header accessibility ids (avoid hardcoding)
IOS_DASHBOARD_TITLE_IDS = ("ProjectTitle", "ProjectTitleHeader")

# Common iOS menu button accessibility ids
IOS_MENU_A11Y_IDS = ("Menu", "menu", "More", "more", "Options", "options")

# Common iOS action button labels used to dismiss sheets/alerts
IOS_DONE_OK_SELECT = ("Done", "OK", "Select", "Close")

# Web: texts that may reveal classic username/password login
WEB_AUTH_OPTION_TEXTS = [
    "Sign in with Aconex username and password",
    "Aconex username",
    "Aconex login",
    "Use your Aconex login",
    "Other sign-in options",
    "Other methods",
    "Sign in with password",
    "Use password instead",
    "Company SSO",
    "Oracle SSO",
]

# Default fallback project name across tests if test data missing
DEFAULT_PROJECT_NAME = "AcxQASanity"

# Post-click default delay if needed (prefer stability wait)
DEFAULT_POST_CLICK_DELAY = 0.0

__all__ = [
    "IOS_CLOSE_NAMES",
    "UI_STABILITY_DEFAULT_DURATION",
    "UI_STABILITY_DEFAULT_WINDOW",
    "SLEEP_SHORT",
    "SLEEP_MED",
    "SLEEP_LONG",
    "IOS_DASHBOARD_TITLE_IDS",
    "IOS_MENU_A11Y_IDS",
    "IOS_DONE_OK_SELECT",
    "WEB_AUTH_OPTION_TEXTS",
    "DEFAULT_PROJECT_NAME",
    "DEFAULT_POST_CLICK_DELAY",
]
