from tests.common.waits import wait_for_ui_stability, sleep_with_reason, safe_click


def open_test_plans(page):
    """
    Common action to open Test Plans from the dashboard.

    Expects `page` to be a SmartHealBasePage (or subclass) instance with:
      - attributes: platform
      - methods: _ensure_banner_closed_ios, scroll_to_find, find, _tap_element_center
    """
    print("[DASHBOARD] Opening Test Plans...")
    # iOS safety: ensure any landing banner is dismissed before interacting
    # if getattr(page, "platform", None) == "ios":
    #     try:
    #         page._ensure_banner_closed_ios(timeout=6)
    #     except Exception:
    #         pass

    # Locate the Test Plans button with smart scroll/heal
    btn = None
    try:
        btn = page.scroll_to_find("test_plans_button")
    except Exception:
        try:
            btn = page.find("test_plans_button", timeout=8, optional=True)
        except Exception:
            btn = None
    if not btn:
        raise Exception("Test Plans button not found on Dashboard")

    # Click with robust fallback and wait for stability
    safe_click(btn, fallback_tap=page._tap_element_center)
    try:
        wait_for_ui_stability(page.driver, duration=4.0, window=1.0)
    except Exception:
        pass
    sleep_with_reason(0.5, "post Test Plans open settle")


def open_issues(page):
    """
    Common action to open Test Plans from the dashboard.

    Expects `page` to be a SmartHealBasePage (or subclass) instance with:
      - attributes: platform
      - methods: _ensure_banner_closed_ios, scroll_to_find, find, _tap_element_center
    """
    print("[DASHBOARD] Opening Issues...")
    # iOS safety: ensure any landing banner is dismissed before interacting
    #if getattr(page, "platform", None) == "ios":
        # try:
        #     page._ensure_banner_closed_ios(timeout=6)
        # except Exception:
        #     pass

    # Locate the Test Plans button with smart scroll/heal
    btn = None
    try:
        btn = page.scroll_to_find("issues_button")
    except Exception:
        try:
            btn = page.find("issues_button", timeout=8, optional=True)
        except Exception:
            btn = None
    if not btn:
        raise Exception("Issues button not found on Dashboard")

    # Click with robust fallback and wait for stability
    safe_click(btn, fallback_tap=page._tap_element_center)
    try:
        wait_for_ui_stability(page.driver, duration=4.0, window=1.0)
    except Exception:
        pass
    sleep_with_reason(0.5, "post Issues open settle")

def open_documents(page):
    print("[DASHBOARD] Opening Documents...")
    btn = None
    try:
        btn = page.scroll_to_find("documents_button")
    except Exception:
        try:
            btn = page.find("documents_button", timeout=8, optional=True)
        except Exception:
            btn = None
    if not btn:
        raise Exception("Documents button not found on Dashboard")

    # Click with robust fallback and wait for stability
    safe_click(btn, fallback_tap=page._tap_element_center)
    try:
        wait_for_ui_stability(page.driver, duration=4.0, window=1.0)
    except Exception:
        pass
    sleep_with_reason(0.5, "post Documents open settle")

__all__ = ["open_test_plans","open_issues","open_documents"]
