import yaml
import os
import time
import re
from appium.webdriver.common.appiumby import AppiumBy
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from smartheal.config import get_locators_path, get_smartheal_config
from smartheal.generator import CandidateGenerator, _normalize_text
from smartheal.ranking import Ranker, _strategy_family_of
from smartheal.repair import RepairAgent
from tests.common.waits import wait_for_ui_stability, sleep_with_reason
from tests.common.constants import IOS_CLOSE_NAMES

os.environ.setdefault("TOKENIZERS_PARALLELISM", "false")


class SmartHealBasePage:
    def __init__(self, driver):
        self.driver = driver
        # Robust platform detection
        try:
            caps = getattr(driver, 'capabilities', {}) or {}
        except Exception:
            caps = {}
        if caps:
            plat = str(caps.get('platformName') or caps.get('platform') or '').lower()
            if caps.get('browserName') or plat in ('mac', 'windows', 'linux', 'any', 'darwin'):
                self.platform = 'web'
            else:
                self.platform = plat if plat else 'android'
        else:
            self.platform = 'web'
        self.page_name = self.__class__.__name__
        self.locators = self._load_yaml()
        self.generator = None
        self.ranker = None
        self.repair_agent = None

    def _load_yaml(self):
        path = os.path.join(get_locators_path(self.platform), f"{self.page_name}.yaml")
        if os.path.exists(path):
            with open(path, 'r') as f:
                return yaml.safe_load(f) or {}
        return {}

    def _tap_element_center(self, el):
        try:
            r = getattr(el, "rect", None) or {}
            x = int(r.get("x", 0) + r.get("width", 0) / 2)
            y = int(r.get("y", 0) + r.get("height", 0) / 2)
            try:
                self.driver.execute_script("mobile: tap", {"x": x, "y": y})
            except Exception:
                try:
                    actions = {
                        "actions": [
                            {
                                "type": "pointer",
                                "id": "finger1",
                                "parameters": {"pointerType": "touch"},
                                "actions": [
                                    {"type": "pointerMove", "duration": 0, "x": x, "y": y},
                                    {"type": "pointerDown", "button": 0},
                                    {"type": "pause", "duration": 100},
                                    {"type": "pointerUp", "button": 0},
                                ],
                            }
                        ]
                    }
                    self.driver.perform(actions)
                except Exception:
                    pass
            sleep_with_reason(0.2, "post center tap")
        except Exception:
            pass

    def _find_banner_close_ios(self):
        # (Snippet for iOS banner closing - unchanged)
        names = IOS_CLOSE_NAMES
        try:
            meta = self.locators.get("landing_close_button", {})
            aid = meta.get("default_locator")
            if aid:
                try:
                    return self.driver.find_element(AppiumBy.ACCESSIBILITY_ID, aid)
                except Exception:
                    pass
        except Exception:
            pass
        try:
            meta = self.locators.get("btn_close", {})
            aid = meta.get("default_locator")
            if aid:
                try:
                    return self.driver.find_element(AppiumBy.ACCESSIBILITY_ID, aid)
                except Exception:
                    pass
        except Exception:
            pass
        for n in names:
            try:
                return self.driver.find_element(
                    AppiumBy.IOS_PREDICATE,
                    f"type == 'XCUIElementTypeButton' AND (name == '{n}' OR label == '{n}' OR name CONTAINS[c] '{n}' OR label CONTAINS[c] '{n}')",
                )
            except Exception:
                continue
        return None

    def _ios_candidate_ok(self, key, meta, cand):
        strat = cand.get('strategy')
        loc = str(cand.get('locator', ''))
        conf = float(cand.get('ml_confidence', cand.get('semantic_score', 0)))
        if strat == 'id':
            return False
        if conf <= 0.6:
            return False
        if strat == 'xpath' and re.match(r"^//XCUIElementType[A-Za-z]+$", loc):
            return False
        if strat == 'xpath':
            low = loc.replace(' ', '').lower()
            if (
                    '@name' not in low and '@label' not in low and 'normalize-space(text())' not in low and 'contains(.' not in low):
                return False
        if strat in ('ios_predicate', 'predicate'):
            low = loc.lower()
            if ('name' not in low and 'label' not in low):
                return False
        return True

    def scroll_to_find(self, key):
        if self.platform == 'web': return self.find(key)
        print(f"Scrolling to find: {key}")
        max_scrolls = 3
        for i in range(max_scrolls):
            try:
                return self.find(key, timeout=2)
            except:
                print("   - Scrolling down...")
                size = self.driver.get_window_size()
                start_x = size['width'] / 2
                start_y = size['height'] * (0.7 if self.platform == 'ios' else 0.8)
                end_y = size['height'] * (0.3 if self.platform == 'ios' else 0.2)
                self.driver.swipe(start_x, start_y, start_x, end_y, 1000)
                sleep_with_reason(1, "post scroll settle")
        return self.find(key)

    def find(self, key, timeout=10, optional=False):
        # iOS can be slower due to animations and permission banners; extend default wait
        eff_timeout = max(timeout, 20) if self.platform == 'ios' else timeout
        element = None
        try:
            element = self._find_native(key, eff_timeout)
        except Exception:
            if optional:
                return None
            print(f"[{self.platform}] '{key}' failed. Engaging SmartHeal...")
            if self._heal_locator(key):
                print("Healing successful. Retrying...")
                try:
                    wait_for_ui_stability(self.driver, duration=3.0, window=1.0)
                except Exception:
                    pass
                try:
                    element = self._find_native(key, eff_timeout)
                except Exception:
                    pass

            # If still failing, raise error (unless optional)
            if not element:
                # If this key recently had a promoted locator, attempt rollback for safety.
                try:
                    if not self.repair_agent:
                        self.repair_agent = RepairAgent()
                    self.repair_agent.record_failure(self.platform, self.page_name, key)
                    # refresh in-memory locators after rollback
                    self.locators = self._load_yaml()
                except Exception:
                    pass
                if not optional:
                    raise Exception(f"SmartHeal failed for '{key}'")
                return None

        # If probation is enabled and this key has a proposed locator staged, record success.
        # This gradually promotes proposed locator after N successful uses.
        try:
            if not self.repair_agent:
                self.repair_agent = RepairAgent()
            self.repair_agent.record_success(self.platform, self.page_name, key)
            # refresh in-memory locators if promotion happened
            try:
                self.locators = self._load_yaml()
            except Exception:
                pass
        except Exception:
            pass

        # --- REVERSE HEALING: CHECK SEMANTIC LABEL DRIFT ---
        if element:
            # Robust attribute capture: query individually so one failure doesn't abort the whole block
            def _safe_attr(attr_name):
                try:
                    return element.get_attribute(attr_name)
                except Exception:
                    return None

            try:
                texts = []
                # element.text access
                try:
                    texts.append(getattr(element, 'text', None))
                except Exception:
                    texts.append(None)
                # common attributes across platforms
                for attr in ("text", "value", "content-desc", "label", "name", "innerText"):
                    texts.append(_safe_attr(attr))

                actual_text = next((t for t in texts if t and str(t).strip()), "")

                locator_data = self.locators.get(key, {})
                expected_label = locator_data.get('semantic_label', '')

                if actual_text and expected_label:
                    norm_actual = _normalize_text(actual_text)
                    norm_expected = _normalize_text(expected_label)

                    # Debounce reverse-healing to avoid oscillation and reduce YAML churn.
                    try:
                        cfg = get_smartheal_config() or {}
                        debounce_ms = int(cfg.get('debounce_label_ms', 30000))
                    except Exception:
                        debounce_ms = 30000

                    def _is_dynamic_like(s: str) -> bool:
                        # Heuristic: ignore strings that are mostly numbers/symbols (timestamps/counters)
                        try:
                            s = (s or '').strip()
                            if not s:
                                return True
                            alnum = sum(1 for ch in s if ch.isalnum())
                            digits = sum(1 for ch in s if ch.isdigit())
                            # If >60% digits, likely dynamic
                            return (alnum > 0 and digits / max(1, alnum) > 0.60)
                        except Exception:
                            return False

                    if norm_actual != norm_expected and not norm_actual.isdigit() and not _is_dynamic_like(actual_text):
                        if not self.repair_agent:
                            self.repair_agent = RepairAgent()

                        # Debounce window check (uses YAML timestamp if present)
                        allow = True
                        try:
                            meta = locator_data or {}
                            last_ts = meta.get('last_label_healed')
                            if last_ts:
                                from datetime import datetime
                                try:
                                    last_dt = datetime.fromisoformat(str(last_ts))
                                    age_ms = (datetime.now() - last_dt).total_seconds() * 1000.0
                                    if age_ms < debounce_ms:
                                        allow = False
                                except Exception:
                                    pass
                        except Exception:
                            pass

                        if not allow:
                            return element

                        if self.repair_agent.update_semantic_label(
                            platform=self.platform,
                            page_name=self.page_name,
                            locator_key=key,
                            new_label=actual_text
                        ):
                            # refresh in-memory cache so subsequent steps see latest labels
                            try:
                                self.locators = self._load_yaml()
                            except Exception:
                                pass
            except Exception:
                pass
        # ----------------------------------------------------

        return element

    def _heal_locator(self, key):
        try:
            dom = self.driver.page_source
        except Exception:
            return False
        if key not in self.locators or not isinstance(self.locators.get(key), dict):
            return False
        meta = self.locators[key]
        if not self.generator:
            self.generator = CandidateGenerator()
        if not self.ranker:
            self.ranker = Ranker()

        candidates = self.generator.find_candidates(meta, dom, self.platform)
        if not candidates:
            return False
        try:
            prev_fam = _strategy_family_of(meta.get('strategy'))
            for c in candidates:
                c['prev_strategy_family'] = prev_fam
        except Exception:
            pass
        ranked = self.ranker.rank_candidates(candidates)
        # Configurable TOP_K with safe default
        try:
            cfg = get_smartheal_config() or {}
            TOP_K = int(cfg.get('top_k', 10))
        except Exception:
            TOP_K = 10
        # Enforce global minimum confidence floor (never below 0.50)
        try:
            min_floor = float((cfg if 'cfg' in locals() else {}).get('min_confidence_floor', 0.50))
        except Exception:
            min_floor = 0.50
        if min_floor < 0.50:
            min_floor = 0.50
        # Interactable gate toggle
        try:
            interact_gate = bool((cfg if 'cfg' in locals() else {}).get('post_probe_interactable_gate', True))
        except Exception:
            interact_gate = True

        # Early-stop: accept first live-probe-ok candidate above safe_early_stop_conf
        try:
            safe_early_stop = float((cfg if 'cfg' in locals() else {}).get('safe_early_stop_conf', 0.95))
        except Exception:
            safe_early_stop = 0.95

        for idx, c in enumerate(ranked[:TOP_K]):
            # Skip low-confidence candidates early to avoid noisy live probes
            try:
                conf_check = float(c.get('ml_confidence', c.get('semantic_score', 0)))
            except Exception:
                conf_check = 0.0
            if conf_check < min_floor:
                continue
            el = self._try_locate(c.get('strategy'), c.get('locator'), timeout=2)
            if el is None:
                continue
            # Post-probe interactability gate to avoid non-visible/disabled elements
            if interact_gate:
                try:
                    vis_ok = True
                    ena_ok = True
                    try:
                        vis_ok = bool(el.is_displayed())
                    except Exception:
                        pass
                    try:
                        ena_ok = bool(el.is_enabled())
                    except Exception:
                        pass
                    if not (vis_ok and ena_ok):
                        continue
                except Exception:
                    pass
            conf = float(c.get('ml_confidence', c.get('semantic_score', 0)))
            if self.platform == 'ios' and not self._ios_candidate_ok(key, meta, c):
                continue
            # Strict healing: accept only candidates meeting the configured floor (>= 0.50 enforced)
            if conf < min_floor:
                continue

            chosen = dict(c)
            chosen['live_probe_ok'] = True
            chosen['rank_index'] = idx
            if not self.repair_agent:
                self.repair_agent = RepairAgent()
            success = self.repair_agent.apply_fix(self.platform, self.page_name, key, chosen)
            if success:
                self.locators = self._load_yaml()
                # If this was a very high-confidence hit, stop immediately.
                try:
                    if conf >= safe_early_stop:
                        return True
                except Exception:
                    pass
                return True
        return False

    def _try_locate(self, strategy, locator, timeout=3):
        try:
            if self.platform == 'web':
                by = By.XPATH
                if strategy == 'id':
                    by = By.ID
                return WebDriverWait(self.driver, timeout).until(EC.presence_of_element_located((by, locator)))
            else:
                by = AppiumBy.XPATH
                if strategy == 'accessibility_id':
                    by = AppiumBy.ACCESSIBILITY_ID
                elif strategy == 'id':
                    by = AppiumBy.ID
                elif strategy in ('ios_predicate', 'predicate'):
                    by = AppiumBy.IOS_PREDICATE
                elif strategy in ('ios_class_chain', 'class_chain'):
                    by = AppiumBy.IOS_CLASS_CHAIN
                elif strategy in ('ui_automator', 'automator'):
                    by = AppiumBy.ANDROID_UIAUTOMATOR
                return WebDriverWait(self.driver, timeout).until(EC.presence_of_element_located((by, locator)))
        except Exception:
            return None

    def _emergency_fallback_heal(self, key):
        return False

    def _find_native(self, key, timeout):
        if key not in self.locators: raise KeyError(f"Key {key} missing")
        data = self.locators[key]
        val = data.get('default_locator')
        by = By.XPATH
        if self.platform != 'web':
            by = AppiumBy.XPATH
            if data.get('strategy') == 'accessibility_id':
                by = AppiumBy.ACCESSIBILITY_ID
            elif data.get('strategy') == 'id':
                by = AppiumBy.ID
            elif data.get('strategy') in ('ios_predicate', 'predicate'):
                by = AppiumBy.IOS_PREDICATE
            elif data.get('strategy') in ('ios_class_chain', 'class_chain'):
                by = AppiumBy.IOS_CLASS_CHAIN
            elif data.get('strategy') in ('ui_automator', 'automator'):
                by = AppiumBy.ANDROID_UIAUTOMATOR
            if self.platform == 'ios' and by == AppiumBy.ID:
                by = AppiumBy.ACCESSIBILITY_ID
        else:
            if data.get('strategy') == 'id': by = By.ID

        if self.platform != 'web' and by == AppiumBy.ACCESSIBILITY_ID and isinstance(val,
                                                                                     str) and val.strip().startswith(
                '/'):
            by = AppiumBy.XPATH
        if self.platform != 'web' and by == AppiumBy.ID and isinstance(val, str) and val.strip().startswith('/'):
            by = AppiumBy.XPATH

        return WebDriverWait(self.driver, timeout).until(EC.presence_of_element_located((by, val)))

    def click_on_element(self, element, optional=False):
        wait_for_ui_stability(self.driver, duration=3.0, window=1.0)
        found = self.find(element, optional=optional)
        if found:
            found.click()
            sleep_with_reason(3, "Waiting for the page to load")

    def send_keys_to_element(self, element, keys, timeout=10, optional=False):
        el = self.find(element, timeout=timeout, optional=optional)
        if not el:
            return
        try:
            try:
                el.click()
            except Exception:
                pass
            try:
                el.clear()
            except Exception:
                pass
            el.send_keys(keys)
        except Exception:
            # Fallbacks for tricky inputs
            try:
                self._tap_element_center(el)
            except Exception:
                pass
            try:
                # Appium extension: set_value works on some fields when send_keys fails
                set_value = getattr(el, 'set_value', None)
                if callable(set_value):
                    set_value(keys)
                else:
                    # last resort: re-try send_keys once more
                    el.send_keys(keys)
            except Exception:
                # propagate the original error by re-raising
                raise
        sleep_with_reason(3, "Waiting for data to be filled")