import os
import json
from fpdf import FPDF
from datetime import datetime


class TestReportPDF(FPDF):
    def header(self):
        self.set_font('Arial', 'B', 15)
        self.cell(0, 10, 'Automation Execution Report', 0, 1, 'C')
        self.ln(5)

    def footer(self):
        self.set_y(-15)
        self.set_font('Arial', 'I', 8)
        self.cell(0, 10, f'Page {self.page_no()}', 0, 0, 'C')


def generate_pdf_report(alluredir, output_path):
    """
    Reads Allure JSON results from `alluredir` and creates a PDF summary at `output_path`.
    """
    if not os.path.exists(alluredir):
        print(f"[PDF] Allure directory not found: {alluredir}")
        return

    # 1. Parse Results
    total = 0
    passed = 0
    failed = 0
    skipped = 0
    broken = 0
    failures = []

    for fname in os.listdir(alluredir):
        if fname.endswith("-result.json"):
            try:
                with open(os.path.join(alluredir, fname), "r", encoding="utf-8") as f:
                    data = json.load(f)
                    status = data.get("status", "unknown")
                    total += 1

                    if status == "passed":
                        passed += 1
                    elif status == "failed":
                        failed += 1
                        failures.append(data)
                    elif status == "skipped":
                        skipped += 1
                    elif status == "broken":
                        broken += 1
                        failures.append(data)
            except Exception:
                pass

    # 2. Build PDF
    pdf = TestReportPDF()
    pdf.add_page()
    pdf.set_font("Arial", size=12)

    # -- Summary Section --
    pdf.set_font("Arial", 'B', 12)
    pdf.cell(0, 10, f"Date: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}", 0, 1)
    pdf.ln(5)

    # Draw stats table
    pdf.set_fill_color(240, 240, 240)
    pdf.cell(0, 10, "Execution Summary", 0, 1, 'L', 1)
    pdf.set_font("Arial", size=11)

    # Helper to draw rows
    def draw_row(label, value, color=(0, 0, 0)):
        pdf.set_text_color(*color)
        pdf.cell(50, 10, label, 0, 0)
        pdf.set_text_color(0, 0, 0)
        pdf.cell(0, 10, str(value), 0, 1)

    draw_row("Total Tests:", total)
    draw_row("Passed:", passed, (0, 128, 0))  # Green
    draw_row("Failed:", failed, (255, 0, 0))  # Red
    draw_row("Broken:", broken, (255, 165, 0))  # Orange
    draw_row("Skipped:", skipped, (128, 128, 128))  # Gray

    pdf.ln(10)

    # -- Failures Section --
    if failures:
        pdf.set_font("Arial", 'B', 12)
        pdf.set_fill_color(255, 220, 220)
        pdf.cell(0, 10, "Failed Test Details", 0, 1, 'L', 1)
        pdf.ln(2)

        pdf.set_font("Arial", size=10)
        for fail in failures:
            name = fail.get("name", "Unknown Test")
            # Try to get error message
            msg = "No error message found."
            if "statusDetails" in fail:
                msg = fail["statusDetails"].get("message", msg)

            # Clean up message for PDF
            msg = str(msg).replace("\n", " ").strip()
            if len(msg) > 300: msg = msg[:300] + "..."

            pdf.set_font("Arial", 'B', 10)
            pdf.multi_cell(0, 6, f"Test: {name}")
            pdf.set_font("Arial", '', 9)
            pdf.set_text_color(200, 0, 0)
            pdf.multi_cell(0, 6, f"Error: {msg}")
            pdf.set_text_color(0, 0, 0)
            pdf.ln(2)
            pdf.line(pdf.get_x(), pdf.get_y(), 190, pdf.get_y())
            pdf.ln(4)
    else:
        pdf.set_font("Arial", 'I', 10)
        pdf.cell(0, 10, "No failures recorded.", 0, 1)

    # 3. Output
    try:
        pdf.output(output_path)
    except Exception as e:
        print(f"[PDF] Failed to save PDF: {e}")