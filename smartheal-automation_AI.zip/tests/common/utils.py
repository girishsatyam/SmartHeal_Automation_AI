from datetime import datetime
import os
import plistlib
import random
from appium.webdriver.common.appiumby import AppiumBy
from selenium.webdriver.common.actions.pointer_input import PointerInput
from selenium.webdriver.common.actions.action_builder import ActionBuilder
from selenium.webdriver.common.actions.interaction import Interaction
import time
from typing import Any, Tuple

# Optional TouchAction import (Appium Python Client v2 may not provide it)
try:
    from appium.webdriver.common.touch_action import TouchAction  # type: ignore
except Exception:
    TouchAction = None  # type: ignore


def is_truthy(val) -> bool:
    """
    Normalize various truthy strings/values to a boolean True.
    Accepts: "1", "true", "yes", "on" (case-insensitive).
    """
    return str(val or "").strip().lower() in ("1", "true", "yes", "on")


def get_bundle_id(app_path: str) -> str | None:
    """
    Read CFBundleIdentifier from a .app bundle's Info.plist.
    Returns None if it cannot be determined.
    """
    try:
        info_plist = os.path.join(app_path, "Info.plist")
        with open(info_plist, "rb") as f:
            info = plistlib.load(f)
            return info.get("CFBundleIdentifier")
    except Exception:
        return None

def random_5_digit_number():
    return str(random.randint(10000, 99999))

def get_current_timestamp():
    # Format with milliseconds, similar to Java's truncatedTo(ChronoUnit.MILLIS)
    return datetime.now().strftime('%Y-%m-%dT%H:%M:%S.%f')[:-3]

def drag_form_up(driver, properties_target: Any, swipe_distance: int = 200, duration: int = 500):
    """
    Drag the form up by simulating a swipe gesture starting from a header element.

    :param driver: Appium driver instance
    :param properties_target: Either a locator tuple (strategy, value) or a WebElement
    :param swipe_distance: Pixels to drag up (positive int = drag up)
    :param duration: Duration of drag in ms
    """
    # Resolve element
    properties_elem = None
    try:
        # Locator tuple e.g. (AppiumBy.ACCESSIBILITY_ID, "Properties")
        if isinstance(properties_target, tuple) and len(properties_target) == 2:
            by, val = properties_target  # type: ignore[misc]
            properties_elem = driver.find_element(by, val)
        else:
            # Assume WebElement
            properties_elem = properties_target
    except Exception:
        properties_elem = None

    if properties_elem is None:
        return

    location = properties_elem.location
    size = properties_elem.size

    # Start point: horizontal center of the title, slightly below its center
    start_x = location['x'] + size['width'] // 2
    start_y = location['y'] + size['height'] // 2 + 20  # Adjust if needed

    # End point: move up by swipe_distance pixels
    end_x = start_x
    end_y = max(start_y - swipe_distance, 0)  # Prevent off-screen

    # Preferred: legacy TouchAction if available
    if TouchAction is not None:
        action = TouchAction(driver)
        action.press(x=start_x, y=start_y).wait(ms=duration).move_to(x=end_x, y=end_y).release().perform()
        return

    # Fallback: Selenium 4 W3C pointer actions
    try:
        from selenium.webdriver.common.actions.action_builder import ActionBuilder  # type: ignore
        from selenium.webdriver.common.actions.pointer_input import PointerInput  # type: ignore

        actions = ActionBuilder(driver)
        actions.add_pointer_input(PointerInput(PointerInput.TOUCH, "finger"))

        actions.pointer_action.move_to_location(start_x, start_y)
        actions.pointer_action.pointer_down()
        # Pause to simulate press duration if provided
        if duration:
            actions.pointer_action.pause(duration / 1000.0)
        actions.pointer_action.move_to_location(end_x, end_y)
        actions.pointer_action.release()
        actions.perform()
    except Exception:
        # Final fallback: Appium mobile gesture (supported by Appium 2 drivers)
        try:
            driver.execute_script(
                "mobile: dragGesture",
                {
                    "startX": start_x,
                    "startY": start_y,
                    "endX": end_x,
                    "endY": end_y,
                    "duration": duration
                },
            )
        except Exception:
            # Last resort (deprecated in recent Appium): driver.swipe if present
            if hasattr(driver, "swipe"):
                driver.swipe(start_x, start_y, end_x, end_y, duration)


def click_long_press_and_drag_up(driver, locator, drag_distance=300, hold_time=500):
    """
    Clicks, then long-presses and drags the element up by drag_distance pixels using W3C Actions API.

    :param driver: Appium WebDriver instance
    :param locator: Locator tuple, e.g., (AppiumBy.ACCESSIBILITY_ID, "SomeElement")
    :param drag_distance: Distance in pixels to drag up
    :param hold_time: Hold (long-press) time in ms before dragging
    """
    import time

    # Find element
    element = driver.find(locator)
    loc = element.location
    size = element.size

    # Start in the middle of the element
    start_x = loc["x"] + size["width"] // 2
    start_y = loc["y"] + size["height"] // 2
    end_y = max(start_y - drag_distance, 0)

    # Click on the element
    element.click()
    time.sleep(0.2)  # Wait for click effect if needed

    # Perform long-press and drag
    actions = [{
        "type": "pointer",
        "id": "finger1",
        "parameters": {"pointerType": "touch"},
        "actions": [
            {"type": "pointerMove", "duration": 0, "x": start_x, "y": start_y},
            {"type": "pointerDown", "button": 0},
            {"type": "pause", "duration": hold_time},
            {"type": "pointerMove", "duration": 500, "x": start_x, "y": end_y},
            {"type": "pointerUp", "button": 0}
        ]
    }]
    driver.perform(actions)

def swipe_element_up(driver, element, drag_distance=300, hold_seconds=2):
    # """
    # Swipes up starting from the center of a given element, works for both Android and iOS.
    #
    # :param driver: Appium WebDriver instance
    # :param element: WebElement to start the swipe from
    # :param drag_distance: Distance in pixels to drag upwards
    # :param hold_seconds: Seconds to hold at the start before dragging
    # """
    # location = element.location
    # size = element.size
    #
    # # Center of the element
    # start_x = int(location['x'] + size['width'] / 2)
    # start_y = int(location['y'] + size['height'] / 2)
    # end_x = start_x
    # end_y = max(start_y - drag_distance, 1)  # ensure stays in screen bounds
    #
    # # Define actions
    # finger = PointerInput(PointerInput.TOUCH, "finger")
    # actions = ActionBuilder(driver)
    # actions.add_action(finger)
    #
    # actions.pointer_action.move_to_location(start_x, start_y)
    # actions.pointer_action.pointer_down()
    # actions.pointer_action.pause(hold_seconds)
    # actions.pointer_action.move_to_location(end_x, end_y)
    # actions.pointer_action.pointer_up()
    # actions.perform()
    # time.sleep(0.5)  # small sleep to stabilize UI
    from selenium.webdriver.common.actions.action_builder import ActionBuilder

    print(f"driver type: {type(driver)}")  # Should be Appium/Selenium WebDriver
    print(f"element type: {type(element)}")  # Should be WebElement

    location = element.location
    size = element.size

    start_x = int(location['x'] + size['width'] / 2)
    start_y = int(location['y'] + size['height'] / 2)
    end_x = start_x
    end_y = max(start_y - drag_distance, 1)

    # No need to add_action, just define pointer_action
    actions = ActionBuilder(driver)
    actions.pointer_action.move_to_location(start_x, start_y)
    actions.pointer_action.pointer_down()
    actions.pointer_action.pause(hold_seconds)
    actions.pointer_action.move_to_location(end_x, end_y)
    actions.pointer_action.pointer_up()
    actions.perform()

__all__ = ["is_truthy", "get_bundle_id","random_5_digit_number","get_current_timestamp","drag_form_up",
           "click_long_press_and_drag_up","swipe_element_up"]