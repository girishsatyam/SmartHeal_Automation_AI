import os
import json
import subprocess
import re


class AppLifecycleManager:
    def __init__(self, apk_path, package_name):
        self.apk_path = apk_path
        self.package_name = package_name

    def force_fresh_install_android(self):
        print(f"\n[LIFECYCLE] FRESH INSTALL (Android): {self.package_name}")
        try:
            subprocess.run(["adb", "uninstall", self.package_name], check=False, stdout=subprocess.DEVNULL)
        except Exception:
            pass
        try:
            print(f"   - Installing APK: {self.apk_path}")
            subprocess.run(["adb", "install", "-r", "-g", self.apk_path], check=True, stdout=subprocess.DEVNULL)
            print("   Install Complete.")
        except Exception as e:
            print(f"   Install Failed: {e}")
            raise e
        subprocess.run(["adb", "shell", "pm", "clear", self.package_name], check=False, stdout=subprocess.DEVNULL)


class IOSLifecycleManager:
    def __init__(self, device_name):
        self.device_name = device_name

    def _devices_json(self):
        try:
            out = subprocess.run(["xcrun", "simctl", "list", "devices", "--json"], capture_output=True, text=True, check=True)
            return json.loads(out.stdout).get("devices", {})
        except Exception:
            return {}

    def _parse_runtime_version(self, runtime_key):
        try:
            # Handles identifiers like:
            # - "iOS 18.2"
            # - "com.apple.CoreSimulator.SimRuntime.iOS-18-2"
            m = re.search(r"iOS[ -]?(\d+)(?:[.-](\d+))?", runtime_key)
            if m:
                major = m.group(1)
                minor = m.group(2) or "0"
                return f"{major}.{minor}"
        except Exception:
            pass
        return None

    def _prepare_sim_env(self, udid):
        try:
            xcode_dir = subprocess.run(["xcode-select", "-p"], capture_output=True, text=True, check=False).stdout.strip()
            platform_dev = os.path.join(xcode_dir, "Platforms", "iPhoneSimulator.platform", "Developer") if xcode_dir else None
            if platform_dev and os.path.isdir(platform_dev):
                subprocess.run(
                    ["xcrun", "simctl", "spawn", udid, "launchctl", "setenv", "IPHONE_SIMULATOR_ROOT", platform_dev],
                    check=False,
                    stdout=subprocess.DEVNULL,
                    stderr=subprocess.DEVNULL,
                )
            sim_sdk = subprocess.run(["xcrun", "--sdk", "iphonesimulator", "--show-sdk-path"], capture_output=True, text=True, check=False).stdout.strip()
            if sim_sdk:
                subprocess.run(
                    ["xcrun", "simctl", "spawn", udid, "launchctl", "setenv", "SDKROOT", sim_sdk],
                    check=False,
                    stdout=subprocess.DEVNULL,
                    stderr=subprocess.DEVNULL,
                )
        except Exception:
            pass

    def find_or_boot(self):
        devices = self._devices_json()
        chosen = None
        runtime_version = None

        # Prefer already booted device with matching name
        for runtime, devs in devices.items():
            for d in devs:
                if d.get("name") == self.device_name and d.get("isAvailable") and d.get("state") == "Booted":
                    chosen = d
                    runtime_version = self._parse_runtime_version(runtime)
                    break
            if chosen:
                break

        # Otherwise pick any available matching device and boot it
        if not chosen:
            for runtime, devs in devices.items():
                for d in devs:
                    if d.get("name") == self.device_name and d.get("isAvailable"):
                        chosen = d
                        runtime_version = self._parse_runtime_version(runtime)
                        break
                if chosen:
                    break
            if chosen:
                udid = chosen["udid"]
                try:
                    # Open Simulator UI bound to this UDID and boot/wait until ready
                    subprocess.run(["open", "-a", "Simulator", "--args", "-CurrentDeviceUDID", udid], check=False)
                    subprocess.run(["xcrun", "simctl", "boot", udid], check=False)
                    subprocess.run(["xcrun", "simctl", "bootstatus", udid, "-b"], check=False)
                except Exception:
                    pass

        if chosen:
            try:
                self._prepare_sim_env(chosen["udid"])
            except Exception:
                pass
            return chosen["udid"], runtime_version
        return None, None


__all__ = ["AppLifecycleManager", "IOSLifecycleManager"]