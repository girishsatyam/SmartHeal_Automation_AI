import time
from typing import Callable, Any, Tuple, Optional
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC


def wait_until(driver, condition: Callable[[Any], Any], timeout: float = 10.0, interval: float = 0.5) -> Any:
    """
    Polls condition(driver) until it returns a truthy value or timeout is reached.
    Returns the condition's truthy value on success, or None on timeout.
    """
    end = time.time() + timeout
    last_exc = None
    while time.time() < end:
        try:
            result = condition(driver)
            if result:
                return result
        except Exception as e:
            last_exc = e
        time.sleep(interval)
    return None


def wait_for_presence(driver, locator: Tuple[str, str], timeout: float = 10.0):
    """
    Wait until an element is present in the DOM (may not be visible).
    locator is a (By/ AppiumBy, value) tuple.
    """
    return WebDriverWait(driver, timeout).until(EC.presence_of_element_located(locator))


def wait_for_visible(driver, locator: Tuple[str, str], timeout: float = 10.0):
    """
    Wait until an element is visible.
    locator is a (By/ AppiumBy, value) tuple.
    """
    return WebDriverWait(driver, timeout).until(EC.visibility_of_element_located(locator))


def wait_for_enabled(element, timeout: float = 5.0, interval: float = 0.25) -> bool:
    """
    Poll element.is_enabled() until True or timeout.
    """
    end = time.time() + timeout
    while time.time() < end:
        try:
            if element.is_enabled():
                return True
        except Exception:
            pass
        time.sleep(interval)
    return False


def wait_for_ui_stability(driver, duration: float = 3.0, window: float = 1.0, interval: float = 0.5) -> bool:
    """
    Heuristic passive wait that returns True if the UI (page_source) is stable for `window` seconds
    within the overall `duration` budget. Helps avoid hardcoded sleeps after navigation/transitions.
    """
    start = time.time()
    stable_since: Optional[float] = None
    last_src: Optional[str] = None

    while time.time() - start < duration:
        cur = ""
        try:
            cur = driver.page_source or ""
        except Exception:
            # If page_source unfetchable, just delay and keep checking
            time.sleep(interval)
            continue

        if cur == last_src:
            if stable_since is None:
                stable_since = time.time()
            elif time.time() - stable_since >= window:
                return True
        else:
            stable_since = None
            last_src = cur

        time.sleep(interval)
    # Timed out without a full stable window
    return False


def sleep_with_reason(seconds: float, reason: str = ""):
    """
    Centralized sleep with optional reason logging. Prefer wait_for_ui_stability where possible.
    """
    if reason:
        try:
            print(f"[SLEEP] {seconds:.1f}s - {reason}")
        except Exception:
            pass
    time.sleep(seconds)


def safe_click(element, fallback_tap: Optional[Callable[[Any], None]] = None, post_delay: float = 0.0):
    """
    Attempts a normal click, falls back to provided center-tap callable if needed.
    Optionally waits post_delay seconds after a successful click to allow transitions.
    """
    try:
        element.click()
    except Exception:
        if fallback_tap:
            try:
                fallback_tap(element)
            except Exception:
                pass
        else:
            raise
    if post_delay > 0:
        time.sleep(post_delay)


__all__ = [
    "wait_until",
    "wait_for_presence",
    "wait_for_visible",
    "wait_for_enabled",
    "wait_for_ui_stability",
    "sleep_with_reason",
    "safe_click",
]