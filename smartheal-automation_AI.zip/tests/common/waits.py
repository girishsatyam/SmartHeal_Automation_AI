import time
from dataclasses import dataclass
from typing import Callable, Any, Tuple, Optional, Literal
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC

# Optional Appium import: this module is used by both web and mobile tests.
# Importing AppiumBy only when available avoids breaking pure-web environments.
try:
    from appium.webdriver.common.appiumby import AppiumBy  # type: ignore
except Exception:  # pragma: no cover
    AppiumBy = None  # type: ignore


WaitMode = Literal[
    "until",            # generic condition
    "presence",         # element present in DOM
    "visible",          # element visible
    "clickable",        # element clickable
    "invisible",        # element invisible
    "ui_stable",        # page_source stable window
    "sleep",            # explicit sleep (centralized)
]


@dataclass(frozen=True)
class SmartWaitConfig:
    timeout: float = 10.0
    interval: float = 0.5
    post_delay: float = 0.0
    reason: str = ""
    # for ui_stable
    stability_duration: float = 3.0
    stability_window: float = 1.0


def wait_until(driver, condition: Callable[[Any], Any], timeout: float = 10.0, interval: float = 0.5) -> Any:
    """
    Polls condition(driver) until it returns a truthy value or timeout is reached.
    Returns the condition's truthy value on success, or None on timeout.
    """
    end = time.time() + timeout
    last_exc = None
    while time.time() < end:
        try:
            result = condition(driver)
            if result:
                return result
        except Exception as e:
            last_exc = e
        time.sleep(interval)
    return None


def smart_wait(
    driver,
    *,
    mode: WaitMode = "until",
    condition: Optional[Callable[[Any], Any]] = None,
    locator: Optional[Tuple[Any, str]] = None,
    element: Any = None,
    timeout: float = 10.0,
    interval: float = 0.5,
    post_delay: float = 0.0,
    reason: str = "",
    stability_duration: float = 3.0,
    stability_window: float = 1.0,
) -> Any:
    """Generic *Smart Wait* entry point.

    This is the single API that test cases/framework code should call instead of:
      - time.sleep / sleep
      - WebDriverWait(...).until(...)

    It supports both Selenium (web) and Appium (mobile) drivers.

    Parameters
    ----------
    mode:
        One of: until/presence/visible/clickable/invisible/ui_stable/sleep
    condition:
        Used when mode='until'. A callable(driver) -> truthy value.
    locator:
        Used when mode in presence/visible/clickable/invisible.
        Must be a 2-tuple (By/AppiumBy, locator_value)
    element:
        Used when mode='invisible' and you want invisibility_of_element(element).
    """
    cfg = SmartWaitConfig(
        timeout=float(timeout),
        interval=float(interval),
        post_delay=float(post_delay),
        reason=str(reason or ""),
        stability_duration=float(stability_duration),
        stability_window=float(stability_window),
    )

    if mode == "sleep":
        sleep_with_reason(cfg.timeout, cfg.reason)
        if cfg.post_delay > 0:
            sleep_with_reason(cfg.post_delay, "post-delay")
        return True

    if mode == "ui_stable":
        ok = wait_for_ui_stability(
            driver,
            duration=cfg.stability_duration,
            window=cfg.stability_window,
            interval=cfg.interval,
        )
        if cfg.post_delay > 0:
            sleep_with_reason(cfg.post_delay, "post ui-stable delay")
        return ok

    if mode == "until":
        if not callable(condition):
            raise ValueError("smart_wait(mode='until') requires a callable 'condition'")
        res = wait_until(driver, condition, timeout=cfg.timeout, interval=cfg.interval)
        if cfg.post_delay > 0:
            sleep_with_reason(cfg.post_delay, "post condition delay")
        return res

    # locator-based modes
    if locator is None and mode in ("presence", "visible", "clickable", "invisible"):
        # allow invisible to use element instead of locator
        if not (mode == "invisible" and element is not None):
            raise ValueError(f"smart_wait(mode='{mode}') requires 'locator' (or 'element' for invisible)")

    if mode == "presence":
        res = WebDriverWait(driver, cfg.timeout, poll_frequency=cfg.interval).until(
            EC.presence_of_element_located(locator)  # type: ignore[arg-type]
        )
    elif mode == "visible":
        res = WebDriverWait(driver, cfg.timeout, poll_frequency=cfg.interval).until(
            EC.visibility_of_element_located(locator)  # type: ignore[arg-type]
        )
    elif mode == "clickable":
        res = WebDriverWait(driver, cfg.timeout, poll_frequency=cfg.interval).until(
            EC.element_to_be_clickable(locator)  # type: ignore[arg-type]
        )
    elif mode == "invisible":
        cond = EC.invisibility_of_element(element) if element is not None else EC.invisibility_of_element_located(locator)  # type: ignore[arg-type]
        res = WebDriverWait(driver, cfg.timeout, poll_frequency=cfg.interval).until(cond)
    else:
        raise ValueError(f"Unsupported smart_wait mode: {mode}")

    if cfg.post_delay > 0:
        sleep_with_reason(cfg.post_delay, "post wait delay")
    return res


def wait_for_presence(driver, locator: Tuple[str, str], timeout: float = 10.0):
    """
    Wait until an element is present in the DOM (may not be visible).
    locator is a (By/ AppiumBy, value) tuple.
    """
    # Backward-compatible wrapper
    return smart_wait(driver, mode="presence", locator=locator, timeout=timeout)


def wait_for_visible(driver, locator: Tuple[str, str], timeout: float = 10.0):
    """
    Wait until an element is visible.
    locator is a (By/ AppiumBy, value) tuple.
    """
    # Backward-compatible wrapper
    return smart_wait(driver, mode="visible", locator=locator, timeout=timeout)


def wait_for_enabled(element, timeout: float = 5.0, interval: float = 0.25) -> bool:
    """
    Poll element.is_enabled() until True or timeout.
    """
    end = time.time() + timeout
    while time.time() < end:
        try:
            if element.is_enabled():
                return True
        except Exception:
            pass
        time.sleep(interval)
    return False


def wait_for_ui_stability(driver, duration: float = 3.0, window: float = 1.0, interval: float = 0.5) -> bool:
    """
    Heuristic passive wait that returns True if the UI (page_source) is stable for `window` seconds
    within the overall `duration` budget. Helps avoid hardcoded sleeps after navigation/transitions.
    """
    start = time.time()
    stable_since: Optional[float] = None
    last_src: Optional[str] = None

    while time.time() - start < duration:
        cur = ""
        try:
            cur = driver.page_source or ""
        except Exception:
            # If page_source unfetchable, just delay and keep checking
            time.sleep(interval)
            continue

        if cur == last_src:
            if stable_since is None:
                stable_since = time.time()
            elif time.time() - stable_since >= window:
                return True
        else:
            stable_since = None
            last_src = cur

        time.sleep(interval)
    # Timed out without a full stable window
    return False


def sleep_with_reason(seconds: float, reason: str = ""):
    """
    Centralized sleep with optional reason logging. Prefer wait_for_ui_stability where possible.
    """
    if reason:
        try:
            print(f"[SLEEP] {seconds:.1f}s - {reason}")
        except Exception:
            pass
    time.sleep(seconds)


def safe_click(element, fallback_tap: Optional[Callable[[Any], None]] = None, post_delay: float = 0.0):
    """
    Attempts a normal click, falls back to provided center-tap callable if needed.
    Optionally waits post_delay seconds after a successful click to allow transitions.
    """
    try:
        element.click()
    except Exception:
        if fallback_tap:
            try:
                fallback_tap(element)
            except Exception:
                pass
        else:
            raise
    if post_delay > 0:
        time.sleep(post_delay)


def wait_and_select_project(driver, platform: str, project_name: str, timeout: float = 60.0):
    print(f"⏳ [SLOWNESS CHECK] Waiting up to {int(timeout)}s for Project Selection screen ('{project_name}')...")

    if platform == 'android':
        if AppiumBy is None:
            raise RuntimeError("AppiumBy is required for android project selection wait")
        locator = (AppiumBy.XPATH, f"//*[contains(@text, '{project_name}')]" )
    else:
        if AppiumBy is None:
            raise RuntimeError("AppiumBy is required for ios project selection wait")
        locator = (AppiumBy.ACCESSIBILITY_ID, project_name)

    smart_wait(driver, mode="presence", locator=locator, timeout=timeout, interval=0.5)
    print("   -> Project found! Clicking now...")
    driver.find_element(*locator).click()
    print(f"✅ Clicked on Project: {project_name}")


__all__ = [
    "SmartWaitConfig",
    "smart_wait",
    "wait_until",
    "wait_for_presence",
    "wait_for_visible",
    "wait_for_enabled",
    "wait_for_ui_stability",
    "sleep_with_reason",
    "safe_click",
    "wait_and_select_project",
]