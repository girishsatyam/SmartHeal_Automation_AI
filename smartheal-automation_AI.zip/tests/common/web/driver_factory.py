import os
import json
import shutil
from selenium import webdriver
from selenium.webdriver.chrome.service import Service as ChromeService
from selenium.webdriver.chrome.options import Options as ChromeOptions
from webdriver_manager.chrome import ChromeDriverManager


def _default_web_config_path():
    # tests/common/web/driver_factory.py -> project root -> config/web_config.json
    return os.path.abspath(
        os.path.join(os.path.dirname(__file__), "..", "..", "..", "config", "web_config.json")
    )


def create_web_driver(config_path: str | None = None):
    """
    Create and return a Selenium WebDriver for Chrome based on config/web_config.json.
    - Reads: browserName, headless, baseUrl
    - Installs the appropriate chromedriver via webdriver-manager
    - Navigates to baseUrl if provided
    """
    cfg_path = config_path or _default_web_config_path()
    if not os.path.exists(cfg_path):
        raise FileNotFoundError(f"Missing web config at: {cfg_path}")

    with open(cfg_path, "r") as f:
        cfg = json.load(f)

    browser = str(cfg.get("browserName", "chrome")).lower()
    headless = bool(cfg.get("headless", False))
    base_url = cfg.get("baseUrl")

    if browser != "chrome":
        raise ValueError(f"Only 'chrome' is supported currently. Got: {browser}")

    options = ChromeOptions()
    # Headless or normal mode
    if headless:
        # Prefer new headless for modern Chrome
        options.add_argument("--headless=new")
        options.add_argument("--disable-gpu")
    # Sensible defaults
    options.add_argument("--no-sandbox")
    options.add_argument("--disable-dev-shm-usage")
    options.add_argument("--window-size=1400,900")
    options.add_argument("--remote-allow-origins=*")
    # Reduce flakiness
    options.add_experimental_option("excludeSwitches", ["enable-automation"])
    options.add_experimental_option("useAutomationExtension", False)

    # Prefer a locally available chromedriver to avoid network dependency
    driver = None
    driver_bin = None

    # 1) Explicit env-provided paths
    for var in ("CHROMEDRIVER", "CHROMEDRIVER_PATH"):
        p = os.environ.get(var)
        if p:
            cand = os.path.join(p, "chromedriver") if os.path.isdir(p) else p
            if os.path.exists(cand):
                driver_bin = cand
                break

    # 2) Standard CHROMEWEBDRIVER directory (e.g., set by installers)
    if not driver_bin:
        drv_dir = os.environ.get("CHROMEWEBDRIVER")
        if drv_dir:
            cand = os.path.join(drv_dir, "chromedriver")
            if os.path.exists(cand):
                driver_bin = cand

    # 3) PATH
    if not driver_bin:
        which = shutil.which("chromedriver")
        if which:
            driver_bin = which

    # 4) Well-known install locations (Homebrew/Intel)
    if not driver_bin:
        for p in ("/opt/homebrew/bin/chromedriver", "/usr/local/bin/chromedriver"):
            if os.path.exists(p) and os.access(p, os.X_OK):
                driver_bin = p
                break

    # 5) Repository-provided drivers folder (scan recursively)
    if not driver_bin:
        try:
            root = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", "..", ".."))
            drivers_dir = os.path.join(root, "drivers")
            if os.path.isdir(drivers_dir):
                for dirpath, dirnames, filenames in os.walk(drivers_dir):
                    for name in ("chromedriver", "chromedriver.exe"):
                        cand = os.path.join(dirpath, name)
                        if os.path.exists(cand) and os.access(cand, os.X_OK):
                            driver_bin = cand
                            raise StopIteration  # break nested loops
        except StopIteration:
            pass
        except Exception:
            pass

    # Attempt creation in order: explicit driver_bin -> Selenium Manager -> webdriver-manager
    last_err = None
    for name in ("ExplicitDriverBin", "SeleniumManager", "WebDriverManager"):
        try:
            if name == "ExplicitDriverBin" and driver_bin:
                service = ChromeService(executable_path=driver_bin)
                driver = webdriver.Chrome(service=service, options=options)
                break
            elif name == "SeleniumManager":
                service = ChromeService()
                driver = webdriver.Chrome(service=service, options=options)
                break
            elif name == "WebDriverManager":
                service = ChromeService(ChromeDriverManager().install())
                driver = webdriver.Chrome(service=service, options=options)
                break
        except Exception as e:
            last_err = e
            driver = None
            continue

    if not driver:
        raise RuntimeError(f"Failed to create Chrome driver (tried ExplicitDriverBin/SeleniumManager/WebDriverManager). Last cause: {last_err}")

    # Reasonable defaults; we use explicit waits primarily
    try:
        driver.implicitly_wait(0)
    except Exception:
        pass
    try:
        driver.set_page_load_timeout(120)
    except Exception:
        pass

    # Navigate to baseUrl if present
    if base_url:
        try:
            driver.get(base_url)
        except Exception:
            # Allow test/page to self-correct if navigation fails initially
            pass

    return driver