"""
Reusable web helpers for Selenium-based flows.
Keep all generic browser/DOM logic here to avoid duplicating it in page objects.

Notes:
- Safe to import from any web Page Object (no mobile code touched).
- Designed to be resilient to iframes/shadow DOM, transient overlays, and flakiness.
"""

from __future__ import annotations

import os
import json
import time
from typing import Optional, Sequence, Tuple

from selenium.webdriver.common.by import By
from selenium.webdriver import ActionChains

try:
    import allure  # type: ignore
except Exception:  # pragma: no cover
    allure = None  # type: ignore

from urllib.parse import urlparse

from tests.common.waits import sleep_with_reason, wait_until, smart_wait


def wait_for_url_contains(driver, substring: str, timeout: float = 30.0, interval: float = 0.5) -> bool:
    """Wait until current_url contains substring (case-insensitive)."""
    sub = (substring or "").strip().lower()
    if not sub:
        return True

    def _cond(_):
        try:
            return sub in (driver.current_url or "").lower()
        except Exception:
            return False

    return bool(wait_until(driver, _cond, timeout=timeout, interval=interval))


def wait_for_text_present(driver, text: str, timeout: float = 30.0, interval: float = 0.5) -> bool:
    """Wait until page contains given text (case-insensitive), searching across frames."""
    t = (text or "").strip().lower()
    if not t:
        return True

    def _has_text(_):
        try:
            el = find_with_frames(
                driver,
                By.XPATH,
                "//*[contains(translate(normalize-space(.),'ABCDEFGHIJKLMNOPQRSTUVWXYZ','abcdefghijklmnopqrstuvwxyz'), '{}')]".format(t),
                timeout=1,
                clickable=False,
            )
            if el:
                return True
        except Exception:
            pass
        try:
            return t in (driver.page_source or "").lower()
        except Exception:
            return False

    return bool(wait_until(driver, _has_text, timeout=timeout, interval=interval))


def load_web_config(config_path: Optional[str] = None) -> dict:
    """
    Load config/web_config.json (or an explicit path), returns dict with keys:
      - browserName
      - baseUrl
      - headless
    """
    if config_path and os.path.exists(config_path):
        path = config_path
    else:
        path = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", "..", "..", "config", "web_config.json"))
    with open(path, "r") as f:
        return json.load(f)


def attach_state(driver, note: str = "state"):
    """
    Attach screenshot and page HTML to Allure for diagnostics (best-effort).
    """
    if not allure:
        return
    try:
        png = driver.get_screenshot_as_png()
        allure.attach(png, name=f"Web State - {note}", attachment_type=allure.attachment_type.PNG)
    except Exception:
        pass
    try:
        src = driver.page_source or ""
        allure.attach(src, name=f"HTML - {note}", attachment_type=allure.attachment_type.HTML)
    except Exception:
        pass


def settle_ready_state(driver, fast_env_var: str = "FAST_WEB"):
    """
    Small settle and fast-ready check to avoid blocking on third-party scripts.
    """
    try:
        fast = str(os.environ.get(fast_env_var, "")).lower() in ("1", "true", "yes")
        settle_secs = 3 if fast else 6
        end = time.time() + settle_secs
        while time.time() < end:
            try:
                state = driver.execute_script("return document.readyState")
                if state in ("interactive", "complete"):
                    break
            except Exception:
                pass
            smart_wait(driver, mode="sleep", timeout=0.3, reason="poll document.readyState")
    except Exception:
        pass


def switch_to_last_window(driver):
    """
    If a new browser window/tab was opened, switch to the last (foreground) one.
    """
    try:
        handles = driver.window_handles
        if len(handles) > 1:
            driver.switch_to.window(handles[-1])
    except Exception:
        pass


def navigate_to_base_if_mismatch(driver, base_url: Optional[str]):
    """
    Ensure browser starts at the expected baseUrl if nothing is loaded yet.
    Do NOT force navigation away from IdP hosts (e.g., Oracle IDCS) after redirects.
    """
    if not base_url:
        return
    try:
        cur_url = driver.current_url or ""
    except Exception:
        cur_url = ""
    try:
        parsed = urlparse(cur_url) if cur_url else None
        cur_scheme = parsed.scheme if parsed else ""
        # Only navigate if we have no URL loaded or it's not http(s)
        if (not cur_url) or (cur_scheme not in ("http", "https")):
            driver.get(base_url)
    except Exception:
        pass


def find_with_frames(driver, locator_by: By, locator_val: str, timeout: float = 12.0, clickable: bool = False, max_depth: int = 8):
    """
    Search default content and recursively traverse nested iframes/frames (up to max_depth).
    Returns the element or None if not found within timeout.
    """
    end_by = time.time() + max(timeout, 12.0)

    def _find_in_current(ctx_timeout):
        mode = "clickable" if clickable else "presence"
        return smart_wait(driver, mode=mode, locator=(locator_by, locator_val), timeout=ctx_timeout, interval=0.25)

    def _recurse(depth, ctx_timeout):
        if time.time() > end_by:
            return None
        try:
            el = _find_in_current(ctx_timeout)
            if el:
                return el
        except Exception:
            pass
        if depth >= max_depth:
            return None
        try:
            frames = driver.find_elements(By.CSS_SELECTOR, "iframe, frame")
        except Exception:
            frames = []
        for fr in frames[:12]:
            try:
                driver.switch_to.frame(fr)
                el = _recurse(depth + 1, max(4, ctx_timeout // 2))
                if el:
                    return el
            except Exception:
                pass
            finally:
                try:
                    driver.switch_to.parent_frame()
                except Exception:
                    try:
                        driver.switch_to.default_content()
                    except Exception:
                        pass
        return None

    try:
        driver.switch_to.default_content()
    except Exception:
        pass
    el = _recurse(0, timeout)
    try:
        driver.switch_to.default_content()
    except Exception:
        pass
    return el


def deep_find_input(driver, kind: str, timeout: float = 12.0):
    """
    JS-based deep search that traverses shadow DOM and same-origin iframes to locate
    'user' or 'pass' inputs quickly.
    """
    def _js_for(kind_name):
        if kind_name == "user":
            return r"""
return (function(){
  function matches(el){
    const t=(s)=> (s||"").toLowerCase();
    const id=t(el.id), name=t(el.name), ph=t(el.getAttribute('placeholder')), aria=t(el.getAttribute('aria-label'));
    return id.includes('user')||name.includes('user')||id.includes('login')||name.includes('login')||ph.includes('login')||ph.includes('email')||aria.includes('login')||aria.includes('email');
  }
  function walk(root){
    const stack=[root];
    while(stack.length){
      const node=stack.pop();
      if (!node) continue;
      if (node.nodeType===1){
        try{
          if (node.matches && node.matches('input') && matches(node)) return node;
        }catch(e){}
        if (node.tagName==='IFRAME'){
          try{
            const doc = node.contentDocument || (node.contentWindow && node.contentWindow.document);
            if (doc){
              const found = walk(doc);
              if (found) return found;
            }
          }catch(e){}
        }
        let children=[];
        try { children = node.querySelectorAll ? node.querySelectorAll('*') : []; } catch(e){ children=[]; }
        for (const c of children){
          stack.push(c);
          try { if (c.shadowRoot) stack.push(c.shadowRoot); } catch(e){}
        }
      }
    }
    return null;
  }
  const start=Date.now();
  const limit=9000;
  let el=null;
  while(Date.now()-start < limit){
    try { el = walk(document); } catch(e){ el=null; }
    if (el) return el;
  }
  return null;
})();"""
        else:
            return r"""
return (function(){
  function matches(el){
    const t=(s)=> (s||"").toLowerCase();
    const id=t(el.id), name=t(el.name), ph=t(el.getAttribute('placeholder')), aria=t(el.getAttribute('aria-label')), type=t(el.getAttribute('type'));
    return type==='password'||id.includes('pass')||name.includes('pass')||ph.includes('pass')||aria.includes('pass')||id.includes('pwd')||name.includes('pwd');
  }
  function walk(root){
    const stack=[root];
    while(stack.length){
      const node=stack.pop();
      if (!node) continue;
      if (node.nodeType===1){
        try{
          if (node.matches && node.matches('input') && matches(node)) return node;
        }catch(e){}
        if (node.tagName==='IFRAME'){
          try{
            const doc = node.contentDocument || (node.contentWindow && node.contentWindow.document);
            if (doc){
              const found = walk(doc);
              if (found) return found;
            }
          }catch(e){}
        }
        let children=[];
        try { children = node.querySelectorAll ? node.querySelectorAll('*') : []; } catch(e){ children=[]; }
        for (const c of children){
          stack.push(c);
          try { if (c.shadowRoot) stack.push(c.shadowRoot); } catch(e){}
        }
      }
    }
    return null;
  }
  const start=Date.now();
  const limit=9000;
  let el=null;
  while(Date.now()-start < limit){
    try { el = walk(document); } catch(e){ el=null; }
    if (el) return el;
  }
  return null;
})();"""
    js = _js_for(kind)
    end = time.time() + timeout
    while time.time() < end:
        try:
            el = driver.execute_script(js)
            if el:
                return el
        except Exception:
            pass
        smart_wait(driver, mode="sleep", timeout=0.2, reason="poll deep_find_input")
    return None


def find_username_field(driver):
    """
    Locate a username/email field via deep search and heuristics across iframes.
    """
    el = deep_find_input(driver, "user", timeout=12)
    if el:
        return el
    el = find_with_frames(driver, By.ID, "userName|input", timeout=15)
    if el:
        return el
    for cand in ("userName", "username", "user_name", "login", "loginName", "email", "emailAddress"):
        el = find_with_frames(driver, By.ID, cand, timeout=10)
        if el:
            return el
    el = find_with_frames(driver, By.NAME, "userName", timeout=10)
    if el:
        return el
    el = find_with_frames(driver, By.NAME, "username", timeout=10)
    if el:
        return el
    # Oracle IDCS common ids
    for cand in ("idcs-signin-basic-signin-form-username", "idcs-username"):
        el = find_with_frames(driver, By.ID, cand, timeout=10)
        if el:
            return el
    el = find_with_frames(driver, By.XPATH, "//label[contains(normalize-space(),'Login Name') or contains(normalize-space(),'Work Email')]/following::input[1]", timeout=10)
    if el:
        return el
    heur = ("//input[(translate(@type,'EMAILTX','emailtx')='email' or translate(@type,'TEXT','text')='text') "
            "or @role='textbox' or contains(@aria-label,'Login') or contains(@aria-label,'Email') "
            "or contains(@id,'user') or contains(@name,'user') or contains(@id,'email') or contains(@name,'email')]")
    return find_with_frames(driver, By.XPATH, heur, timeout=15)


def find_password_field(driver):
    """
    Locate a password field via deep search and heuristics across iframes.
    """
    el = deep_find_input(driver, "pass", timeout=12)
    if el:
        return el
    # Common ids
    el = find_with_frames(driver, By.ID, "password", timeout=15)
    if el:
        return el
    for cand in ("passwd", "user_password", "pwd"):
        el = find_with_frames(driver, By.ID, cand, timeout=10)
        if el:
            return el
    # Oracle IDCS common ids
    for cand in ("idcs-signin-basic-signin-form-password", "idcs-password"):
        el = find_with_frames(driver, By.ID, cand, timeout=10)
        if el:
            return el
    el = find_with_frames(driver, By.NAME, "password", timeout=10)
    if el:
        return el
    xpath = "//input[@type='password' or contains(@id,'pass') or contains(@name,'pass')]"
    return find_with_frames(driver, By.XPATH, xpath, timeout=15)


def ensure_in_view(driver, el):
    try:
        driver.execute_script("arguments[0].scrollIntoView({block: 'center', inline: 'center'});", el)
        sleep_with_reason(0.1, "scrollIntoView settle")
    except Exception:
        pass


def _safe_attr(el, name: str) -> str:
    try:
        val = el.get_attribute(name)
        return val if val is not None else ""
    except Exception:
        return ""


def describe_element(el) -> str:
    try:
        return f"id={_safe_attr(el,'id')} name={_safe_attr(el,'name')} type={_safe_attr(el,'type')} placeholder={_safe_attr(el,'placeholder')} aria-label={_safe_attr(el,'aria-label')}"
    except Exception:
        return "id= name= type= placeholder= aria-label="


def click_element(driver, el) -> bool:
    """
    Try native click, JS click, then ActionChains click.
    """
    ensure_in_view(driver, el)
    try:
        el.click()
        return True
    except Exception:
        pass
    try:
        driver.execute_script("arguments[0].click();", el)
        return True
    except Exception:
        pass
    try:
        ActionChains(driver).move_to_element(el).pause(0.1).click().perform()
        return True
    except Exception:
        return False


def click_button_by_id(driver, btn_id: str, timeout: float = 8.0) -> bool:
    el = find_with_frames(driver, By.ID, btn_id, timeout=timeout, clickable=True)
    if not el:
        return False
    return click_element(driver, el)


def type_fast(driver, el, text: str):
    """
    Clear and type quickly with robust fallbacks (Safari-friendly + JS setter).
    """
    def _is_safari():
        try:
            caps = getattr(driver, "capabilities", {}) or {}
            bname = str(caps.get("browserName", "")).lower()
            return "safari" in bname
        except Exception:
            return False

    ensure_in_view(driver, el)
    try:
        el.click()
    except Exception:
        try:
            ActionChains(driver).move_to_element(el).pause(0.05).click().perform()
        except Exception:
            pass

    try:
        try:
            el.clear()
        except Exception:
            pass
        el.send_keys(text)
        return
    except Exception:
        pass

    if _is_safari():
        try:
            for ch in str(text):
                el.send_keys(ch)
                sleep_with_reason(0.01, "safari type pacing")
            return
        except Exception:
            pass
        try:
            actions = ActionChains(driver)
            actions.click(el).pause(0.05)
            for ch in str(text):
                actions.send_keys(ch).pause(0.005)
            actions.perform()
            return
        except Exception:
            pass

    try:
        driver.execute_script("""
            const el = arguments[0];
            const val = arguments[1];
            try { el.focus(); } catch(e) {}
            try { if (el.select) el.select(); } catch(e) {}
            try { el.value = ''; } catch(e) {}
            try {
              const desc = Object.getOwnPropertyDescriptor(el.__proto__, 'value');
              if (desc && desc.set) { desc.set.call(el, val); } else { el.value = val; }
            } catch(e) { try { el.value = val; } catch(_) {} }
            try { el.dispatchEvent(new Event('input', { bubbles: true })); } catch(e) {}
            try { el.dispatchEvent(new Event('change', { bubbles: true })); } catch(e) {}
        """, el, text)
    except Exception:
        pass


def dismiss_cookie_banners(driver):
    """
    Try to dismiss common cookie/consent banners.
    """
    selectors = [
        (By.ID, "onetrust-accept-btn-handler"),
        (By.ID, "acceptAll"),
        (By.XPATH, "//*[self::button and contains(translate(., 'ACEIPT', 'aceipt'), 'accept')]"),
        (By.XPATH, "//*[self::button and contains(translate(., 'AGREEOK', 'agreeok'), 'agree')]"),
    ]
    for by, val in selectors:
        try:
            el = smart_wait(driver, mode="clickable", locator=(by, val), timeout=5, interval=0.25)
            click_element(driver, el)
            sleep_with_reason(0.2, "cookie banner dismissed")
        except Exception:
            continue


def click_auth_options(driver, texts: Sequence[str]) -> bool:
    """
    Click tiles/links that reveal classic username/password if present.
    Returns True if any click succeeded.
    """
    lowered = [t.lower() for t in texts]
    xpats = [
        "//*[self::a or self::button][contains(translate(normalize-space(.),'ABCDEFGHIJKLMNOPQRSTUVWXYZ','abcdefghijklmnopqrstuvwxyz'), '{t}')]",
        "//*[@role='button'][contains(translate(normalize-space(.),'ABCDEFGHIJKLMNOPQRSTUVWXYZ','abcdefghijklmnopqrstuvwxyz'), '{t}')]",
        "//div[contains(translate(normalize-space(.),'ABCDEFGHIJKLMNOPQRSTUVWXYZ','abcdefghijklmnopqrstuvwxyz'), '{t}')]"
    ]
    for t in lowered:
        for xp in xpats:
            try:
                el = find_with_frames(driver, By.XPATH, xp.format(t=t), timeout=3, clickable=True)
                if el and click_element(driver, el):
                    sleep_with_reason(0.5, "auth option clicked")
                    return True
            except Exception:
                continue

    # Fallbacks: very broad text-based selectors that often appear on IDCS/AuthHub pages
    broad_xpaths = [
        "//*[contains(translate(normalize-space(.),'ABCDEFGHIJKLMNOPQRSTUVWXYZ','abcdefghijklmnopqrstuvwxyz'),'aconex') and contains(translate(normalize-space(.),'ABCDEFGHIJKLMNOPQRSTUVWXYZ','abcdefghijklmnopqrstuvwxyz'),'password')]",
        "//*[contains(translate(normalize-space(.),'ABCDEFGHIJKLMNOPQRSTUVWXYZ','abcdefghijklmnopqrstuvwxyz'),'use password')]",
        "//*[contains(translate(normalize-space(.),'ABCDEFGHIJKLMNOPQRSTUVWXYZ','abcdefghijklmnopqrstuvwxyz'),'sign in with password')]",
        "//*[contains(translate(normalize-space(.),'ABCDEFGHIJKLMNOPQRSTUVWXYZ','abcdefghijklmnopqrstuvwxyz'),'other sign-in options')]",
        "//*[contains(translate(normalize-space(.),'ABCDEFGHIJKLMNOPQRSTUVWXYZ','abcdefghijklmnopqrstuvwxyz'),'other sign in options')]",
        "//*[contains(translate(normalize-space(.),'ABCDEFGHIJKLMNOPQRSTUVWXYZ','abcdefghijklmnopqrstuvwxyz'),'aconex')]",
    ]
    for xp in broad_xpaths:
        try:
            el = find_with_frames(driver, By.XPATH, xp, timeout=3, clickable=True)
            if el and click_element(driver, el):
                sleep_with_reason(0.5, "auth option fallback clicked")
                return True
        except Exception:
            continue
    return False


def click_any_text_contains(driver, strings: Sequence[str], timeout_per: float = 2.5) -> bool:
    """
    Click any element that contains one of the provided strings (case-insensitive).
    Useful for labels/tiles like 'Login Name', 'Work Email', 'Aconex username', etc.
    """
    for s in strings:
        try:
            xp = "//*[contains(translate(normalize-space(.),'ABCDEFGHIJKLMNOPQRSTUVWXYZ','abcdefghijklmnopqrstuvwxyz'), '{t}')]".format(
                t=str(s).lower()
            )
            el = find_with_frames(driver, By.XPATH, xp, timeout=timeout_per, clickable=True)
            if el and click_element(driver, el):
                sleep_with_reason(0.3, f"clicked text-containing element: {s}")
                return True
        except Exception:
            continue
    return False


def recover_from_gateway_error(driver, base_url: Optional[str], retries: int = 3):
    """
    Detect bad gateway pages and reload baseUrl a few times to recover.
    """
    def _body_text():
        try:
            return (driver.find_element(By.TAG_NAME, "body").text or "").strip()
        except Exception:
            try:
                return driver.execute_script("return document.body && document.body.innerText || ''") or ""
            except Exception:
                return ""

    def _is_gateway_error():
        try:
            title = (driver.title or "").strip().lower()
        except Exception:
            title = ""
        body = (_body_text() or "").lower()
        return ("bad gateway" in title) or ("502 bad gateway" in title) or ("bad gateway" in body)

    if not base_url:
        return
    for attempt in range(retries):
        if not _is_gateway_error():
            break
        try:
            driver.get(base_url)
        except Exception:
            pass
        sleep_with_reason(2.0, "post baseUrl reload settle")


def wait_post_login_settle(driver, duration: float = 1.0):
    """
    Small passive wait after login submits.
    """
    sleep_with_reason(duration, "post login submit settle")


def click_skip_this_time(driver, timeout: float = 6.0) -> bool:
    """
    Click 'Skip This Time' (or similar) post-login prompt if present.
    """
    # Try id first
    try:
        if click_button_by_id(driver, "skipButton", timeout=min(6, int(timeout))):
            sleep_with_reason(0.3, "clicked Skip via id")
            return True
    except Exception:
        pass
    # Broad text matcher
    xpats = [
        "//button[contains(normalize-space(),'Skip This Time')]",
        "//*[self::a or self::button][contains(normalize-space(),'Skip')]",
    ]
    for xp in xpats:
        try:
            el = find_with_frames(driver, By.XPATH, xp, timeout=3, clickable=True)
            if el and click_element(driver, el):
                sleep_with_reason(0.3, "clicked Skip via text")
                return True
        except Exception:
            continue
    return False


def ensure_landed_on_dashboard(driver, header_text: str = "ORACLE Aconex", wait_timeout: float = 5.0):
    """
    After login, optionally click 'Skip This Time' and validate the dashboard header text.
    Raises on validation failure.
    """
    try:
        click_skip_this_time(driver, timeout=4.0)
    except Exception:
        pass

    target = (header_text or "").strip().lower()
    if not target:
        return

    def _has_text(_):
        # Prefer DOM search with XPath across frames; fallback to page_source contains
        try:
            el = find_with_frames(driver, By.XPATH,
                                  "//*[contains(translate(normalize-space(.),'ABCDEFGHIJKLMNOPQRSTUVWXYZ','abcdefghijklmnopqrstuvwxyz'), '{}')]".format(target),
                                  timeout=1, clickable=False)
            if el:
                return True
        except Exception:
            pass
        try:
            src = (driver.page_source or "").lower()
            return target in src
        except Exception:
            return False

    ok = wait_until(driver, _has_text, timeout=wait_timeout, interval=0.5)
    if not ok:
        raise Exception(f"Dashboard header '{header_text}' not found after login")


def pl12_login_flow(driver, username: str, password: str, base_url: Optional[str], auth_option_texts: Sequence[str]):
    """
    Full PL12 login flow composed from the generic helpers in this module.
    Intended for reuse by page objects.
    """
    settle_ready_state(driver)
    switch_to_last_window(driver)
    navigate_to_base_if_mismatch(driver, base_url)
    dismiss_cookie_banners(driver)

    # Attempt to reveal classic username/password option if on an auth hub
    try:
        if click_auth_options(driver, auth_option_texts):
            switch_to_last_window(driver)
    except Exception:
        pass

    recover_from_gateway_error(driver, base_url, retries=3)

    # Username (allow time for redirects and option tiles)
    user_el = None
    end_wait = time.time() + 60
    while time.time() < end_wait and not user_el:
        user_el = find_username_field(driver)
        if user_el:
            break
        try:
            # Actively reveal username/password option and common label toggles
            click_auth_options(driver, auth_option_texts)
            click_any_text_contains(driver, ["Login Name", "Work Email", "Aconex username", "Aconex login", "Use your Aconex login"])
            dismiss_cookie_banners(driver)
        except Exception:
            pass
        smart_wait(driver, mode="sleep", timeout=0.5, reason="poll for username input")
    if not user_el:
        raise Exception("Username input not found")
    try:
        print(f"[WEB] Username element: {describe_element(user_el)}")
    except Exception:
        pass
    type_fast(driver, user_el, username)

    # Next button (id: nextButton) fallback to visible text and known IDCS ids
    did_next = click_button_by_id(driver, "nextButton", timeout=12)
    if not did_next:
        for bid in ("idcs-signin-basic-signin-form-nextBtn", "idcs-next", "continue", "idcs-continue"):
            if click_button_by_id(driver, bid, timeout=4):
                did_next = True
                break
    if not did_next:
        try:
            fb = find_with_frames(driver, By.XPATH, "//button[contains(normalize-space(),'Next') or contains(normalize-space(),'Continue') or contains(normalize-space(),'Proceed')]", timeout=6, clickable=True)
            if fb:
                click_element(driver, fb)
                did_next = True
        except Exception:
            pass
    if did_next:
        try:
            print("[WEB] Next/Continue clicked")
        except Exception:
            pass

    # Password
    pwd_el = find_password_field(driver)
    if not pwd_el:
        raise Exception("Password input not found")
    try:
        print(f"[WEB] Password element: {describe_element(pwd_el)}")
    except Exception:
        pass
    try:
        pwd_el.clear()
    except Exception:
        pass
    type_fast(driver, pwd_el, password)

    # Submit (same id nextButton), plus common ids and text fallbacks
    did_submit = click_button_by_id(driver, "nextButton", timeout=12)
    if not did_submit:
        for bid in ("loginBtn", "idcs-signin-basic-signin-form-submit", "idcs-submit"):
            if click_button_by_id(driver, bid, timeout=4):
                did_submit = True
                break
    if not did_submit:
        try:
            fb2 = find_with_frames(driver, By.XPATH, "//button[contains(normalize-space(),'Sign in') or contains(normalize-space(),'Log in') or contains(normalize-space(),'Login') or contains(normalize-space(),'Submit')]", timeout=6, clickable=True)
            if fb2:
                click_element(driver, fb2)
                did_submit = True
        except Exception:
            pass
    if did_submit:
        try:
            print("[WEB] Submit/Sign in clicked")
        except Exception:
            pass

    # Optional "Skip This Time"
    if not click_button_by_id(driver, "skipButton", timeout=6):
        try:
            sk = find_with_frames(driver, By.XPATH, "//button[contains(normalize-space(),'Skip')]", timeout=3, clickable=True)
            if sk:
                click_element(driver, sk)
        except Exception:
            pass

    wait_post_login_settle(driver)