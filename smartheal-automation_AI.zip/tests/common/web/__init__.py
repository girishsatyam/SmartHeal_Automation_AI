"""
Web-specific helpers and factories for Selenium-based UI tests.
This package currently exposes:
- tests.common.web.driver_factory.create_web_driver
"""