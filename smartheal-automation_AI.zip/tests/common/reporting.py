import os
import json
import getpass
import socket


def get_alluredir(config):
    try:
        ad = config.getoption("--alluredir")
        if ad:
            return os.path.abspath(ad)
    except Exception:
        pass
    return os.path.abspath(os.path.join(os.getcwd(), "reports", "allure-results"))


def resolve_executor_name():
    try:
        user = os.environ.get("USER") or os.environ.get("LOGNAME") or getpass.getuser()
    except Exception:
        user = None
    return "Girish Satyam" if user == "gsatyam" else (user or "Unknown")


def write_executor_json(alluredir, display_name):
    data = {
        "name": display_name,
        "type": "local",
        "hostname": socket.gethostname(),
        "reportName": "SmartHeal Automation Report",
    }
    try:
        os.makedirs(alluredir, exist_ok=True)
        with open(os.path.join(alluredir, "executor.json"), "w") as f:
            json.dump(data, f)
    except Exception:
        pass


def detect_platforms_from_results(alluredir):
    plats = set()
    try:
        # 1) Scan main results dir
        for fname in os.listdir(alluredir):
            if not fname.endswith(".json"):
                continue
            try:
                with open(os.path.join(alluredir, fname)) as f:
                    obj = json.load(f)
                for lab in obj.get("labels", []):
                    if lab.get("name") == "tag" and lab.get("value") in ("android", "ios", "web"):
                        plats.add(lab["value"])
            except Exception:
                continue
        # 2) Also scan platform-specific dirs if present
        base = os.path.dirname(alluredir)
        for sub in ("allure-results-android", "allure-results-ios", "allure-results-web"):
            alt = os.path.join(base, sub)
            if not os.path.isdir(alt):
                continue
            try:
                for fname in os.listdir(alt):
                    if not fname.endswith(".json"):
                        continue
                    try:
                        with open(os.path.join(alt, fname)) as f:
                            obj = json.load(f)
                        for lab in obj.get("labels", []):
                            if lab.get("name") == "tag" and lab.get("value") in ("android", "ios", "web"):
                                plats.add(lab["value"])
                    except Exception:
                        continue
            except Exception:
                continue
    except Exception:
        pass
    return plats


def platform_string(plats):
    names = []
    if "android" in plats:
        names.append("Android")
    if "ios" in plats:
        names.append("iOS")
    if "web" in plats:
        names.append("Web")
    if not names:
        return ""
    if len(names) == 2:
        return " & ".join(names)
    return ", ".join(names) if len(names) > 1 else names[0]


__all__ = [
    "get_alluredir",
    "resolve_executor_name",
    "write_executor_json",
    "detect_platforms_from_results",
    "platform_string",
]
