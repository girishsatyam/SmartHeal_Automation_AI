import yaml
import os
import re

class DataLoader:
    @staticmethod
    def get_data():
        raw_env = os.environ.get('TARGET_ENV', 'OCIPL12').strip().upper()
        target_env = raw_env
        if "US1UAT" in raw_env: target_env = "US1UAT"
        elif "PL" in raw_env or "OCIPL" in raw_env:
            match = re.search(r'(\d+)', raw_env)
            if match:
                number = int(match.group(1))
                target_env = f"OCIPL{number}"

        filename = f"test_data_{target_env}.yaml"
        path = os.path.join(os.path.dirname(__file__), '..', '..', 'data', 'test_data', filename)
        print(f"Loading Data: {filename} (Derived from '{raw_env}')")
        if not os.path.exists(path): raise FileNotFoundError(f"Missing Data File: {path}")
        with open(path, 'r') as f: return yaml.safe_load(f)