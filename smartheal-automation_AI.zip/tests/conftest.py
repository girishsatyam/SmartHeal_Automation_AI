import pytest
import os
import json
import subprocess
import allure
import random
from appium import webdriver
from appium.options.android import UiAutomator2Options
from appium.options.ios import XCUITestOptions
import re
from uuid import uuid4

from tests.common.utils import get_bundle_id as common_get_bundle_id
from tests.common.device import AppLifecycleManager as CommonAppLifecycleManager, \
    IOSLifecycleManager as CommonIOSLifecycleManager
from tests.common.reporting import (
    get_alluredir as _common_get_alluredir,
    resolve_executor_name as _common_resolve_executor_name,
    write_executor_json as _common_write_executor_json,
    detect_platforms_from_results as _common_detect_platforms_from_results,
    platform_string as _common_platform_string,
)

CONFIG_DIR = os.path.join(os.path.dirname(__file__), '..', 'config')


def get_driver(platform_name):
    config_file = f'{platform_name}_config.json'
    path = os.path.join(CONFIG_DIR, config_file)
    if not os.path.exists(path):
        return None

    with open(path, 'r') as f:
        caps = json.load(f)
    if 'app' in caps:
        root = os.path.abspath(os.path.join(CONFIG_DIR, '..'))
        caps['app'] = os.path.join(root, 'apps', os.path.basename(caps['app']))

    if platform_name == 'android':
        if not os.path.exists(caps['app']):
            raise FileNotFoundError(f"APK Missing: {caps['app']}")
        pkg = caps.get('appPackage', 'com.oracle.aconex.qa')
        CommonAppLifecycleManager(caps['app'], pkg).force_fresh_install_android()
        caps['systemPort'] = random.randint(8200, 8299)
    elif platform_name == 'ios':
        app_path = caps.get('app')
        if not os.path.exists(app_path):
            raise FileNotFoundError(f"iOS .app Missing: {app_path}")
        bundle_id = common_get_bundle_id(app_path)
        if bundle_id:
            caps['bundleId'] = bundle_id
        manager = CommonIOSLifecycleManager(caps.get('deviceName', 'iPhone 14'))
        udid, runtime_version = manager.find_or_boot()
        if udid:
            caps['udid'] = udid
            if runtime_version:
                caps['platformVersion'] = runtime_version
        print(f"[iOS] Simulator selection: udid={caps.get('udid')} platformVersion={caps.get('platformVersion')}")

        try:
            if bundle_id:
                subprocess.run(["xcrun", "simctl", "uninstall", caps['udid'], bundle_id], check=False,
                               stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
            subprocess.run(["xcrun", "simctl", "install", caps['udid'], app_path], check=True,
                           stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        except Exception as e:
            print(f"iOS Install Failed: {e}")
            return None
        caps['wdaLocalPort'] = caps.get('wdaLocalPort', random.randint(8100, 8199))
        caps['skipAppInstalledCheck'] = True
        caps['noReset'] = True
        # Auto-handle any permission/system alerts that may block UI during parallel runs
        caps['autoAcceptAlerts'] = True
        caps['autoDismissAlerts'] = True
        caps.pop('fullReset', None)
        caps.pop('app', None)

    elif platform_name == 'web':
        try:
            from tests.common.web.driver_factory import create_web_driver
        except Exception as e:
            print(f"Web driver factory import error: {e}")
            return None
        try:
            try:
                root = os.path.abspath(os.path.join(CONFIG_DIR, '..'))
                repo_bin = os.path.join(root, 'drivers', 'cft', '143.0.7499.170', 'chromedriver')
                if os.path.exists(repo_bin):
                    os.environ['CHROMEDRIVER'] = repo_bin
                    os.environ['CHROMEDRIVER_PREFER_REPO'] = '1'
            except Exception:
                pass
            return create_web_driver(os.path.join(CONFIG_DIR, 'web_config.json'))
        except Exception as e:
            print(f"Driver Init Error (web): {e}")
            return None

    try:
        if platform_name == 'android':
            options = UiAutomator2Options().load_capabilities(caps)
        elif platform_name == 'ios':
            options = XCUITestOptions().load_capabilities(caps)
        else:
            return None
        server_url = os.environ.get('APPIUM_URL', 'http://127.0.0.1:4723/wd/hub')
        return webdriver.Remote(server_url, options=options)
    except Exception as e:
        print(f"Driver Init Error ({platform_name}): {e}")
        return None


@pytest.fixture(scope="function")
def platform(request):
    p = (os.environ.get("TEST_PLATFORM") or os.environ.get("PLATFORM") or "").strip().lower()
    if p in ("web", "ios", "android"):
        return p
    try:
        if request.node.get_closest_marker('web'):
            return 'web'
        elif request.node.get_closest_marker('ios'):
            return 'ios'
        elif request.node.get_closest_marker('android'):
            return 'android'
    except Exception:
        pass
    return 'android'


@pytest.fixture(scope="function")
def driver(platform):
    d = get_driver(platform)
    yield d
    if d:
        d.quit()


def pytest_collection_modifyitems(config, items):
    disable_web = os.environ.get("DISABLE_WEB", "").strip().lower() in ("1", "true", "yes")
    if not disable_web:
        return
    skip_web = pytest.mark.skip(reason="Web UI tests are disabled by env (DISABLE_WEB).")
    for item in items:
        try:
            fspath = os.path.normpath(str(item.fspath))
            parts = fspath.split(os.sep)
            if "web" in parts:
                item.add_marker(skip_web)
        except Exception:
            pass


@pytest.hookimpl(hookwrapper=True)
def pytest_runtest_makereport(item, call):
    outcome = yield
    report = outcome.get_result()
    if report.when == "call" and report.failed:
        driver = item.funcargs.get('driver')
        if driver:
            try:
                allure.attach(driver.get_screenshot_as_png(), name="Screenshot",
                              attachment_type=allure.attachment_type.PNG)
            except Exception:
                pass


@pytest.hookimpl(tryfirst=True)
def pytest_runtest_setup(item):
    try:
        plat = 'android'
        if item.get_closest_marker('web'):
            plat = 'web'
        elif item.get_closest_marker('ios'):
            plat = 'ios'
        elif item.get_closest_marker('android'):
            plat = 'android'
        env_plat = (os.environ.get("TEST_PLATFORM") or os.environ.get("PLATFORM") or "").strip().lower()
        if env_plat in ("web", "ios", "android"):
            plat = env_plat
        nodeid = getattr(item, 'nodeid', '')
        print("\n" + "=" * 8 + f" RUNNING [{plat.upper()}] {nodeid} " + "=" * 8)
    except Exception:
        pass


def _get_alluredir(config):
    return _common_get_alluredir(config)


def _resolve_executor_name():
    return _common_resolve_executor_name()


def _write_executor_json(alluredir, display_name):
    _common_write_executor_json(alluredir, display_name)


def _detect_platforms_from_results(alluredir):
    return _common_detect_platforms_from_results(alluredir)


def _platform_string(plats):
    return _common_platform_string(plats)


def _read_heal_events(alluredir: str):
    events = []
    seen = set()
    try:
        for name in os.listdir(alluredir):
            if not name.startswith("heal_events") or not name.endswith(".jsonl"): continue
            p = os.path.join(alluredir, name)
            try:
                with open(p, "r", encoding="utf-8") as f:
                    for line in f:
                        line = (line or "").strip()
                        if not line: continue
                        try:
                            ev = json.loads(line)
                            key = (ev.get("ts"), ev.get("platform"), ev.get("page"), ev.get("key"),
                                   ev.get("new_locator"))
                            if key not in seen:
                                seen.add(key)
                                events.append(ev)
                        except Exception:
                            continue
            except Exception:
                continue
        base = os.path.dirname(alluredir)
        for sub in ("allure-results-android", "allure-results-ios", "allure-results-web"):
            alt = os.path.join(base, sub)
            if not os.path.isdir(alt): continue
            try:
                for name in os.listdir(alt):
                    if not name.startswith("heal_events") or not name.endswith(".jsonl"): continue
                    p = os.path.join(alt, name)
                    try:
                        with open(p, "r", encoding="utf-8") as f:
                            for line in f:
                                line = (line or "").strip()
                                if not line: continue
                                try:
                                    ev = json.loads(line)
                                    key = (ev.get("ts"), ev.get("platform"), ev.get("page"), ev.get("key"),
                                           ev.get("new_locator"))
                                    if key not in seen:
                                        seen.add(key)
                                        events.append(ev)
                                except Exception:
                                    continue
                    except Exception:
                        continue
            except Exception:
                continue
    except Exception:
        pass
    return events


def _build_heal_table_html(rows):
    try:
        html = []
        html.append("<html><head><meta charset='utf-8'><title>SmartHeal Summary</title>")
        html.append(
            "<style>body{font-family:Arial,sans-serif;padding:16px;} table{border-collapse:collapse;width:100%;} th,td{border:1px solid #ddd;padding:8px;font-size:13px;} th{background:#f4f4f4;} .muted{color:#666}</style></head><body>")
        html.append("<h2>SmartHeal - Locator & Label Changes (This Run)</h2>")
        html.append(f"<p class='muted'>Total changes: {len(rows)}</p>")
        if rows:
            # UPDATED HEADERS
            html.append(
                "<table><thead><tr><th>Time</th><th>Platform</th><th>Page</th><th>Key</th><th>Old Strategy</th><th>Old Value</th><th>New Strategy</th><th>New Value</th><th>Confidence</th></tr></thead><tbody>")
            for ev in rows:
                try:
                    conf = ev.get("confidence", "")
                    try:
                        conf = f"{float(conf):.4f}"
                    except Exception:
                        conf = str(conf)

                    row_style = ""
                    if ev.get("strategy") == "LABEL_UPDATE":
                        row_style = "style='background-color:#e6f7ff'"

                    html.append(
                        f"<tr {row_style}><td>{ev.get('ts', '')}</td><td>{ev.get('platform', '')}</td><td>{ev.get('page', '')}</td><td>{ev.get('key', '')}</td><td>{ev.get('old_strategy', '')}</td><td>{(ev.get('old_locator') or '')}</td><td>{ev.get('new_strategy', '')}</td><td>{ev.get('new_locator', '')}</td><td>{conf}</td></tr>"
                    )
                except Exception:
                    continue
            html.append("</tbody></table>")
        else:
            html.append("<p>No healing events recorded in this run.</p>")
        html.append("</body></html>")
        return "\n".join(html)
    except Exception:
        return "<html><body><p>Failed to build SmartHeal summary.</p></body></html>"


def _write_allure_summary_result(alluredir: str, html_content: str):
    try:
        os.makedirs(alluredir, exist_ok=True)
        uid = str(uuid4())
        attach_name = f"smartheal-summary-{uid}.html"
        with open(os.path.join(alluredir, attach_name), "w", encoding="utf-8") as f:
            f.write(html_content)
        result = {
            "uuid": uid,
            "name": "SmartHeal Summary",
            "fullName": "SmartHeal Summary",
            "historyId": "smartheal-summary",
            "status": "passed",
            "stage": "finished",
            "attachments": [{"name": "Healed Locators", "source": attach_name, "type": "text/html"}],
            "labels": [{"name": "tag", "value": "smartheal"}],
        }
        with open(os.path.join(alluredir, f"{uid}-result.json"), "w", encoding="utf-8") as rf:
            json.dump(result, rf)
    except Exception:
        pass


def _print_console_heal_summary(alluredir: str):
    try:
        rows = _read_heal_events(alluredir)
        print("\n" + "=" * 60)
        print("SmartHeal - Locator & Label Changes (This Run)")
        print("=" * 60)
        if not rows:
            print("No healing events recorded.")
            return

        def trunc(s, w):
            s = "" if s is None else str(s)
            return s if len(s) <= w else (s[: max(0, w - 1)] + "…")

        # UPDATED HEADERS
        headers = ["Time", "Plat", "Page", "Key", "OldStrat", "Old Value", "NewStrat", "New Value", "Conf"]
        widths = [19, 5, 16, 18, 9, 34, 9, 34, 7]
        fmt = " {0:<19} | {1:<5} | {2:<16} | {3:<18} | {4:<9} | {5:<34} | {6:<9} | {7:<34} | {8:>7} "
        header_line = fmt.format(*[trunc(h, w) for h, w in zip(headers, widths)])
        sep = "-" * len(header_line)
        print(header_line)
        print(sep)
        for ev in rows:
            conf = ev.get("confidence", "")
            try:
                conf_str = f"{float(conf):.4f}"
            except Exception:
                conf_str = str(conf)
            values = [
                trunc(ev.get("ts", ""), widths[0]),
                trunc(ev.get("platform", ""), widths[1]),
                trunc(ev.get("page", ""), widths[2]),
                trunc(ev.get("key", ""), widths[3]),
                trunc(ev.get("old_strategy", ""), widths[4]),
                trunc(ev.get("old_locator", ""), widths[5]),
                trunc(ev.get("new_strategy", ""), widths[6]),
                trunc(ev.get("new_locator", ""), widths[7]),
                trunc(conf_str, widths[8]),
            ]
            print(fmt.format(*values))
        print(f"\nTotal changes: {len(rows)}")
    except Exception as e:
        print(f"  Failed to print SmartHeal console summary: {e}")


@pytest.hookimpl(tryfirst=True)
def pytest_sessionstart(session):
    alluredir = _get_alluredir(session.config)
    _write_executor_json(alluredir, _resolve_executor_name())


@pytest.hookimpl(trylast=True)
def pytest_sessionfinish(session, exitstatus):
    alluredir = _get_alluredir(session.config)
    plats = _detect_platforms_from_results(alluredir)
    try:
        plats.update(getattr(session.config, "_seen_platforms", set()))
    except Exception:
        pass
    platform_value = _platform_string(plats)
    target_env = os.environ.get("TARGET_ENV", "")
    lines = []
    if platform_value: lines.append(f"Platform={platform_value}")
    if target_env: lines.append(f"Server={target_env}")
    display = _resolve_executor_name()
    if display: lines.append(f"Executor={display}")
    if lines:
        try:
            os.makedirs(alluredir, exist_ok=True)
            with open(os.path.join(alluredir, "environment.properties"), "w") as f:
                f.write("\n".join(lines) + "\n")
        except Exception:
            pass
    try:
        _print_console_heal_summary(alluredir)
    except Exception:
        pass
    try:
        events = _read_heal_events(alluredir)
        html = _build_heal_table_html(events)
        _write_allure_summary_result(alluredir, html)
    except Exception:
        pass
    _write_executor_json(alluredir, _resolve_executor_name())