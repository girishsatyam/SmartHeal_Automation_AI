from sentence_transformers import SentenceTransformer
import os
import sys
sys.path.append(os.getcwd())
from smartheal.config import get_nlp_model_path
target = get_nlp_model_path()
MODEL_NAME = 'BAAI/bge-m3'
print(f"Downloading {MODEL_NAME} to: {target}")
print("Please ensure VPN is DISCONNECTED.")
os.environ["HF_HUB_OFFLINE"] = "0"
try:
    model = SentenceTransformer(MODEL_NAME)
    model.save(target)
    print('Download Complete!')
except Exception as e:
    print(f"Error: {e}")
