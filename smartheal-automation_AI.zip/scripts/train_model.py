import numpy as np
import lightgbm as lgb
import joblib
import os
import sys
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from smartheal.config import get_model_path
def train():
    print("Training Ranking Model...")
    n = 2000
    X = np.random.rand(n, 3) 
    y = (X[:, 0] * 0.8 + X[:, 1] * 0.2) > 0.5
    model = lgb.LGBMClassifier()
    model.fit(X, y.astype(int))
    path = get_model_path()
    os.makedirs(path, exist_ok=True)
    joblib.dump(model, os.path.join(path, 'lightgbm_ranker.pkl'))
    print("Model Ready.")
if __name__ == "__main__": train()