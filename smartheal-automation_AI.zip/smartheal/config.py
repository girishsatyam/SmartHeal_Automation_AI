import os
import json

_SMARTHEAL_CONFIG_CACHE = None

def get_root():
    return os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

def get_locators_path(platform):
    return os.path.join(get_root(), 'data', 'locators', platform)

def get_model_path():
    return os.path.join(get_root(), 'models')

def get_nlp_model_path():
    return os.path.join(get_root(), 'models', 'nlp')


def get_smartheal_config():
    """
    Load optional SmartHeal runtime configuration from config/smartheal_config.json.
    Safe defaults are used if the file is missing or invalid. A global minimum
    confidence floor of 0.50 is always enforced by callers.
    """
    global _SMARTHEAL_CONFIG_CACHE
    if _SMARTHEAL_CONFIG_CACHE is not None:
        return _SMARTHEAL_CONFIG_CACHE
    cfg_path = os.path.join(get_root(), 'config', 'smartheal_config.json')
    defaults = {
        "skip_hidden_web": False,
        "min_confidence_floor": 0.50,
        "top_k": 10,
        "safe_id_floor": 0.92,
        "safe_native_floor": 0.86,
        "lock_enabled": True,
        "post_probe_interactable_gate": True,
        "safe_early_stop_conf": 0.95,
        "android_desc_contains": False,
        "enable_data_testid_boost": False,
        "enable_aria_labelledby": False,
        "enable_fuzzy_tokens": False,
        "debounce_label_ms": 30000,

        # Robustness controls (safe defaults keep existing behavior)
        "dry_run": False,
        "probation_enabled": False,
        "probation_successes": 2,
        "scan_max_nodes": 0,
        "scan_time_budget_ms": 0
    }
    try:
        if os.path.isfile(cfg_path):
            with open(cfg_path, 'r', encoding='utf-8') as f:
                data = json.load(f) or {}
            # Merge
            for k, v in defaults.items():
                data.setdefault(k, v)
            _SMARTHEAL_CONFIG_CACHE = data
            return _SMARTHEAL_CONFIG_CACHE
    except Exception:
        pass
    _SMARTHEAL_CONFIG_CACHE = defaults
    return _SMARTHEAL_CONFIG_CACHE