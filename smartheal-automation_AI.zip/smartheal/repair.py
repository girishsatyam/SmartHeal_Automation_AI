import yaml
import os
from .config import get_locators_path, get_root, get_smartheal_config
from datetime import datetime
import json
from contextlib import contextmanager

try:
    import portalocker  # type: ignore
except Exception:
    portalocker = None
try:
    import fcntl  # POSIX only
except Exception:
    fcntl = None

try:
    import allure
except Exception:
    allure = None


class RepairAgent:
    def _should_skip_persist(self):
        """
        In parallel mode (android+ios running together), avoid persisting locator/label
        updates to YAML to prevent cross-test instability. Can be overridden by
        setting SMARTHEAL_ALLOW_WRITE=1.
        """
        try:
            if os.environ.get("SMARTHEAL_ALLOW_WRITE", "").strip() == "1":
                return False
            rp = (os.environ.get("RUN_PLATFORMS") or "").strip().lower()
            if "android" in rp and "ios" in rp:
                return True
        except Exception:
            pass
        return False
    def apply_fix(self, platform, page_name, locator_key, new_data):
        """
        Persist the healed locator.
        LOGIC UPDATED: Strict acceptance gate to prevent weak heals.
        """
        # Do not persist changes in parallel runs to keep tests stable
        if self._should_skip_persist():
            try:
                self._log_event(platform, page_name, locator_key, new_data,
                                float(new_data.get('ml_confidence', new_data.get('semantic_score', 0) or 0)),
                                status="skipped_parallel", reason="parallel_mode_readonly")
            except Exception:
                pass
            return True
        folder = get_locators_path(platform)
        path = os.path.join(folder, f"{page_name}.yaml")
        if not os.path.exists(path):
            return False

        # --- STRICT THRESHOLD LOGIC ---
        try:
            conf_val = float(new_data.get('ml_confidence', new_data.get('semantic_score', 0) or 0))
        except Exception:
            conf_val = 0.0

        strategy = new_data.get('strategy', 'xpath')

        # Global minimum acceptance threshold. Do not accept anything below 0.50.
        acceptance_threshold = 0.50

        # Hard gate: if confidence is < 0.50, reject at any cost
        if conf_val < acceptance_threshold:
            self._log_event(platform, page_name, locator_key, new_data, conf_val, status="rejected_low_conf", reason=f"conf<{acceptance_threshold:.2f}")
            print(
                f"SELF-HEALING [{platform.upper()}]: Rejected '{locator_key}' (Conf: {conf_val:.2f} < {acceptance_threshold})")
            return False

        try:
            # 1. Load Data
            with open(path, 'r', encoding='utf-8') as f:
                data = yaml.safe_load(f) or {}

            if locator_key not in data or not isinstance(data.get(locator_key), dict):
                return False

            old_meta = (data.get(locator_key) or {}).copy()
            old_locator = old_meta.get('default_locator')
            old_strategy = old_meta.get('strategy')

            # 2. No-op Check
            proposed_strategy = new_data.get('strategy') or old_strategy
            if str(old_locator) == str(new_data.get('locator')) and (proposed_strategy == old_strategy):
                self._log_event(platform, page_name, locator_key, new_data, conf_val, status="noop_same_value", reason="noop",
                                old_locator=old_locator, old_strategy=old_strategy)
                return True

            # 3. Apply Updates
            entry = data[locator_key]
            entry['default_locator'] = new_data['locator']
            if new_data.get('strategy'):
                entry['strategy'] = new_data['strategy']
            # rename timestamp key to last_locator_healed
            entry['last_locator_healed'] = datetime.now().isoformat()
            entry['confidence'] = round(conf_val, 4)

            # 4. Atomic Write with Backup
            self._create_backup(path, page_name, platform)
            self._write_yaml(path, data)

            print(f"SELF-HEALING [{platform.upper()}]: FIXED '{locator_key}' -> {entry.get('strategy', 'xpath')}")

            # 5. Reporting
            self._log_event(platform, page_name, locator_key, new_data, conf_val, status="updated", reason="accepted",
                            old_locator=old_locator, old_strategy=old_strategy)
            if allure:
                self._attach_to_allure(page_name, locator_key, old_locator, old_strategy, entry['default_locator'],
                                       entry.get('strategy'), conf_val, platform)

            return True
        except Exception as e:
            print(f"Heal Write Failed: {e}")
            return False

    def update_semantic_label(self, platform, page_name, locator_key, new_label):
        """
        REVERSE HEALING: Updates YAML 'semantic_label' when text on screen changes.
        """
        folder = get_locators_path(platform)
        path = os.path.join(folder, f"{page_name}.yaml")

        if not os.path.exists(path):
            return False

        # Do not persist changes in parallel runs to keep tests stable
        if self._should_skip_persist():
            try:
                event_data = {
                    "locator": new_label,
                    "strategy": "LABEL_UPDATE",
                    "strategy_family": "semantic",
                    "had_predicate": False,
                    "live_probe_ok": True
                }
                self._log_event(platform, page_name, locator_key, event_data, 1.0,
                                status="skipped_parallel", reason="parallel_mode_readonly")
            except Exception:
                pass
            return True

        try:
            with open(path, 'r', encoding='utf-8') as f:
                data = yaml.safe_load(f) or {}

            if locator_key not in data or not isinstance(data.get(locator_key), dict):
                return False

            entry = data[locator_key]
            old_label = entry.get('semantic_label', '')

            # Apply Update
            try:
                entry['semantic_label'] = str(new_label).strip()
            except Exception:
                entry['semantic_label'] = f"{new_label}"
            # rename timestamp key to last_label_healed
            entry['last_label_healed'] = datetime.now().isoformat()

            # Atomic Write
            # Create a backup similar to locator healing for traceability
            try:
                self._create_backup(path, page_name, platform)
            except Exception:
                pass
            self._write_yaml(path, data)

            print(
                f"REVERSE HEALING [{platform.upper()}]: Updated Label for '{locator_key}' | '{old_label}' -> '{new_label}'")

            # Log Event (Mapping Label to Locator fields for table compatibility)
            event_data = {
                "locator": new_label,
                "strategy": "LABEL_UPDATE",
                "strategy_family": "semantic",
                "had_predicate": False,
                "live_probe_ok": True
            }
            # We pass 'old_label' as 'old_locator' so it shows up in the Old Value column
            self._log_event(platform, page_name, locator_key, event_data, 1.0, status="label_updated", reason="label_drift",
                            old_locator=old_label, old_strategy="LABEL")

            return True

        except Exception as e:
            print(f"REVERSE HEALING FAILED: {e}")
            return False

    # --- Helper Methods ---

    @contextmanager
    def _file_lock(self, lock_path: str):
        cfg = {}
        try:
            cfg = get_smartheal_config() or {}
        except Exception:
            cfg = {}
        if not bool(cfg.get('lock_enabled', True)):
            # Locking disabled
            yield None
            return
        # Prefer portalocker; fallback to fcntl; else no-op
        if portalocker is not None:
            os.makedirs(os.path.dirname(lock_path), exist_ok=True)
            with open(lock_path, 'a+') as lf:
                try:
                    portalocker.lock(lf, portalocker.LOCK_EX)
                    yield lf
                finally:
                    try:
                        portalocker.unlock(lf)
                    except Exception:
                        pass
            return
        if fcntl is not None:
            os.makedirs(os.path.dirname(lock_path), exist_ok=True)
            with open(lock_path, 'a+') as lf:
                try:
                    fcntl.flock(lf.fileno(), fcntl.LOCK_EX)
                    yield lf
                finally:
                    try:
                        fcntl.flock(lf.fileno(), fcntl.LOCK_UN)
                    except Exception:
                        pass
            return
        # no-op
        yield None

    def _write_yaml(self, path, data):
        tmp_path = path + ".tmp"
        lock_path = path + ".lock"
        with self._file_lock(lock_path):
            with open(tmp_path, 'w', encoding='utf-8') as f:
                yaml.safe_dump(data, f, sort_keys=False, allow_unicode=True)
                f.flush()
                os.fsync(f.fileno())
            os.replace(tmp_path, path)

    def _create_backup(self, path, page_name, platform):
        try:
            backups_dir = os.path.join(get_root(), "reports", "heal_backups", platform)
            os.makedirs(backups_dir, exist_ok=True)
            ts = datetime.now().strftime("%Y%m%d-%H%M%S")
            backup_path = os.path.join(backups_dir, f"{page_name}-{ts}.yaml")
            with open(path, 'r', encoding='utf-8') as src, open(backup_path, 'w', encoding='utf-8') as dst:
                dst.write(src.read())
        except Exception:
            pass

    def _log_event(self, platform, page_name, key, new_data, conf, status, old_locator=None, old_strategy=None, reason=None):
        try:
            results_dir = os.path.join(get_root(), "reports", "allure-results")
            os.makedirs(results_dir, exist_ok=True)

            event = {
                "ts": datetime.now().isoformat(),
                "platform": platform,
                "page": page_name,
                "key": key,
                "old_locator": old_locator,
                "old_strategy": old_strategy,
                "new_locator": new_data.get("locator"),
                "new_strategy": new_data.get("strategy"),
                "confidence": round(float(conf), 4),
                "status": status,
                "reason": reason or status,
                "strategy_family": new_data.get('strategy_family'),
                "had_predicate": bool(new_data.get('had_predicate')),
                "live_probe_ok": bool(new_data.get('live_probe_ok'))
            }

            line = json.dumps(event, ensure_ascii=False) + "\n"

            with open(os.path.join(results_dir, "heal_events.jsonl"), "a", encoding="utf-8") as hf:
                hf.write(line)

            try:
                plat_dir = os.path.join(get_root(), "reports", f"allure-results-{platform}")
                if os.path.isdir(plat_dir):
                    with open(os.path.join(plat_dir, "heal_events.jsonl"), "a", encoding="utf-8") as hf2:
                        hf2.write(line)
            except Exception:
                pass
        except Exception:
            pass

    def _attach_to_allure(self, page, key, old_loc, old_strat, new_loc, new_strat, conf, platform):
        try:
            table = f"""
<table border="1" cellpadding="6" cellspacing="0">
  <thead><tr><th>Time</th><th>Platform</th><th>Page</th><th>Key</th><th>Old Strategy</th><th>Old Value</th><th>New Strategy</th><th>New Value</th><th>Confidence</th></tr></thead>
  <tbody>
    <tr>
      <td>{datetime.now().isoformat()}</td>
      <td>{platform}</td>
      <td>{page}</td>
      <td>{key}</td>
      <td>{old_strat or ''}</td>
      <td>{(old_loc or '')}</td>
      <td>{new_strat}</td>
      <td>{new_loc}</td>
      <td>{conf:.4f}</td>
    </tr>
  </tbody>
</table>
""".strip()
            allure.attach(table, name=f"Heal: {page}.{key}", attachment_type=allure.attachment_type.HTML)
        except Exception:
            pass