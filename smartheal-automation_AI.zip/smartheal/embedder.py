import torch
from sentence_transformers import SentenceTransformer
from sentence_transformers import models as st_models
import os
import json
import collections
from .config import get_nlp_model_path

MODEL_NAME = 'BAAI/bge-m3'

class ElementEmbedder:
    _instance = None
    def __init__(self):
        if ElementEmbedder._instance is None:
            self._load_model()
        self.model = ElementEmbedder._instance
        self.device = self.model.device if self.model else 'cpu'
        # Small LRU cache to avoid re-encoding the same strings repeatedly
        try:
            self._enc_cache_max = int(os.getenv("EMBED_CACHE_SIZE", "256"))
        except Exception:
            self._enc_cache_max = 256
        self._enc_cache: collections.OrderedDict[str, object] = collections.OrderedDict()

    def _load_model(self):
        device = 'cuda' if torch.cuda.is_available() else 'cpu'
        local_path = get_nlp_model_path()
        print(f"Loading AI (Offline) from: {local_path}")
        os.environ["HF_HUB_OFFLINE"] = "1"
        os.environ["TRANSFORMERS_OFFLINE"] = "1"
        # Avoid advisory warnings that sometimes surface with offline loads
        os.environ.setdefault("TRANSFORMERS_NO_ADVISORY_WARNINGS", "1")
        if not os.path.exists(local_path) or not os.listdir(local_path):
            print("CRITICAL: Local model missing. Run download_model.py!")
            ElementEmbedder._instance = None
            return

        # Quick integrity check to ensure we're pointing at an ST root and not a submodule
        st_root_ok = all(
            os.path.exists(os.path.join(local_path, f)) for f in ("modules.json", "config_sentence_transformers.json")
        )
        if not st_root_ok:
            print("CRITICAL: Invalid NLP model layout. Please re-download with: python scripts/download_model.py")
            ElementEmbedder._instance = None
            return

        # First attempt: load directly from provided local path
        try:
            ElementEmbedder._instance = SentenceTransformer(local_path, device=device)
            print("AI Model Loaded Successfully.")
            return
        except Exception as e:
            msg = str(e)
            warn_text = (
                "AI Init Warning: Local NLP model appears incompatible with current libraries (e.g., dict lacks model_type). "
                "Attempting safe manual assembly. To refresh the model, run: python scripts/download_model.py"
            )
            if "model_type" in msg or "Unrecognized model" in msg or "dict" in msg:
                print(warn_text)
            else:
                print(f"AI Init Failed from base path: {e}")

        # Fallback: Manually assemble pipeline to avoid mis-detecting submodules like 1_Pooling
        try:
            modules = []
            transformer = st_models.Transformer(local_path, device=device)
            modules.append(transformer)

            pool_dir = os.path.join(local_path, '1_Pooling')
            if os.path.isdir(pool_dir):
                try:
                    modules.append(st_models.Pooling.load(pool_dir))
                except Exception:
                    # As a last resort, create a default mean pooling layer
                    emb_dim = getattr(transformer, 'get_word_embedding_dimension', lambda: 768)()
                    modules.append(st_models.Pooling(emb_dim))

            norm_dir = os.path.join(local_path, '2_Normalize')
            if os.path.isdir(norm_dir):
                try:
                    modules.append(st_models.Normalize.load(norm_dir))
                except Exception:
                    pass

            ElementEmbedder._instance = SentenceTransformer(modules=modules, device=device)
            print("AI Model Loaded Successfully (manual assembly).")
            return
        except Exception as e:
            print(f"CRITICAL: Could not construct SentenceTransformer from local NLP folder: {e}")
            ElementEmbedder._instance = None

    def encode(self, text):
        if not self.model or not text:
            return None
        key = str(text).strip().lower()
        try:
            if key in self._enc_cache:
                # Move to end to mark as recently used
                val = self._enc_cache.pop(key)
                self._enc_cache[key] = val
                return val
        except Exception:
            pass
        emb = self.model.encode(str(text), convert_to_tensor=True)
        try:
            # basic LRU: pop least recently used when over capacity
            if len(self._enc_cache) >= self._enc_cache_max:
                try:
                    self._enc_cache.popitem(last=False)
                except Exception:
                    self._enc_cache.clear()
            self._enc_cache[key] = emb
        except Exception:
            pass
        return emb


    def similarity(self, emb1, emb2):
        if emb1 is None or emb2 is None:
            return 0.0
        return torch.nn.functional.cosine_similarity(emb1, emb2, dim=0).item()

    def encode_many(self, texts):
        """
        Batch-encode a list of texts. Returns a tensor of shape [N, D] when
        a model is available; otherwise returns None.
        Caches individual rows in the LRU cache for future single-lookups.
        """
        if not self.model or not texts:
            return None
        # Normalize keys used for caching
        norm_keys = [str(t).strip().lower() if t else "" for t in texts]
        # Fast path: if all cached, stack and return
        try:
            cached = []
            all_cached = True
            for k in norm_keys:
                if k in self._enc_cache:
                    val = self._enc_cache.pop(k)
                    self._enc_cache[k] = val
                    cached.append(val)
                else:
                    all_cached = False
                    break
            if all_cached and cached:
                try:
                    return torch.stack(cached, dim=0)
                except Exception:
                    pass
        except Exception:
            pass

        # Encode full batch (simpler and efficient); then populate cache
        embs = self.model.encode(list(texts), convert_to_tensor=True)
        try:
            for i, k in enumerate(norm_keys):
                val = embs[i]
                if len(self._enc_cache) >= self._enc_cache_max:
                    try:
                        self._enc_cache.popitem(last=False)
                    except Exception:
                        self._enc_cache.clear()
                self._enc_cache[k] = val
        except Exception:
            pass
        return embs
