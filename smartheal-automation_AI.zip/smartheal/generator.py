from lxml import etree, html
from .embedder import ElementEmbedder
from .config import get_smartheal_config
import re
import time
from typing import List, Dict, Any, Optional, Set


def _normalize_text(s: Optional[str]) -> str:
    if not s:
        return ""
    s = s.lower().strip()
    # de-punctuate but keep spaces/numbers
    s = re.sub(r"[^a-z0-9\s]+", " ", s)
    s = re.sub(r"\s+", " ", s).strip()
    return s


def _label_tokens(semantic_label: Optional[str]) -> List[str]:
    base = _normalize_text(semantic_label)
    if not base:
        return []
    parts = [p for p in re.split(r"\s+", base) if p]
    stop = {
        'the', 'a', 'an', 'to', 'and', 'or', 'for', 'of', 'in', 'on', 'with',
        'tab', 'button', 'link', 'field', 'input', 'text', 'label', 'title'
    }
    tokens: Set[str] = {p for p in parts if len(p) >= 3 and p not in stop}

    # synonyms/aliases per token (generic, not per element key)
    syn_map = {
        'login': {'signin', 'sign', 'log', 'logon'},
        'sign': {'signin', 'login'},
        'user': {'username', 'userid', 'email'},
        'name': {'username'},
        'email': {'mail'},
        'pass': {'password'},
        'password': {'pass', 'pwd'},
        'issue': {'issues'},
        'test': {'tests', 'plan', 'plans'},
        'agree': {'accept', 'ok'},
        'close': {'dismiss'},
        'other': {'more', 'another'},
        'project': {'workspace'},
    }
    # multi-word canonical intents
    base_join = " ".join(parts)
    if 'sign in' in base_join:
        tokens.update({'sign', 'signin'})
    if 'log in' in base_join:
        tokens.update({'login'})

    # expand synonyms
    for t in list(tokens):
        for k, vs in syn_map.items():
            if t == k or t in vs:
                tokens.update(vs | {k})

    # add bigrams for adjacent words (helps phrase-level intents like "reset password")
    try:
        for i in range(len(parts) - 1):
            bigram = f"{parts[i]} {parts[i+1]}".strip()
            if bigram and all(len(w) >= 2 for w in bigram.split()):
                tokens.add(bigram)
    except Exception:
        pass

    return list(sorted(tokens))


class CandidateGenerator:
    def __init__(self):
        self.embedder = ElementEmbedder()

    def _simple_score(self, semantic_label: str, desc: str) -> float:
        try:
            lbl = _normalize_text(semantic_label)
            desc_l = _normalize_text(desc)
            if not lbl or not desc_l:
                return 0.0
            words = [w for w in lbl.split() if w]
            if not words:
                return 0.0
            hits = sum(1 for w in words if w in desc_l)
            return hits / max(1, len(words))
        except Exception:
            return 0.0

    def _infer_ios_tag(self, label_tokens: List[str]) -> Optional[str]:
        toks = set(label_tokens)
        if {'password', 'pass', 'pwd'} & toks:
            return 'SecureTextField'
        if {'user', 'username', 'email', 'name'} & toks:
            return 'TextField'
        # verb-y intents likely buttons
        if {'login', 'signin', 'sign', 'agree', 'ok', 'continue', 'close', 'other'} & toks:
            return 'Button'
        return None

    def _has_any_token(self, tokens: List[str], text: str) -> bool:
        low = _normalize_text(text)
        return any(t in low for t in tokens)

    def _web_locator(self, node, tag: str, a: Dict[str, Any], label_tokens: List[str]):
        # id > name > placeholder/aria-label > visible text (use tokens)
        try:
            cfg = get_smartheal_config() or {}
            boost_testid = bool(cfg.get('enable_data_testid_boost', False))
        except Exception:
            boost_testid = False
        # data-testid / data-test / data-qa boost (optional)
        if boost_testid:
            for attr in ('data-testid', 'data-test', 'data-qa'):
                if a.get(attr):
                    esc = str(a[attr]).replace("'", "\\'")
                    return f"//*[@{attr}='{esc}']", 'xpath', 'xpath', True
        if a.get('id'):
            return a['id'], 'id', 'id', False
        if a.get('name'):
            esc = str(a['name']).replace("'", "\\'")
            return f"//{tag}[@name='{esc}']", 'xpath', 'xpath', True
        token_subset = label_tokens[:2]  # avoid very long predicates
        for attr in ('placeholder', 'aria-label'):
            if a.get(attr):
                esc = str(a[attr]).replace("'", "\\'")
                # ensure token alignment; if attribute already contains a token, match contains(attr, raw)
                pred = f"contains(@{attr}, '{esc}')"
                return f"//{tag}[{pred}]", 'xpath', 'xpath', True
        vis = (getattr(node, 'text', None) or '').strip()
        if vis:
            esc = vis.replace("'", "\\'")
            # fallback with tokens if visible text is long
            if len(esc) > 40 and token_subset:
                ors = " or ".join([f"contains(normalize-space(text()), '{t}')" for t in token_subset])
                return f"//{tag}[{ors}]", 'xpath', 'xpath', True
            return f"//{tag}[contains(normalize-space(text()), '{esc}') or contains(., '{esc}')]", 'xpath', 'xpath', True
        return None, None, None, False

    def _android_locator(self, a: Dict[str, Any], label_tokens: List[str]):
        # accessibility_id (content-desc) > id (resource-id) > UiSelector > text contains xpath
        if a.get('content-desc'):
            return a['content-desc'], 'accessibility_id', 'accessibility', False
        if a.get('resource-id'):
            return a['resource-id'], 'id', 'id', False
        # UiSelector using first strong token
        if label_tokens:
            tok = label_tokens[0]
            esc = tok.replace('"', '\\"')
            # Optionally try descriptionContains as alternative based on config
            try:
                cfg = get_smartheal_config() or {}
                use_desc = bool(cfg.get('android_desc_contains', False))
            except Exception:
                use_desc = False
            ui = f'new UiSelector().textContains("{esc}")'
            if use_desc:
                ui = f'new UiSelector().descriptionContains("{esc}")'
            return ui, 'ui_automator', 'automator', True
        if a.get('text'):
            esc = a['text'].replace("'", "\\'")
            return f"//*[contains(@text, '{esc}')]", 'xpath', 'xpath', True
        return None, None, None, False

    def _ios_locator(self, tag: str, a: Dict[str, Any], label_tokens: List[str]):
        # prefer accessibility id via 'name'/'label'; then predicate constrained by intended control type and tokens
        if a.get('name'):
            return a['name'], 'accessibility_id', 'accessibility', False
        if a.get('label'):
            return a['label'], 'accessibility_id', 'accessibility', False
        desired_tag = self._infer_ios_tag(label_tokens)
        typ = f"XCUIElementType{desired_tag}" if desired_tag else tag
        # build predicate using tokens on name/label
        if label_tokens:
            subset = label_tokens[:2]
            ors = []
            for t in subset:
                esc = t.replace('"', '\\"')
                ors.append(f"name CONTAINS[c] \"{esc}\"")
                ors.append(f"label CONTAINS[c] \"{esc}\"")
                ors.append(f"value CONTAINS[c] \"{esc}\"")
            pred = " OR ".join(ors)
            return f"type == \"{typ}\" AND ({pred})", 'ios_predicate', 'predicate', True
        # Avoid raw //XCUIElementType*
        return None, None, None, False

    def find_candidates(self, broken_meta: Dict[str, Any], dom_source: str, platform: str) -> List[Dict[str, Any]]:
        # Parse document
        try:
            if platform == 'web':
                tree = html.fromstring(dom_source)
            else:
                parser = etree.XMLParser(recover=True)
                tree = etree.fromstring(bytes(dom_source, encoding='utf-8'), parser=parser)
        except Exception:
            return []

        label = broken_meta.get('semantic_label') or ''
        label_tokens = _label_tokens(label)
        if not label_tokens:
            return []

        candidates: List[Dict[str, Any]] = []
        model_available = getattr(self.embedder, 'model', None) is not None
        target_emb = self.embedder.encode(label) if model_available else label
        cfg = {}
        try:
            cfg = get_smartheal_config() or {}
        except Exception:
            cfg = {}
        skip_hidden_web = bool(cfg.get('skip_hidden_web', False))
        try:
            scan_max_nodes = int(cfg.get('scan_max_nodes', 0) or 0)
        except Exception:
            scan_max_nodes = 0
        try:
            scan_time_budget_ms = int(cfg.get('scan_time_budget_ms', 0) or 0)
        except Exception:
            scan_time_budget_ms = 0
        min_floor = float(cfg.get('min_confidence_floor', 0.50))
        threshold = 0.50 if min_floor < 0.50 else min_floor

        # iterate and collect
        skip_tags_web = {"script", "style", "head", "meta", "link"}
        items = []  # hold raw candidates to score later (enables batch encode)

        t0 = time.time()
        seen_nodes = 0
        for node in tree.iter():
            seen_nodes += 1
            if scan_max_nodes and seen_nodes > scan_max_nodes:
                break
            if scan_time_budget_ms and ((time.time() - t0) * 1000.0) > scan_time_budget_ms:
                break
            try:
                t = node.tag
            except Exception:
                continue
            # High Efficiency: ignore non-UI tags for web to reduce noise and speed up scanning
            if platform == 'web':
                try:
                    tag_name = str(t).lower()
                    if tag_name in skip_tags_web:
                        continue
                except Exception:
                    pass
            attrs = dict(getattr(node, 'attrib', {}) or {})
            # Optional: skip hidden web nodes (safe default is off)
            if platform == 'web' and skip_hidden_web:
                try:
                    if attrs.get('type', '').lower() == 'hidden' or 'hidden' in attrs or str(attrs.get('aria-hidden', '')).lower() == 'true':
                        continue
                except Exception:
                    pass
            inner_text = (getattr(node, 'text', None) or '').strip()

            # collect descriptive attributes across platforms
            text_vals = [
                inner_text,
                attrs.get('text', ''), attrs.get('content-desc', ''), attrs.get('resource-id', ''),
                attrs.get('id', ''), attrs.get('name', ''), attrs.get('placeholder', ''), attrs.get('aria-label', ''),
                attrs.get('value', ''), attrs.get('label', '')
            ]
            desc = " ".join(v for v in text_vals if v)
            if not desc.strip():
                continue

            # token-based DOM filtering: require at least one token present in any attribute/text,
            # BUT allow "safe" strategies (IDs / accessibility IDs) to skip this filter.
            safe_flag = False
            try:
                if platform == 'web' and attrs.get('id'):
                    safe_flag = True
                if platform == 'web':
                    try:
                        cfg = get_smartheal_config() or {}
                        if bool(cfg.get('enable_data_testid_boost', False)) and any(
                            k in attrs for k in ('data-testid', 'data-test', 'data-qa')
                        ):
                            safe_flag = True
                    except Exception:
                        pass
                elif platform != 'web' and (attrs.get('content-desc') or attrs.get('resource-id')):
                    safe_flag = True
                if platform == 'ios' and (attrs.get('name') or attrs.get('label')):
                    safe_flag = True
            except Exception:
                pass
            if not safe_flag and not self._has_any_token(label_tokens, desc):
                continue

            # build best locator per platform
            if platform == 'web':
                loc, strat, family, had_pred = self._web_locator(node, t, attrs, label_tokens)
            elif platform == 'ios':
                loc, strat, family, had_pred = self._ios_locator(t, attrs, label_tokens)
            else:
                loc, strat, family, had_pred = self._android_locator(attrs, label_tokens)

            if not loc:
                continue

            # Avoid raw/generic xpath like //XCUIElementTypeButton or //tag only
            if strat == 'xpath':
                low = str(loc)
                if re.match(r"^//[^\[]+$", low):
                    # no predicate present
                    continue

            # Defer scoring (enable batch encoding)
            items.append({
                'locator': loc,
                'strategy': strat,
                'strategy_family': family,
                'had_predicate': bool(had_pred),
                'attributes': attrs,
                'tag': t,
                'desc': desc,
                'safe_flag': safe_flag,
            })

        # Now score and threshold
        if not items:
            return []

        if model_available:
            try:
                cand_embs = self.embedder.encode_many([it['desc'] for it in items])
            except Exception:
                cand_embs = None
        else:
            cand_embs = None

        for idx, it in enumerate(items):
            try:
                if model_available and cand_embs is not None:
                    score = self.embedder.similarity(target_emb, cand_embs[idx])
                else:
                    score = self._simple_score(label, it['desc'])
            except Exception:
                score = 0.0

            # Strict threshold to cut noisy candidates aggressively, enforce >= min floor (never below 0.50)
            sc = float(score)
            if it.get('safe_flag'):
                sc = max(sc, 0.90)
            if sc < threshold:
                continue

            candidates.append({
                'locator': it['locator'],
                'strategy': it['strategy'],
                'strategy_family': it['strategy_family'],
                'had_predicate': it['had_predicate'],
                'semantic_score': float(sc),
                'attributes': it['attributes'],
                'tag': it['tag'],
            })

        return candidates
